package namoo.drama.feedback.adapter.rest;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.spec.drama.FeedbackProvider;
import namoo.drama.feedback.domain.spec.shared.FeedbackCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.restclient.NaraRestClient;
import namoo.nara.share.restclient.RequestBuilder;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-16
 */
public class FeedbackRestAdapter implements FeedbackProvider {
    //
    private NaraRestClient naraRestClient;

    public FeedbackRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public String registerReplyFeedback(FeedbackCdo feedbackCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_FEEDBACK_REGISTER)
                .setRequestBody(feedbackCdo)
                .setResponseType(String.class)
        );
    }

    @Override
    public String registerReviewFeedback(FeedbackCdo feedbackCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REVIEW_FEEDBACK_REGISTER)
                .setRequestBody(feedbackCdo)
                .setResponseType(String.class)
        );
    }

    @Override
    public Feedback findFeedback(String feedbackId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_FEEDBACK_FIND)
                .addPathParam("feedbackId", feedbackId)
                .setResponseType(Feedback.class)
        );
    }

    @Override
    public void makeAnonymous(String feedbackId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_FEEDBACK_MAKE_ANONYMOUS)
                .addPathParam("feedbackId", feedbackId)
        );
    }

    @Override
    public void modifyFeedback(String feedbackId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_FEEDBACK_MODIFY)
                .addPathParam("feedbackId", feedbackId)
                .setRequestBody(nameValues)
        );
    }

    @Override
    public void removeReplyFeedback(String feedbackId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_FEEDBACK_REMOVE)
                .addPathParam("feedbackId", feedbackId)
        );
    }

    @Override
    public void removeReviewFeedback(String feedbackId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REVIEW_FEEDBACK_REMOVE)
                .addPathParam("feedbackId", feedbackId)
        );
    }
}
