package namoo.drama.feedback.adapter.rest;

import namoo.nara.share.restclient.HttpMethod;
import namoo.nara.share.restclient.NaraRestUrl;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-16
 */
public enum FeedbackRestUrl implements NaraRestUrl {
    //
    // Feedback
    URL_REPLY_FEEDBACK_REGISTER         ("feedback-prov-api/feedback/reply",                                HttpMethod.POST),
    URL_REVIEW_FEEDBACK_REGISTER        ("feedback-prov-api/feedback/reply",                                HttpMethod.POST),
    URL_FEEDBACK_FIND                   ("feedback-prov-api/feedback/{feedbackId}",                         HttpMethod.GET),
    URL_FEEDBACK_MAKE_ANONYMOUS         ("feedback-prov-api/feedback/{feedbackId}/anonymous",               HttpMethod.PUT),
    URL_FEEDBACK_MODIFY                 ("feedback-prov-api/feedback/{feedbackId}",                         HttpMethod.PUT),
    URL_REPLY_FEEDBACK_REMOVE           ("feedback-prov-api/feedback/{feedbackId}/reply",                   HttpMethod.DELETE),
    URL_REVIEW_FEEDBACK_REMOVE          ("feedback-prov-api/feedback/{feedbackId}/review",                  HttpMethod.DELETE),

    // reply
    URL_REPLY_REGISTER                  ("feedback-prov-api/replies",                                       HttpMethod.POST),
    URL_REPLY_FIND                      ("feedback-prov-api/replies/{replyId}",                             HttpMethod.GET),
    URL_REPLIES_FIND                    ("feedback-prov-api/replies",                                       HttpMethod.GET),
    URL_REPLY_MODIFY                    ("feedback-prov-api/replies/{replyId}",                             HttpMethod.PUT),
    URL_REPLY_REMOVE                    ("feedback-prov-api/replies/{replyId}",                             HttpMethod.DELETE),
    URL_REPLY_COMMENT_ADD               ("feedback-prov-api/replies/{replyId}/comment",                     HttpMethod.POST),
    URL_REPLY_COMMENT_MODIFY            ("feedback-prov-api/replies/{replyId}/comment/{sequence}",          HttpMethod.PUT),
    URL_REPLY_COMMENT_REMOVE            ("feedback-prov-api/replies/{replyId}/comment/{sequence}",          HttpMethod.DELETE),

    // review
    URL_REVIEW_REGISTER                 ("feedback-prov-api/reviews",                                       HttpMethod.POST),
    URL_VERSIONED_REVIEW_REGISTER       ("feedback-prov-api/reviews/version/{version}",                     HttpMethod.POST),
    URL_REVIEW_FIND                     ("feedback-prov-api/reviews/{reviewId}",                            HttpMethod.GET),
    URL_REVIEWS_FIND                    ("feedback-prov-api/reviews",                                       HttpMethod.GET),
    URL_VERSIONED_REVIEWS_FIND          ("feedback-prov-api/reviews/version/{version}",                     HttpMethod.GET),
    URL_REVIEW_MODIFY                   ("feedback-prov-api/reviews/{reviewId}",                            HttpMethod.PUT),
    URL_REVIEW_REMOVE                   ("feedback-prov-api/reviews/{reviewId}",                            HttpMethod.DELETE),
    URL_HELP_COMMENT_ADD                ("feedback-prov-api/reviews/{reviewId}/help",                       HttpMethod.POST),
    URL_HELP_COMMENT_REMOVE             ("feedback-prov-api/reviews/{reviewId}/help/{helpCommentId}",       HttpMethod.DELETE),
    URL_HELP_COMMENT_BY_REVIEWER_REMOVE ("feedback-prov-api/reviews/{reviewId}/help/reviewer/{reviewerId}", HttpMethod.DELETE),
    URL_REVIEW_SUMMARY_FIND             ("feedback-prov-api/reviews/summary",                               HttpMethod.DELETE),

    ;

    private String serviceUrl;
    private HttpMethod method;

    FeedbackRestUrl(String serviceUrl, HttpMethod httpMethod) {
        this.serviceUrl = serviceUrl;
        this.method = httpMethod;
    }

    @Override
    public String getUrl() {
        return serviceUrl;
    }

    @Override
    public HttpMethod getMethod() {
        return method;
    }
}
