package namoo.drama.feedback.adapter.rest;

import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.spec.drama.ReplyProvider;
import namoo.drama.feedback.domain.spec.shared.CommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReplyCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.restclient.NaraRestClient;
import namoo.nara.share.restclient.RequestBuilder;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-16
 */
public class ReplyRestAdapter implements ReplyProvider {
    //
    private NaraRestClient naraRestClient;

    public ReplyRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public String registerReply(String feedbackId, ReplyCdo replyCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_REGISTER)
                .addQueryParam("feedbackId", feedbackId)
                .setRequestBody(replyCdo)
                .setResponseType(String.class)
        );
    }

    @Override
    public Reply findReply(String replyId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_FIND)
                .addPathParam("replyId", replyId)
                .setResponseType(Reply.class)
        );
    }

    @Override
    public OffsetList<Reply> findReplies(String feedbackId, int offset, int limit) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLIES_FIND)
                .addQueryParam("feedbackId", feedbackId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(OffsetList.class)
        );
    }

    @Override
    public void modifyReply(String replyId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_MODIFY)
                .addPathParam("replyId", replyId)
                .setRequestBody(nameValues)
        );
    }

    @Override
    public void removeReply(String replyId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_REMOVE)
                .addPathParam("replyId", replyId)
        );
    }

    @Override
    public int addComment(String replyId, CommentCdo commentCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_COMMENT_ADD)
                .addPathParam("replyId", replyId)
                .setRequestBody(commentCdo)
                .setResponseType(Integer.class)
        );
    }

    @Override
    public void modifyComment(String replyId, int sequence, String text) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_COMMENT_MODIFY)
                .addPathParam("replyId", replyId)
                .addPathParam("sequence", sequence)
                .setRequestBody(text)
        );
    }

    @Override
    public void removeComment(String replyId, int sequence) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REPLY_COMMENT_REMOVE)
                .addPathParam("replyId", replyId)
                .addPathParam("sequence", sequence)
        );
    }
}
