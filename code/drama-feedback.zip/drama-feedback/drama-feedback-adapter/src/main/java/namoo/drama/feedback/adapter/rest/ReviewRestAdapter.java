package namoo.drama.feedback.adapter.rest;

import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.drama.feedback.domain.spec.drama.ReviewProvider;
import namoo.drama.feedback.domain.spec.shared.HelpCommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReviewCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.restclient.NaraRestClient;
import namoo.nara.share.restclient.RequestBuilder;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-16
 */
public class ReviewRestAdapter implements ReviewProvider {
    //
    private NaraRestClient naraRestClient;

    public ReviewRestAdapter(NaraRestClient naraRestClient) {
        //
        this.naraRestClient = naraRestClient;
    }

    @Override
    public String registerReview(String feedbackId, ReviewCdo reviewCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REVIEW_REGISTER)
                .addQueryParam("feedbackId", feedbackId)
                .setRequestBody(reviewCdo)
                .setResponseType(String.class)
        );
    }

    @Override
    public String registerVersionedReview(String feedbackId, String version, ReviewCdo reviewCdo) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_VERSIONED_REVIEW_REGISTER)
                .addQueryParam("feedbackId", feedbackId)
                .addPathParam("version", version)
                .setRequestBody(reviewCdo)
                .setResponseType(String.class)
        );
    }

    @Override
    public Review findReview(String reviewId) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REVIEW_FIND)
                .addPathParam("reviewId", reviewId)
                .setResponseType(Review.class)
        );
    }

    @Override
    public OffsetList<Review> findReviews(String feedbackId, int offset, int limit) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REVIEWS_FIND)
                .addQueryParam("feedbackId", feedbackId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(OffsetList.class)
        );
    }

    @Override
    public OffsetList<Review> findReviews(String feedbackId, String version, int offset, int limit) {
        //
        return naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_VERSIONED_REVIEWS_FIND)
                .addPathParam("version", version)
                .addQueryParam("feedbackId", feedbackId)
                .addQueryParam("offset", offset)
                .addQueryParam("limit", limit)
                .setResponseType(OffsetList.class)
        );
    }

    @Override
    public void modifyReview(String reviewId, NameValueList nameValues) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REVIEW_MODIFY)
                .addPathParam("reviewId", reviewId)
                .setRequestBody(nameValues)
        );
    }

    @Override
    public void addHelpComment(String reviewId, HelpCommentCdo helpCommentCdo) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_HELP_COMMENT_ADD)
                .addPathParam("reviewId", reviewId)
                .setRequestBody(helpCommentCdo)
        );
    }

    @Override
    public void removeHelpComment(String helpCommentId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_HELP_COMMENT_REMOVE)
                .addPathParam("helpCommentId", helpCommentId)
        );
    }

    @Override
    public void removeHelpComment(String reviewId, String reviewerId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_HELP_COMMENT_BY_REVIEWER_REMOVE)
                .addPathParam("reviewId", reviewId)
                .addPathParam("reviewerId", reviewerId)
        );
    }

    @Override
    public void removeReview(String reviewId) {
        //
        naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REVIEW_REMOVE)
                .addPathParam("reviewId", reviewId)
        );
    }

    @Override
    public ReviewSummary findReviewSummary(String feedbackId) {
        //
        return  naraRestClient.sendAndRecieve(
            RequestBuilder.create(FeedbackRestUrl.URL_REVIEW_SUMMARY_FIND)
                .addQueryParam("feedbackId", feedbackId)
        );
    }

}
