package namoo.drama.feedback.domain.proxy;

import namoo.nara.share.event.NaraEventProxy;

public interface FeedbackProxyLycler {
    //
    NaraEventProxy requestEventProxy();
    EnvoyProxy requestEnvoyProxy();
}
