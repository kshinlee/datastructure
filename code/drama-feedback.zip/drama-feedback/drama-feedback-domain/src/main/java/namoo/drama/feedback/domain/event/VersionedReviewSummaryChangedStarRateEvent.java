package namoo.drama.feedback.domain.event;

import namoo.nara.share.event.NaraEvent;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
public class VersionedReviewSummaryChangedStarRateEvent implements NaraEvent {
    //
    private String feedbackId;
    private String version;
    private int selectedStar;
    private boolean increased;

    public VersionedReviewSummaryChangedStarRateEvent(String feedbackId, String version, int selectedStar, boolean increased) {
        //
        this.feedbackId = feedbackId;
        this.version = version;
        this.selectedStar = selectedStar;
        this.increased = increased;
    }

    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getSelectedStar() {
        return selectedStar;
    }

    public void setSelectedStar(int selectedStar) {
        this.selectedStar = selectedStar;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public boolean isIncreased() {
        return increased;
    }

    public void setIncreased(boolean increased) {
        this.increased = increased;
    }
}
