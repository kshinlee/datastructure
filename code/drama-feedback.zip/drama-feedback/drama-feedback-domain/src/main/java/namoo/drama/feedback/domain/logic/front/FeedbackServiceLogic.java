package namoo.drama.feedback.domain.logic.front;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.proxy.FeedbackProxyLycler;
import namoo.drama.feedback.domain.spec.front.FeedbackService;
import namoo.drama.feedback.domain.spec.shared.FeedbackCdo;
import namoo.drama.feedback.domain.store.*;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.domain.ScreenId;

public class FeedbackServiceLogic implements FeedbackService {
    //
    private FeedbackStore feedbackStore;
    private ReplyStore replyStore;
    private ReviewStore reviewStore;
    private ReviewSummaryStore reviewSummaryStore;

    public FeedbackServiceLogic(FeedbackStoreLycler storeLycler, FeedbackProxyLycler proxyLycler) {
        //
        this.feedbackStore = storeLycler.requestFeedbackStore();
        this.replyStore = storeLycler.requestReplyStore();
        this.reviewStore = storeLycler.requestReviewStore();
        this.reviewSummaryStore = storeLycler.requestReviewSummaryStore();
    }

    @Override
    public String registerReplyFeedback(FeedbackCdo feedbackCdo) {
        return null;
    }

    @Override
    public String registerReviewFeedback(FeedbackCdo feedbackCdo) {
        return null;
    }

    @Override
    public Feedback findFeedback(String feedbackId) {
        return null;
    }

    @Override
    public void modifyFeedback(String feedbackId, NameValueList nameValues) {

    }

    @Override
    public OffsetList<Feedback> findFeedback(String pavilionId, int offset, int limit) {
        return feedbackStore.retrieveAllByPavilionId(pavilionId, offset, limit);
    }

    @Override
    public OffsetList<Feedback> findFeedbackByCineroomId(String pavilionId, String cineroomId, int offset, int limit) {
        return null;
    }

    @Override
    public OffsetList<Feedback> findFeedback(ScreenId screenId, int offset, int limit) {
        return null;
    }

    @Override
    public OffsetList<Feedback> findFeedbackByDramaId(String pavilionId, String dramaId, int offset, int limit) {
        return null;
    }
}
