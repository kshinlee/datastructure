package namoo.drama.feedback.domain.entity.reply;

import namoo.nara.share.domain.ValueObject;
import namoo.nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.List;

public class CommentList implements ValueObject {
    //
    private List<Comment> comments;

    public CommentList() {
        //
        this.comments = new ArrayList<>();
    }

    public CommentList(Comment comment) {
        //
        this();
        this.comments.add(comment);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("CommentList{");
        sb.append("comments=").append(comments);
        sb.append('}');
        return sb.toString();
    }

    public static CommentList getSample() {
        //
        CommentList sample = new CommentList();
        sample.add(Comment.getSample());

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static CommentList fromJson(String json) {
        //
        return JsonUtil.fromJson(json, CommentList.class);
    }

    public void add(Comment comment) {
        //
        this.comments.add(comment);
    }

    public void addAll(List<Comment> comments) {
        //
        this.comments.addAll(comments);
    }

    public List<Comment> getList() {
        //
        return comments;
    }

    public Comment getFirst() {
        //
        if (comments == null || comments.isEmpty()) return null;
        return comments.get(0);
    }

    public Comment getLast() {
        //
        if (comments == null || comments.isEmpty()) return null;
        return comments.get(size()-1);
    }

    public Comment get(int sequence) {
        //
        Comment foundComment = null;
        for(Comment comment : this.comments) {
            if (comment.getSequence() == sequence) {
                foundComment = comment;
                break;
            }
        }

        return foundComment;
    }

    public boolean contains(int sequence) {
        //
        for(Comment comment : this.comments) {
            if (comment.getSequence() == sequence) {
                return true;
            }
        }
        return false;
    }

    public void remove(Comment comment) {
        //
        comments.remove(comment);
    }

    public int size() {
        return comments.size();
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
        System.out.println(getSample().toJson());
    }
}
