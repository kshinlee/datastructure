package namoo.drama.feedback.domain.spec.shared;

import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.util.json.JsonUtil;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-11
 */
public class HelpCommentCdo {
    //
    private String reviewerId;
    private boolean helpful;

    private NameValueList nameValues;

    public HelpCommentCdo() {

    }

    public HelpCommentCdo(String reviewerId, boolean helpful) {
        //
        this.reviewerId = reviewerId;
        this.helpful = helpful;
        this.nameValues = null;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("HelpCommentCdo{");
        sb.append("reviewerId=").append(reviewerId);
        sb.append(", helpful='").append(helpful).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static HelpCommentCdo getSample() {
        //
        String reviewerId = Actor.getSample().getId();
        boolean helpful = true;

        HelpCommentCdo sample = new HelpCommentCdo(reviewerId, helpful);

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static HelpCommentCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, HelpCommentCdo.class);
    }

    public boolean hasNameValues() {
        //
        if(nameValues != null) {
            return true;
        }

        return false;
    }

    public NameValueList getNameValues() {
        return nameValues;
    }

    public void setNameValues(NameValueList nameValues) {
        this.nameValues = nameValues;
    }

    public String getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(String reviewerId) {
        this.reviewerId = reviewerId;
    }

    public boolean isHelpful() {
        return helpful;
    }

    public void setHelpful(boolean helpful) {
        this.helpful = helpful;
    }
}
