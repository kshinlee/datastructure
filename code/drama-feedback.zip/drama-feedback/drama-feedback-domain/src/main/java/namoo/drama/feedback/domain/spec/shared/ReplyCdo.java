package namoo.drama.feedback.domain.spec.shared;

import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.util.json.JsonUtil;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-11
 */
public class ReplyCdo {
    //
    private Actor writer;
    private String text;

    private NameValueList nameValues;

    public ReplyCdo() {

    }

    public ReplyCdo(Actor writer, String text) {
        //
        this.writer = writer;
        this.text = text;
        this.nameValues = null;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReplyCdo{");
        sb.append("writer=").append(writer);
        sb.append(", text='").append(text).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static ReplyCdo getSample() {
        //
        Actor writer = Actor.getSample();
        String text = "열흘 사용 후 솔직한 생각";

        ReplyCdo sample = new ReplyCdo(writer, text);

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static ReplyCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ReplyCdo.class);
    }

    public boolean hasNameValues() {
        //
        if(nameValues != null) {
            return true;
        }

        return false;
    }

    public NameValueList getNameValues() {
        return nameValues;
    }

    public void setNameValues(NameValueList nameValues) {
        this.nameValues = nameValues;
    }


    public Actor getWriter() {
        return writer;
    }

    public void setWriter(Actor writer) {
        this.writer = writer;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
