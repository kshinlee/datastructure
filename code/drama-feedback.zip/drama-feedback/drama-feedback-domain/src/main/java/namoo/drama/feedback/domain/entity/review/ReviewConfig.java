package namoo.drama.feedback.domain.entity.review;

import namoo.drama.feedback.domain.entity.feedback.FeedbackConfig;
import namoo.nara.share.domain.ValueObject;
import namoo.nara.share.util.json.JsonUtil;

public class ReviewConfig extends FeedbackConfig implements ValueObject {
    //
    private int maxStarCount;
    private boolean versionBased;

    public ReviewConfig() {
        //
        super();
        this.maxStarCount = 5;
        this.versionBased = false;
    }

    public ReviewConfig(boolean anonymous, int maxStarCount, boolean versionBased) {
        //
        super(anonymous);
        this.maxStarCount = maxStarCount;
        this.versionBased = versionBased;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReviewConfig{");
        sb.append(super.toString());
        sb.append(", maxStarCount=").append(maxStarCount);
        sb.append(", versionBased=").append(versionBased);
        sb.append('}');
        return sb.toString();
    }

    public static ReviewConfig getSample() {
        //
        return new ReviewConfig();
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static ReviewConfig fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ReviewConfig.class);
    }

    public int getMaxStarCount() {
        return maxStarCount;
    }

    public void setMaxStarCount(int maxStarCount) {
        this.maxStarCount = maxStarCount;
    }

    public boolean isVersionBased() {
        return versionBased;
    }

    public void setVersionBased(boolean versionBased) {
        this.versionBased = versionBased;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}