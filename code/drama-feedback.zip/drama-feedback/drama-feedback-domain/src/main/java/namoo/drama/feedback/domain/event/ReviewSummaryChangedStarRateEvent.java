package namoo.drama.feedback.domain.event;

import namoo.nara.share.event.NaraEvent;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
public class ReviewSummaryChangedStarRateEvent implements NaraEvent {
    //
    private String feedbackId;
    private int selectedStar;
    private boolean increased;

    public ReviewSummaryChangedStarRateEvent(String feedbackId, int selectedStar, boolean increased) {
        //
        this.feedbackId = feedbackId;
        this.selectedStar = selectedStar;
        this.increased = increased;
    }

    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getSelectedStar() {
        return selectedStar;
    }

    public void setSelectedStar(int selectedStar) {
        this.selectedStar = selectedStar;
    }

    public boolean isIncreased() {
        return increased;
    }

    public void setIncreased(boolean increased) {
        this.increased = increased;
    }
}
