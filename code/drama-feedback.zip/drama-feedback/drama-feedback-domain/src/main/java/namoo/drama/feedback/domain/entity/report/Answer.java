package namoo.drama.feedback.domain.entity.report;

import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.ValueObject;
import namoo.nara.share.util.json.JsonUtil;

public class Answer implements ValueObject {
    //
    public static final int MAX_SEQUENCE = 10;

    private int sequence;
    private String text;
    private Actor writer;
    private Long time;


    public Answer() {
        //
    }

    public Answer(int sequence, Actor writer, String text) {
        //
        this.sequence = sequence;
        this.text = text;
        this.writer = writer;
        this.time = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Answer{");
        sb.append("sequence=").append(sequence);
        sb.append(", text='").append(text).append('\'');
        sb.append(", writer=").append(writer);
        sb.append(", time=").append(time);
        sb.append('}');
        return sb.toString();
    }

    public static Answer getSample() {
        //
        int sequence = 1;
        Actor writer = Actor.getSample();
        String text = "요청하신 부분 반영하였습니다.";

        Answer sample = new Answer(sequence, writer, text);

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static Answer fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Answer.class);
    }


    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Actor getWriter() {
        return writer;
    }

    public void setWriter(Actor writer) {
        this.writer = writer;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
