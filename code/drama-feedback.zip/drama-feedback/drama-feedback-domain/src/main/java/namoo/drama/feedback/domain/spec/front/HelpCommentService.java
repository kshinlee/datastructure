package namoo.drama.feedback.domain.spec.front;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.nara.stage.dramaspec.annotation.OptionLabel;
import namoo.nara.stage.dramaspec.annotation.RoleLabel;

import java.util.List;

//@OptionLabel(
//    supportEditions = {"Basic"},
//    feature = "HelpComment"
//)
//@RoleLabel(names = "user")
public interface HelpCommentService {
    //
    void removeHelpCommentsByReviewId(String reviewId);
}
