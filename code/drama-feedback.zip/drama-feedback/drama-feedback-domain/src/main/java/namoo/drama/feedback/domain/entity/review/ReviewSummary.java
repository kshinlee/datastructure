package namoo.drama.feedback.domain.entity.review;


import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.nara.share.domain.Entity;
import namoo.nara.share.domain.IntPair;
import namoo.nara.share.domain.IntPairList;
import namoo.nara.share.util.json.JsonUtil;

import java.util.LinkedHashMap;
import java.util.Map;

public class ReviewSummary extends Entity {
    //
    private boolean versionBased;
    private int maxStarCount;

    private int reviewerCount;
    private double average;             // 4.31
    private IntPairList starCounts;     // 1:2, 2:3, 3:0, 4:5, 5:10

    private Map<String,IntPairList> versionStarCountMap;
    private Map<String,Integer> versionReviewerCountMap;

    public ReviewSummary(String id) {
        //
        super(id);
    }

    public ReviewSummary(String feedbackId, ReviewConfig config) {
        //
        super(feedbackId);

        this.versionBased = config.isVersionBased();
        this.maxStarCount = config.getMaxStarCount();
        this.reviewerCount = 0;
        this.starCounts = new IntPairList(maxStarCount);
        this.versionStarCountMap = new LinkedHashMap<>();
        this.versionReviewerCountMap = new LinkedHashMap<>();
    }

    public void setValues(ReviewConfig reviewConfig) {
        //
        this.versionBased = reviewConfig.isVersionBased();
        this.maxStarCount = reviewConfig.getMaxStarCount();
    }

    public void updateAverage() {
        //
        if (maxStarCount != starCounts.size()) {
            throw new IllegalArgumentException("maxStarCount:" + maxStarCount + "starCounts:" + starCounts.size());
        }
        int rightTotal = 0;
        double total = 0.0;
        for(IntPair starCount : starCounts.getList()) {
            rightTotal += starCount.getRight();
            total += (starCount.getLeft() * starCount.getRight());
        }

        this.average = total/rightTotal;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReviewSummary{");
        sb.append("versionBased=").append(versionBased);
        sb.append(", maxStarCount=").append(maxStarCount);
        sb.append(", reviewerCount=").append(reviewerCount);
        sb.append(", average=").append(average);
        sb.append(", starCounts=").append(starCounts);
        sb.append(", versionStarCountMap=").append(versionStarCountMap);
        sb.append(", versionReviewerCountMap=").append(versionReviewerCountMap);
        sb.append('}');
        return sb.toString();
    }

    public static ReviewSummary getSample() {
        //
        String feedbackId = Feedback.getSample().getId();
        ReviewConfig config = ReviewConfig.getSample();

        ReviewSummary sample = new ReviewSummary(feedbackId, config);
        IntPairList startCounts = sample.getStarCounts();
        startCounts.increaseRight(1);
        startCounts.increaseRight(2);
        startCounts.increaseRight(3);
        startCounts.increaseRight(4);
        startCounts.increaseRight(5);

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static ReviewSummary fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ReviewSummary.class);
    }

    public void increase(int selectedStar) {
        //
        if (starCounts.size() < selectedStar) {
            for (int i=starCounts.size(); i<selectedStar; i++) {
                starCounts.getList().add(new IntPair(i + 1, 0));
            }
        }
        starCounts.increaseRight(selectedStar);
        reviewerCount++;
        this.updateAverage();
    }

    public void decrease(int selectedStar) {
        //
        if (starCounts.size() < selectedStar) {
            return;
        }
        starCounts.decreaseRight(selectedStar);
        reviewerCount--;
        this.updateAverage();
    }

    public void increase(int selectedStar, String version) {
        //
        this.increase(selectedStar);

        IntPairList versionStarCount = this.getVersionCounts(version);
        if (versionStarCount.size() < selectedStar) {
            for (int i=versionStarCount.size(); i<selectedStar; i++) {
                versionStarCount.getList().add(new IntPair(i + 1, 0));
            }
        }
        versionStarCount.increaseRight(selectedStar);

        Integer versionReviewerCount = this.getVersionReviewerCount(version);
        this.versionReviewerCountMap.put(version, ++versionReviewerCount);
        this.updateAverage();
    }

    public void decrease(int selectedStar, String version) {
        //
        this.decrease(selectedStar);

        IntPairList versionStarCount = this.getVersionCounts(version);
        if (versionStarCount.size() < selectedStar) {
            return;
        }
        versionStarCount.decreaseRight(selectedStar);

        Integer versionReviewerCount = this.getVersionReviewerCount(version);
        this.versionReviewerCountMap.put(version, --versionReviewerCount);
        this.updateAverage();
    }

    public IntPairList getVersionCounts(String version) {
        //
        IntPairList versionCounts = this.versionStarCountMap.get(version);
        if (versionCounts == null) {
            versionCounts = new IntPairList(maxStarCount);
            this.versionStarCountMap.put(version, versionCounts);
        }

        return versionCounts;
    }

    public Integer getVersionReviewerCount(String version) {
        //
        Integer versionReviewerCount = this.versionReviewerCountMap.get(version);
        if(versionReviewerCount == null) {
            versionReviewerCount = 0;
            this.versionReviewerCountMap.put(version, versionReviewerCount);
        }

        return versionReviewerCount;
    }

    public boolean isVersionBased() {
        return versionBased;
    }

    public int getReviewerCount() {
        return reviewerCount;
    }

    public void setReviewerCount(int reviewerCount) {
        this.reviewerCount = reviewerCount;
    }

    public void setVersionBased(boolean versionBased) {
        this.versionBased = versionBased;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }

    public int getMaxStarCount() {
        return maxStarCount;
    }

    public void setMaxStarCount(int maxStarCount) {
        this.maxStarCount = maxStarCount;
    }

    public IntPairList getStarCounts() {
        return starCounts;
    }

    public void setStarCounts(IntPairList starCounts) {
        this.starCounts = starCounts;
    }

    public Map<String, IntPairList> getVersionStarCountMap() {
        return versionStarCountMap;
    }

    public void setVersionStarCountMap(Map<String, IntPairList> versionStarCountMap) {
        this.versionStarCountMap = versionStarCountMap;
    }

    public Map<String, Integer> getVersionReviewerCountMap() {
        return versionReviewerCountMap;
    }

    public void setVersionReviewerCountMap(Map<String, Integer> versionReviewerCountMap) {
        this.versionReviewerCountMap = versionReviewerCountMap;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }

}
