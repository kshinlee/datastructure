package namoo.drama.feedback.domain.proxy;

import namoo.nara.share.domain.ViewerId;

public interface EnvoyProxy {
    //
    ViewerId getViewerId();
}