package namoo.drama.feedback.domain.entity.report;

import namoo.nara.share.domain.ValueObject;
import namoo.nara.share.util.json.JsonUtil;

import java.util.ArrayList;
import java.util.List;

public class AnswerList implements ValueObject {
    //
    private List<Answer> answers;

    public AnswerList() {
        //
        this.answers = new ArrayList<>();
    }

    public AnswerList(Answer answer) {
        //
        this();
        this.answers.add(answer);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("AnswerList{");
        sb.append("answers=").append(answers);
        sb.append('}');
        return sb.toString();
    }

    public static AnswerList getSample() {
        //
        AnswerList sample = new AnswerList();
        sample.add(Answer.getSample());

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static AnswerList fromJson(String json) {
        //
        return JsonUtil.fromJson(json, AnswerList.class);
    }

    public void add(Answer answer) {
        //
        this.answers.add(answer);
    }

    public void addAll(List<Answer> answers) {
        //
        this.answers.addAll(answers);
    }

    public List<Answer> getList() {
        //
        return answers;
    }

    public Answer getFirst() {
        //
        if (answers == null || answers.isEmpty()) {
            return null;
        }

        return answers.get(0);
    }

    public Answer getLast() {
        //
        if (answers == null || answers.isEmpty()) {
            return null;
        }

        return answers.get(size()-1);
    }

    public Answer get(int sequence) {
        //
        Answer foundAnswer = null;
        for(Answer answer : this.answers) {
            if (answer.getSequence() == sequence) {
                foundAnswer = answer;
                break;
            }
        }

        return foundAnswer;
    }

    public boolean contains(int sequence) {
        //
        for(Answer answer : this.answers) {
            if (answer.getSequence() == sequence) {
                return true;
            }
        }
        return false;
    }

    public void remove(Answer answer) {
        //
        answers.remove(answer);
    }

    public int size() {
        return answers.size();
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
        System.out.println(getSample().toJson());
    }
}
