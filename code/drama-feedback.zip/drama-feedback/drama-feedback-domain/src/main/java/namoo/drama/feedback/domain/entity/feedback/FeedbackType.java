package namoo.drama.feedback.domain.entity.feedback;

public enum FeedbackType {
    //
    Reply,
    Review,
    Report
}