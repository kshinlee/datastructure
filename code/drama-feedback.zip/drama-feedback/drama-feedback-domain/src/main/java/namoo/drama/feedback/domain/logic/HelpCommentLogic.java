package namoo.drama.feedback.domain.logic;

import namoo.drama.feedback.domain.proxy.FeedbackProxyLycler;
import namoo.drama.feedback.domain.spec.front.HelpCommentService;
import namoo.drama.feedback.domain.store.FeedbackStoreLycler;
import namoo.drama.feedback.domain.store.HelpCommentStore;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
public class HelpCommentLogic implements HelpCommentService {
    //
    private HelpCommentStore helpCommentStore;

    public HelpCommentLogic(FeedbackStoreLycler storeLycler, FeedbackProxyLycler proxyLycler) {
        //
        this.helpCommentStore = storeLycler.requestHelpCommentStore();
    }

    @Override
    public void removeHelpCommentsByReviewId(String reviewId) {
        //
        helpCommentStore.deleteAllByReviewId(reviewId);
    }
}
