package namoo.drama.feedback.domain.store;

import namoo.drama.feedback.domain.entity.review.Review;
import namoo.nara.share.domain.OffsetList;

import java.util.List;

public interface ReviewStore {
    //
    void create(Review review);
    Review retrieve(String id);
    List<Review> retrieveAllByFeedbackId(String feedbackId);
    OffsetList<Review> retrieveAll(String feedbackId, String version, int offset, int limit);
    OffsetList<Review> retrieveAll(String feedbackId, int offset, int limit);
    void update(Review review);
    void delete(Review review);
    void deleteByFeedbackId(String feedbackId);

    int countAllByFeedbackId(String feedbackId);
}
