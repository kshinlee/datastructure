package namoo.drama.feedback.domain.spec.front;

import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.spec.shared.CommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReplyCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.stage.dramaspec.annotation.OptionLabel;
import namoo.nara.stage.dramaspec.annotation.RoleLabel;

@OptionLabel(
    supportEditions = {"Basic"},
    feature = "Reply"
)
@RoleLabel(names = "admin")
public interface ReplyService {
    //
    String registerReply(String feedbackId, ReplyCdo replyCdo);
    Reply findReply(String replyId);
    OffsetList<Reply> findReplies(String feedbackId, int offset, int limit);
    void modifyReply(String replyId, NameValueList nameValues);
    void removeReply(String replyId);
    int addComment(String replyId, CommentCdo commentCdo);
    void modifyComment(String replyId, int sequence, String text);
    void removeComment(String replyId, int sequence);
}
