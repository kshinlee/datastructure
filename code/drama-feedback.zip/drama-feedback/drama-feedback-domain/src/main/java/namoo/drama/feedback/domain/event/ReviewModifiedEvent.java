package namoo.drama.feedback.domain.event;

import namoo.drama.feedback.domain.entity.review.Review;
import namoo.nara.share.domain.NameValue;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.event.NaraEvent;
import namoo.nara.share.util.json.JsonUtil;
import org.springframework.beans.BeanUtils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
public class ReviewModifiedEvent implements NaraEvent {
    //
    private Review review;

    public ReviewModifiedEvent(Review review) {
        //
        this.review = review;
    }

    public Review getReview() {
        return review;
    }

    public void setReview(Review review) {
        this.review = review;
    }

    public NameValueList getNameValueList(){
        //
        if (this.review == null) return null;
        NameValueList nameValues = new NameValueList();


        Class clazz = this.review.getClass();
        for (Field field : clazz.getDeclaredFields()) {
            //
            StringBuilder sb = new StringBuilder();
            String fieldName = field.getName();

            sb.append("get");
            sb.append(fieldName.substring(0, 1).toUpperCase());
            sb.append(fieldName.substring(1));

            String methodName = sb.toString();

            try {
                Method method = clazz.getMethod(methodName, null);
                Object object = method.invoke(this.review, null);
                if (object == null) continue;
                nameValues.add(new NameValue(fieldName, isPrimitive(object) ? object.toString() : JsonUtil.toJson(object) ));
            }
            catch (NoSuchMethodException e) {
                continue;
            }
            catch (IllegalAccessException e) {
                continue;
            }
            catch (InvocationTargetException e) {
                continue;
            }
        }

        return nameValues;
    }

    private boolean isPrimitive(Object object) {
        if ((object instanceof String) || (object instanceof Integer) || (object instanceof Long) ||  (object instanceof Double) || object.getClass().isPrimitive()) {
            return true;
        }
        return false;
    }
}
