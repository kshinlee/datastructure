package namoo.drama.feedback.domain.event;

import namoo.nara.share.event.NaraEvent;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
public class ReviewSummaryChangedStarRateByStarsEvent implements NaraEvent {
    //
    private String feedbackId;
    private int oldStar;
    private int newStar;

    public ReviewSummaryChangedStarRateByStarsEvent(String feedbackId, int oldStar, int newStar) {
        //
        this.feedbackId = feedbackId;
        this.oldStar = oldStar;
        this.newStar = newStar;
    }

    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getOldStar() {
        return oldStar;
    }

    public void setOldStar(int oldStar) {
        this.oldStar = oldStar;
    }

    public int getNewStar() {
        return newStar;
    }

    public void setNewStar(int newStar) {
        this.newStar = newStar;
    }
}
