package namoo.drama.feedback.domain.entity.feedback;

import namoo.nara.share.domain.ValueObject;

public abstract class FeedbackConfig implements ValueObject {
    //
    private boolean anonymous;

    protected FeedbackConfig() {
        //
        this.anonymous = false;
    }

    protected FeedbackConfig(boolean anonymous) {
        //
        this.anonymous = anonymous;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("FeedbackConfig{");
        sb.append("anonymous=").append(anonymous);
        sb.append('}');
        return sb.toString();
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }
}
