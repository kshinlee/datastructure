package namoo.drama.feedback.domain.event;

import namoo.nara.share.event.NaraEvent;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
public class HelpCommentRemovedByReviewIdEvent implements NaraEvent {
    //
    private String reviewId;

    public HelpCommentRemovedByReviewIdEvent(String reviewId) {
        //
        this.reviewId = reviewId;
    }

    public String getReviewId() {
        return reviewId;
    }

    public void setReviewId(String reviewId) {
        this.reviewId = reviewId;
    }
}
