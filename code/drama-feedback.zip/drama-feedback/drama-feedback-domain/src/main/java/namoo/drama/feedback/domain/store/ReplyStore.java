package namoo.drama.feedback.domain.store;

import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.nara.share.domain.OffsetList;

import java.util.List;

public interface ReplyStore {
    //
    void create(Reply reply);
    Reply retrieve(String id);
    List<Reply> retrieveAllByFeedbackId(String feedbackId);
    OffsetList<Reply> retrieveAll(String feedbackId, int offset, int limit);
    void update(Reply reply);
    void delete(Reply reply);
    void deleteByFeedbackId(String feedbackId);
}
