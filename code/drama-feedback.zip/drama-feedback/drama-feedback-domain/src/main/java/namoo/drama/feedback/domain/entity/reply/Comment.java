package namoo.drama.feedback.domain.entity.reply;

import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.ValueObject;
import namoo.nara.share.util.json.JsonUtil;

public class Comment implements ValueObject {
	//
	public static final int MAX_SEQUENCE = 25;

	private int sequence;
	private String text;
	private Actor writer;
	private Long time;

	public Comment(int sequence, Actor writer, String text) {
		//
		this.sequence = sequence;
		this.text = text;
		this.writer = writer;
		this.time = System.currentTimeMillis();
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("Comment{");
		sb.append("sequence=").append(sequence);
		sb.append(", text='").append(text).append('\'');
		sb.append(", writer=").append(writer);
		sb.append(", time=").append(time);
		sb.append('}');
		return sb.toString();
	}

	public static Comment getSample() {
		//
		int sequence = 1;
		Actor writer = Actor.getSample();
		String text = "참 좋은 의견입니다. 저녁에 한 잔 해요.";

		Comment sample = new Comment(sequence, writer, text);
		return sample;
	}

	public String toJson() {
		//
		return JsonUtil.toJson(this);
	}

	public static Comment fromJson(String json) {
		//
		return JsonUtil.fromJson(json, Comment.class);
	}

	public static int getMaxSequence() {
		return MAX_SEQUENCE;
	}

	public int getSequence() {
		return sequence;
	}

	public void setSequence(int sequence) {
		this.sequence = sequence;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Actor getWriter() {
		return writer;
	}

	public void setWriter(Actor writer) {
		this.writer = writer;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

	public static void main(String[] args) {
		//
		System.out.println(getSample());
	}
}