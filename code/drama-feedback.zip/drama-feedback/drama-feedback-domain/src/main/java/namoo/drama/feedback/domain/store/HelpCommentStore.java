package namoo.drama.feedback.domain.store;

import namoo.drama.feedback.domain.entity.review.HelpComment;
import namoo.nara.share.domain.IntPair;
import namoo.nara.share.domain.OffsetList;

public interface HelpCommentStore {
    //
    void create(HelpComment helpComment);
    HelpComment retrieve(String id);
    HelpComment retrieve(String reviewId, String reviewerId);
    OffsetList<HelpComment> retrieveAll(String reviewId, int offset, int  limit);
    void update(HelpComment helpComment);
    void delete(HelpComment helpComment);
    void deleteAllByReviewId(String reviewId);

    int countByReviewId(String reviewId);
}
