package namoo.drama.feedback.domain.spec.front;

import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.drama.feedback.domain.spec.shared.HelpCommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReviewCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.stage.dramaspec.annotation.OptionLabel;
import namoo.nara.stage.dramaspec.annotation.RoleLabel;

@OptionLabel(
    supportEditions = {"Basic"},
    feature = "Review"
)
@RoleLabel(names = "admin")
public interface ReviewService {
    //
    String registerReview(String feedbackId, ReviewCdo reviewCdo);
    String registerVersionedReview(String feedbackId, String version, ReviewCdo reviewCdo);
    Review findReview(String reviewId);
    OffsetList<Review> findReviews(String feedbackId, int offset, int limit);
    OffsetList<Review> findReviews(String feedbackId, String version, int offset, int limit);
    void modifyReview(String reviewId, NameValueList nameValues);
    void addHelpComment(String reviewId, HelpCommentCdo helpCommentCdo);
    void removeHelpComment(String helpCommentId);
    void removeHelpComment(String reviewId, String reviewerId);
    void removeReview(String reviewId);

    ReviewSummary findReviewSummary(String feedbackId);
}
