package namoo.drama.feedback.domain.spec.drama;

public interface ReportProvider {
}
