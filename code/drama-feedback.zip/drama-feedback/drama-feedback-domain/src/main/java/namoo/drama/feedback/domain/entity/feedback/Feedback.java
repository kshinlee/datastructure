package namoo.drama.feedback.domain.entity.feedback;

import namoo.drama.feedback.domain.entity.reply.ReplyConfig;
import namoo.drama.feedback.domain.entity.review.ReviewConfig;
import namoo.nara.share.domain.*;
import namoo.nara.share.util.json.JsonUtil;
import namoo.nara.share.util.string.StringUtil;

public class Feedback extends Entity implements Aggregate {
	//
	private String title;
	private Informant informant;
	private FeedbackType type;
	private FeedbackConfig config;
	private Long time;

	public Feedback(String id) {
		//
		super(id);
	}

	private Feedback(String title, Informant informant) {
		//
		super();
		this.title = title;
		this.informant = informant;
		this.time = System.currentTimeMillis();
	}

	public static Feedback newReplyFeedback(String title, Informant informant) {
		//
		Feedback feedback = new Feedback(title, informant);
		feedback.setType(FeedbackType.Reply);
		feedback.setConfig(new ReplyConfig());
		return feedback;
	}

	public static Feedback newReviewFeedback(String title, Informant informant) {
		//
		Feedback feedback = new Feedback(title, informant);
		feedback.setType(FeedbackType.Review);
		feedback.setConfig(new ReviewConfig());

		return feedback;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("Feedback{");
		sb.append("title='").append(title).append('\'');
		sb.append(", informant=").append(informant);
		sb.append(", config=").append(config);
		sb.append(", time=").append(time);
		sb.append('}');
		return sb.toString();
	}

	public static Feedback getSample() {
		//
		String title = "수강생의 의견";
		Informant informant = Informant.getSample();
		Feedback sample = Feedback.newReplyFeedback(title, informant);

		return sample;
	}

	public String toJson() {
		//
		return JsonUtil.toJson(this);
	}

	public static Feedback fromJson(String json) {
		//
		return JsonUtil.fromJson(json, Feedback.class);
	}

	public void setValues(NameValueList nameValues) {
		//
        if (nameValues == null || nameValues.size() == 0) return;
        for(NameValue nameValue : nameValues.getList()) {
            String name = nameValue.getName();
            String value = nameValue.getValue();
            if (StringUtil.isEmpty(value)) continue;
			switch(name) {
				case "title":     	this.title = value; break;
				case "informant": 	this.informant = Informant.fromJson(value); break;
				case "config":
					switch(type) {
						case Review: 	this.config = ReviewConfig.fromJson(value); break;
						case Reply: 	this.config = ReplyConfig.fromJson(value); break;
					}
					break;
			}
		}
	}

	public FeedbackType getType() {
		return type;
	}

	public void setType(FeedbackType type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

	public Informant getInformant() {
		return informant;
	}

	public void setInformant(Informant informant) {
		this.informant = informant;
	}

	public FeedbackConfig getConfig() {
		return config;
	}

	public void setConfig(FeedbackConfig config) {
		this.config = config;
	}

	public static void main(String[] args) {
		//
		System.out.println(getSample());
	}
}
