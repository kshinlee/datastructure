package namoo.drama.feedback.domain.spec.shared;

import namoo.nara.share.domain.Informant;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.util.json.JsonUtil;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-11
 */
public class FeedbackCdo {
    //
    private Informant informant;
    private String title;

    private NameValueList nameValues;

    public FeedbackCdo() {

    }

    public FeedbackCdo(Informant informant, String title) {
        this.informant = informant;
        this.title = title;
        this.nameValues = null;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReplyCdo{");
        sb.append("informant=").append(informant.toString());
        sb.append(", title='").append(title).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static FeedbackCdo getSample() {
        //
        Informant informant = Informant.getSample();
        String title = "Feedback Sample";

        FeedbackCdo sample = new FeedbackCdo(informant, title);

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static ReplyCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ReplyCdo.class);
    }

    public boolean hasNameValues() {
        //
        if(nameValues != null) {
            return true;
        }

        return false;
    }

    public NameValueList getNameValues() {
        return nameValues;
    }

    public void setNameValues(NameValueList nameValues) {
        this.nameValues = nameValues;
    }

    public Informant getInformant() {
        return informant;
    }

    public void setInformant(Informant informant) {
        this.informant = informant;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
