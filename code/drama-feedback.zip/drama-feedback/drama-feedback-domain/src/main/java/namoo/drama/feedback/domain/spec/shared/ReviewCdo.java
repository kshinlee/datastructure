package namoo.drama.feedback.domain.spec.shared;

import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.util.json.JsonUtil;

public class ReviewCdo {
    //
    private Actor writer;
    private String title;
    private String opinion;
    private int selectedStar;

    private NameValueList nameValues;

    public ReviewCdo() {

    }

    public ReviewCdo(Actor writer, String title, String opinion, int selectedStar) {
        //
        this.writer = writer;
        this.title = title;
        this.opinion = opinion;
        this.selectedStar = selectedStar;
        this.nameValues = null;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReviewCdo{");
        sb.append("writer=").append(writer);
        sb.append(", title='").append(title).append('\'');
        sb.append(", opinion='").append(opinion).append('\'');
        sb.append(", selectedStar=").append(selectedStar);
        sb.append('}');
        return sb.toString();
    }

    public static ReviewCdo getSample() {
        //
        Actor writer = Actor.getSample();
        String title = "열흘 사용 후 솔직한 생각";
        String opinion = "구매할 경우 두 배로 신중하게 생각하세요 ";
        int selectedStar = 3;

        ReviewCdo sample = new ReviewCdo(writer, title, opinion, selectedStar);
        sample.setNameValues(new NameValueList().add("version", "v1.1.2"));

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static ReviewCdo fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ReviewCdo.class);
    }

    public boolean hasNameValues() {
        //
        if(nameValues != null) {
            return true;
        }

        return false;
    }

    public NameValueList getNameValues() {
        return nameValues;
    }

    public void setNameValues(NameValueList nameValues) {
        this.nameValues = nameValues;
    }

    public Actor getWriter() {
        return writer;
    }

    public void setWriter(Actor writer) {
        this.writer = writer;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOpinion() {
        return opinion;
    }

    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }

    public int getSelectedStar() {
        return selectedStar;
    }

    public void setSelectedStar(int selectedStar) {
        this.selectedStar = selectedStar;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
