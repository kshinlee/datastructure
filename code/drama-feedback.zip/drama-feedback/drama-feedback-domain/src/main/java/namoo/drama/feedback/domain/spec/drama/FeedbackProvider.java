package namoo.drama.feedback.domain.spec.drama;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.spec.shared.FeedbackCdo;
import namoo.nara.share.domain.NameValueList;

public interface FeedbackProvider {
    //
    String registerReplyFeedback(FeedbackCdo feedbackCdo);
    String registerReviewFeedback(FeedbackCdo feedbackCdo);
    Feedback findFeedback(String feedbackId);
    void makeAnonymous(String feedbackId);
    void modifyFeedback(String feedbackId, NameValueList nameValues);
    void removeReplyFeedback(String feedbackId);
    void removeReviewFeedback(String feedbackId);
}
