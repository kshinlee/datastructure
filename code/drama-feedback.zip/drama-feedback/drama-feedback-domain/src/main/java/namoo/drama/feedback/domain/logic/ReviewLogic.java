package namoo.drama.feedback.domain.logic;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import namoo.drama.feedback.domain.entity.review.HelpComment;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.entity.review.ReviewConfig;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.drama.feedback.domain.event.*;
import namoo.drama.feedback.domain.proxy.FeedbackProxyLycler;
import namoo.drama.feedback.domain.spec.drama.ReviewProvider;
import namoo.drama.feedback.domain.spec.front.ReviewService;
import namoo.drama.feedback.domain.spec.shared.HelpCommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReviewCdo;
import namoo.drama.feedback.domain.store.*;
import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.event.NaraEventProxy;

import java.util.NoSuchElementException;

public class ReviewLogic implements ReviewProvider, ReviewService {
    //
    private FeedbackStore feedbackStore;
    private ReviewStore reviewStore;
    private ReviewSummaryStore reviewSummaryStore;
    private HelpCommentStore helpCommentStore;

    private NaraEventProxy eventProxy;

    public ReviewLogic(FeedbackStoreLycler storeLycler, FeedbackProxyLycler proxyLycler) {
        //
        this.feedbackStore = storeLycler.requestFeedbackStore();
        this.reviewStore = storeLycler.requestReviewStore();
        this.reviewSummaryStore = storeLycler.requestReviewSummaryStore();
        this.helpCommentStore = storeLycler.requestHelpCommentStore();

        this.eventProxy = proxyLycler.requestEventProxy();
    }

    @Override
    public String registerReview(String feedbackId, ReviewCdo reviewCdo) {
        //
        Review review = this.buildReview(feedbackId, reviewCdo);
        if(reviewCdo.hasNameValues()) {
            review.setValues(reviewCdo.getNameValues());
        }

        reviewStore.create(review);
        eventProxy.create(new ReviewSummaryChangedStarRateEvent(feedbackId, reviewCdo.getSelectedStar(), true));

        return review.getId();
    }

    @Override
    public String registerVersionedReview(String feedbackId, String version, ReviewCdo reviewCdo) {
        //
        Review review = this.buildReview(feedbackId, reviewCdo);
        review.setVersion(version);
        reviewStore.create(review);
        eventProxy.create(new VersionedReviewSummaryChangedStarRateEvent(feedbackId, version, reviewCdo.getSelectedStar(), true));

        return review.getId();
    }

    @Override
    public Review findReview(String reviewId) {
        //
        return reviewStore.retrieve(reviewId);
    }

    @Override
    public OffsetList<Review> findReviews(String feedbackId, int offset, int limit) {
        //
        return reviewStore.retrieveAll(feedbackId, offset, limit);
    }

    @Override
    public OffsetList<Review> findReviews(String feedbackId, String version, int offset, int limit) {
        //
        return reviewStore.retrieveAll(feedbackId, version, offset, limit);
    }

    @Override
    public void modifyReview(String reviewId, NameValueList nameValues) {
        //
        Review review = requestReview(reviewId);
        String selectedStar = "selectedStar";

        if(nameValues.containsName(selectedStar)) {
            String feedbackId = review.getFeedbackId();
            int oldStar = review.getSelectedStar();
            String newStarStr = nameValues.getValueOf(selectedStar);
            if(newStarStr != null) {
                int newStar = Integer.valueOf(newStarStr);

                if (review.isVersioned()) {
                    eventProxy.create(new VersionedReviewSummaryChangedStarRateByStarsEvent(feedbackId, review.getVersion(), oldStar, newStar));
                } else {
                    eventProxy.create(new ReviewSummaryChangedStarRateByStarsEvent(feedbackId, oldStar, newStar));
                }
            }
        }

        review.setValues(nameValues);
        reviewStore.update(review);
    }

    @Override
    public void addHelpComment(String reviewId, HelpCommentCdo helpCommentCdo) {
        //
        String reviewerId = helpCommentCdo.getReviewerId();
        boolean helpful = helpCommentCdo.isHelpful();
        HelpComment helpComment = helpCommentStore.retrieve(reviewId, reviewerId);
        if(helpComment != null && (helpComment.isHelpful() == helpful)) {
            return;
        }

        Review review = requestReview(reviewId);

        if(helpComment == null) {
            helpComment = new HelpComment(reviewId, reviewerId, helpful);
            helpCommentStore.create(helpComment);
            if(helpful) {
                review.getHelpCount().increaseLeft();
            }
            review.getHelpCount().increaseRight();
        } else {
            if(helpComment.isHelpful() != helpful) {
                if(helpful) {
                    review.getHelpCount().increaseLeft();
                } else {
                    review.getHelpCount().decreaseLeft();
                }
                helpComment.setHelpful(helpful);
                helpCommentStore.update(helpComment);
            }
        }


        eventProxy.create(new ReviewModifiedEvent(review));
    }

    @Override
    public void removeHelpComment(String helpCommentId) {
        //
        HelpComment helpComment = helpCommentStore.retrieve(helpCommentId);
        if(helpComment == null) {
            throw new NoSuchElementException("HelpCommentId:" + helpCommentId);
        }

        this.decreaseHelpCount(helpComment.getReviewId(), helpComment.isHelpful());
        helpCommentStore.delete(helpComment);
    }

    @Override
    public void removeHelpComment(String reviewId, String reviewerId) {
        //
        HelpComment helpComment = helpCommentStore.retrieve(reviewId, reviewerId);
        if(helpComment == null) {
            throw new NoSuchElementException("ReviewId:" + reviewId + ", ReviewerId:" + reviewerId);
        }

        this.decreaseHelpCount(helpComment.getReviewId(), helpComment.isHelpful());
        helpCommentStore.delete(helpComment);
    }

    @Override
    public void removeReview(String reviewId) {
        //
        Review review = requestReview(reviewId);
        String feedbackId = review.getFeedbackId();
        int selectedStar = review.getSelectedStar();
        boolean increase = true;
        if (review.isVersioned()) {
            eventProxy.create(new VersionedReviewSummaryChangedStarRateEvent(feedbackId, review.getVersion(), selectedStar, !increase));
        } else {
            eventProxy.create(new ReviewSummaryChangedStarRateEvent(feedbackId, selectedStar, !increase));
        }

        eventProxy.create(new HelpCommentRemovedByReviewIdEvent(reviewId));
        reviewStore.delete(review);
    }

    @Override
    public ReviewSummary findReviewSummary(String feedbackId) {
        //
        Feedback feedback = feedbackStore.retrieve(feedbackId);
        if(!feedback.getType().equals(FeedbackType.Review)) {
            throw new IllegalArgumentException("Not review type feedback.");
        }

        ReviewSummary reviewSummary =reviewSummaryStore.retrieve(feedbackId);

        if (reviewSummary == null) {
            ReviewConfig reviewConfig = (ReviewConfig)feedback.getConfig();
            reviewSummary = new ReviewSummary(feedbackId, reviewConfig);
            reviewSummaryStore.create(reviewSummary);
        }

        return reviewSummary;
    }

    private Review buildReview(String feedbackId, ReviewCdo reviewCdo) {
        //
        Feedback feedback = feedbackStore.retrieve(feedbackId);
        if (feedback == null) {
            throw new NoSuchElementException("feedback id: " + feedbackId);
        }

        Actor writer = reviewCdo.getWriter();
        String title = reviewCdo.getTitle();
        String opinion = reviewCdo.getOpinion();
        int selectedStar = reviewCdo.getSelectedStar();

        Review review = new Review(writer, title, opinion, selectedStar, feedbackId);

        return review;
    }

    private Review requestReview(String reviewId) {
        //
        Review review = reviewStore.retrieve(reviewId);
        if (review == null) {
            throw new NoSuchElementException("review id: " + reviewId);
        }

        return review;
    }

    private void decreaseHelpCount(String reviewId, boolean isHelpful) {
        //
        if(isHelpful) {
            Review review = reviewStore.retrieve(reviewId);
            if (review == null) {
                throw new NoSuchElementException("ReviewId:" + reviewId);
            }
            review.getHelpCount().decreaseLeft();
            eventProxy.create(new ReviewModifiedEvent(review));
        }
    }

}
