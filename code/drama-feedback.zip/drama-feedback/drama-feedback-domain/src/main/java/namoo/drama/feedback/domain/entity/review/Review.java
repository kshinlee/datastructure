package namoo.drama.feedback.domain.entity.review;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.nara.share.domain.*;
import namoo.nara.share.util.json.JsonUtil;
import namoo.nara.share.util.string.StringUtil;

public class Review extends Entity implements Aggregate {
    //
    private String version;
    private Actor writer;
    private String title;
    private String opinion;
    private int selectedStar;
    private Long time;
    private IntPair helpCount;          // helpful/total

    private String feedbackId;

    public Review(String id) {
        //
        super(id);
    }

    public Review(Actor writer, String title, String opinion, int selectedStar, String feedbackId) {
        //
        super();
        this.version = null;              // default
        this.writer = writer;
        this.title = title;
        this.opinion = opinion;
        this.selectedStar = selectedStar;
        this.time = System.currentTimeMillis();
        this.helpCount = new IntPair(0, 0);
        this.feedbackId = feedbackId;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Review{");
        sb.append("version=").append(version);
        sb.append(", writer=").append(writer);
        sb.append(", title='").append(title).append('\'');
        sb.append(", opinion='").append(opinion).append('\'');
        sb.append(", selectedStar=").append(selectedStar);
        sb.append(", time=").append(time);
        sb.append(", helpCount=").append(helpCount);
        sb.append(", feedbackId='").append(feedbackId).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static Review getSample() {
        //
        Actor writer = Actor.getSample();
        String title = "지극히 개인적인 의견입니다";
        String opinion = "이 제품은 장점과 단점이 아주 명확합니다.";
        int starRate = 3;
        String feedbackId = Feedback.getSample().getId();

        Review sample = new Review(writer, title, opinion, starRate, feedbackId);
        sample.increaseHelpCount();
        sample.increaseHelpCount();
        sample.increaseHelpCount();

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static Review fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Review.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        if (nameValues == null || nameValues.size() == 0) return;
        for(NameValue nameValue : nameValues.getList()) {
            String name = nameValue.getName();
            String value = nameValue.getValue();
            if (StringUtil.isEmpty(value)) continue;
            switch(name) {
                case "version":         this.version = value; break;
                case "title":           this.title = value; break;
                case "opinion":         this.opinion = value; break;
                case "selectedStar":    this.selectedStar = Integer.valueOf(value); break;
                case "helpCount":       this.helpCount = JsonUtil.fromJson(value, IntPair.class); break;
            }
        }
    }

    public void increaseHelpCount() {
        //
        helpCount.increaseLeft();
        helpCount.increaseRight();
    }

    public void decreaseHelpCount() {
        //
        helpCount.decreaseRight();
        helpCount.increaseLeft();
    }

    public boolean isVersioned() {
        //
        if(version != null) {
            return true;
        }

        return false;
    }

    public Actor getWriter() {
        return writer;
    }

    public void setWriter(Actor writer) {
        this.writer = writer;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOpinion() {
        return opinion;
    }

    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }

    public int getSelectedStar() {
        return selectedStar;
    }

    public void setSelectedStar(int selectedStar) {
        this.selectedStar = selectedStar;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public IntPair getHelpCount() {
        return helpCount;
    }

    public void setHelpCount(IntPair helpCount) {
        this.helpCount = helpCount;
    }

    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
