package namoo.drama.feedback.domain.logic.shared;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.entity.review.ReviewConfig;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.drama.feedback.domain.proxy.FeedbackProxyLycler;
import namoo.drama.feedback.domain.spec.shared.ReviewCdo;
import namoo.drama.feedback.domain.store.FeedbackStore;
import namoo.drama.feedback.domain.store.FeedbackStoreLycler;
import namoo.drama.feedback.domain.store.ReviewSummaryStore;
import namoo.nara.share.domain.Actor;

import java.util.NoSuchElementException;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
public class ReviewSummaryEventHelper {
    //
    private FeedbackStore feedbackStore;
    private ReviewSummaryStore reviewSummaryStore;

    public ReviewSummaryEventHelper(FeedbackStoreLycler storeLycler, FeedbackProxyLycler proxyLycler) {
        //
        this.feedbackStore = storeLycler.requestFeedbackStore();
        this.reviewSummaryStore = storeLycler.requestReviewSummaryStore();
    }

    public void changeStarRateInVersionedReviewSummary(String feedbackId, String version, int selectedStar, boolean increased) {
        //
        ReviewSummary reviewSummary = this.findReviewSummary(feedbackId);

        if (increased) {
            reviewSummary.increase(selectedStar, version);
        } else {
            reviewSummary.decrease(selectedStar, version);
        }
        reviewSummaryStore.update(reviewSummary);
    }

    public void changeStarRateInVersionedReviewSummary(String feedbackId, String version, int oldStar, int newStar) {
        //
        ReviewSummary reviewSummary = this.findReviewSummary(feedbackId);

        reviewSummary.increase(newStar, version);
        reviewSummary.decrease(oldStar, version);
        reviewSummaryStore.update(reviewSummary);
    }


    public void changeStarRateInReviewSummary(String feedbackId, int selectedStar, boolean increased) {
        //
        ReviewSummary reviewSummary = this.findReviewSummary(feedbackId);

        if (increased) {
            reviewSummary.increase(selectedStar);
        } else {
            reviewSummary.decrease(selectedStar);
        }

        reviewSummaryStore.update(reviewSummary);
    }

    public void changeStarRateInReviewSummary(String feedbackId, int oldStar, int newStar) {
        //
        ReviewSummary reviewSummary = this.findReviewSummary(feedbackId);

        reviewSummary.increase(newStar);
        reviewSummary.decrease(oldStar);
        reviewSummaryStore.update(reviewSummary);
    }

    private ReviewSummary findReviewSummary(String feedbackId) {
        //
        Feedback feedback = feedbackStore.retrieve(feedbackId);
        if(!FeedbackType.Review.equals(feedback.getType())) {
            throw new IllegalArgumentException("Not review type feedback.");
        }

        ReviewSummary reviewSummary =reviewSummaryStore.retrieve(feedbackId);

        if (reviewSummary == null) {
            ReviewConfig reviewConfig = (ReviewConfig)feedback.getConfig();
            reviewSummary = new ReviewSummary(feedbackId, reviewConfig);
            reviewSummaryStore.create(reviewSummary);
        }

        return reviewSummary;
    }
}
