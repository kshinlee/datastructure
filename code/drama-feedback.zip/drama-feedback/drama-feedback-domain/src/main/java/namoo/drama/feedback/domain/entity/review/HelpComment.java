package namoo.drama.feedback.domain.entity.review;

import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.Entity;
import namoo.nara.share.util.json.JsonUtil;

public class HelpComment extends Entity {
    //
    private boolean anonymous;
    private String reviewerId;
    private boolean helpful;
    private Long time;

    private String reviewId;

    public HelpComment(String id) {
        //
        super(id);
    }

    public HelpComment(String reviewId, boolean helpful) {
        //
        super();
        this.anonymous = true;
        this.reviewId = reviewId;
        this.reviewerId = null;
        this.helpful = helpful;
        this.time = System.currentTimeMillis();
    }

    public HelpComment(String reviewId, String reviewerId, boolean helpful) {
        //
        super();
        this.anonymous = false;
        this.reviewId = reviewId;
        this.reviewerId = reviewerId;
        this.helpful = helpful;
        this.time = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("HelpComment{");
        sb.append(super.toString());
        sb.append(", anonymous=").append(anonymous);
        sb.append(", reviewId='").append(reviewId).append('\'');
        sb.append(", reviewerId='").append(reviewerId).append('\'');
        sb.append(", helpful=").append(helpful);
        sb.append(", time=").append(time);
        sb.append('}');
        return sb.toString();
    }

    public static HelpComment getSample() {
        //
        String reviewId = Review.getSample().getId();
        String reviewerId = Actor.getSample().getId();
        boolean helpful = true;

        HelpComment sample = new HelpComment(reviewId, reviewerId, helpful);

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static HelpComment fromJson(String json) {
        //
        return JsonUtil.fromJson(json, HelpComment.class);
    }

    public boolean isAnonymous() {
        return anonymous;
    }

    public void setAnonymous(boolean anonymous) {
        this.anonymous = anonymous;
    }

    public String getReviewId() {
        return reviewId;
    }

    public void setReviewId(String reviewId) {
        this.reviewId = reviewId;
    }

    public String getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(String reviewerId) {
        this.reviewerId = reviewerId;
    }

    public boolean isHelpful() {
        return helpful;
    }

    public void setHelpful(boolean helpful) {
        this.helpful = helpful;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
