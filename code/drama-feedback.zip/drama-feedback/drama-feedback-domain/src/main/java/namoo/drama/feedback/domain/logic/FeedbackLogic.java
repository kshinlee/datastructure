package namoo.drama.feedback.domain.logic;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.entity.review.ReviewConfig;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.drama.feedback.domain.proxy.FeedbackProxyLycler;
import namoo.drama.feedback.domain.spec.drama.FeedbackProvider;
import namoo.drama.feedback.domain.spec.front.FeedbackService;
import namoo.drama.feedback.domain.spec.shared.FeedbackCdo;
import namoo.drama.feedback.domain.store.*;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.domain.ScreenId;

import java.util.List;
import java.util.NoSuchElementException;

public class FeedbackLogic implements FeedbackProvider, FeedbackService {
    //
    private FeedbackStore feedbackStore;
    private ReplyStore replyStore;
    private ReviewStore reviewStore;
    private ReviewSummaryStore reviewSummaryStore;

    public FeedbackLogic(FeedbackStoreLycler storeLycler, FeedbackProxyLycler proxyLycler) {
        //
        this.feedbackStore = storeLycler.requestFeedbackStore();
        this.replyStore = storeLycler.requestReplyStore();
        this.reviewStore = storeLycler.requestReviewStore();
        this.reviewSummaryStore = storeLycler.requestReviewSummaryStore();
    }

    @Override
    public String registerReplyFeedback(FeedbackCdo feedbackCdo) {
        //
        Feedback feedback = Feedback.newReplyFeedback(feedbackCdo.getTitle(), feedbackCdo.getInformant());
        feedbackStore.create(feedback);

        return feedback.getId();
    }

    @Override
    public String registerReviewFeedback(FeedbackCdo feedbackCdo) {
        //
        Feedback feedback = Feedback.newReviewFeedback(feedbackCdo.getTitle(), feedbackCdo.getInformant());
        feedbackStore.create(feedback);

        ReviewConfig reviewConfig = (ReviewConfig)feedback.getConfig();
        ReviewSummary reviewSummary = new ReviewSummary(feedback.getId(), reviewConfig);
        reviewSummaryStore.create(reviewSummary);

        return feedback.getId();
    }

    @Override
    public Feedback findFeedback(String feedbackId) {
        //
        return feedbackStore.retrieve(feedbackId);
    }

    @Override
    public OffsetList<Feedback> findFeedback(String pavilionId, int offset, int limit) {
        //
        return feedbackStore.retrieveAllByPavilionId(pavilionId, offset, limit);
    }

    @Override
    public OffsetList<Feedback> findFeedbackByCineroomId(String pavilionId, String cineroomId, int offset, int limit) {
        //
        return feedbackStore.retrieveAllByPavilionIdAndCineroomId(pavilionId, cineroomId, offset, limit);
    }

    @Override
    public OffsetList<Feedback> findFeedback(ScreenId screenId, int offset, int limit) {
        //
        return feedbackStore.retrieveAllByScreenId(screenId, offset, limit);
    }

    @Override
    public OffsetList<Feedback> findFeedbackByDramaId(String pavilionId, String dramaId, int offset, int limit) {
        //
        return feedbackStore.retrieveAllByPavilionIdAndDramaId(pavilionId, dramaId, offset, limit);
    }

    @Override
    public void makeAnonymous(String feedbackId) {
        //
        Feedback feedback = requestFeedback(feedbackId);

        feedback.getConfig().setAnonymous(true);

        feedbackStore.update(feedback);
    }

    @Override
    public void modifyFeedback(String feedbackId, NameValueList nameValues) {
        //
        Feedback feedback = requestFeedback(feedbackId);
        feedback.setValues(nameValues);

        if (feedback.getType().equals(FeedbackType.Review)) {
            ReviewSummary reviewSummary = reviewSummaryStore.retrieve(feedbackId);
            reviewSummary.setValues((ReviewConfig)feedback.getConfig());
            reviewSummaryStore.update(reviewSummary);
        }

        feedbackStore.update(feedback);
    }


    @Override
    public void removeReplyFeedback(String feedbackId) {
        //
        Feedback feedback = requestFeedback(feedbackId);
        replyStore.deleteByFeedbackId(feedbackId);
        feedbackStore.delete(feedbackId);
    }

    @Override
    public void removeReviewFeedback(String feedbackId) {
        //
        Feedback feedback = requestFeedback(feedbackId);
        reviewStore.deleteByFeedbackId(feedbackId);
        feedbackStore.delete(feedbackId);
    }

    private Feedback requestFeedback(String feedbackId) {
        //
        Feedback feedback = feedbackStore.retrieve(feedbackId);
        if(feedback == null) {
            throw new NoSuchElementException("feedback id: " + feedbackId);
        }

        return feedback;
    }
}
