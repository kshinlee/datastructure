package namoo.drama.feedback.domain.spec.front;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.spec.shared.FeedbackCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.domain.ScreenId;
import namoo.nara.stage.dramaspec.annotation.OptionLabel;
import namoo.nara.stage.dramaspec.annotation.RoleLabel;

@OptionLabel(
    supportEditions = {"Basic"},
    feature = "Feedback"
)
@RoleLabel(names = "admin")
public interface FeedbackService {
    //
    String registerReplyFeedback(FeedbackCdo feedbackCdo);
    String registerReviewFeedback(FeedbackCdo feedbackCdo);
    Feedback findFeedback(String feedbackId);
    OffsetList<Feedback> findFeedback(String pavilionId, int offset, int limit);
    OffsetList<Feedback> findFeedbackByCineroomId(String pavilionId, String cineroomId, int offset, int limit);
    OffsetList<Feedback> findFeedback(ScreenId screenId, int offset, int limit);
    OffsetList<Feedback> findFeedbackByDramaId(String pavilionId, String dramaId, int offset, int limit);
    void modifyFeedback(String feedbackId, NameValueList nameValues);
}
