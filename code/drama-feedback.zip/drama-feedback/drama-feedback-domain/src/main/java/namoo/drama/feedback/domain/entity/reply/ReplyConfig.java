package namoo.drama.feedback.domain.entity.reply;

import namoo.drama.feedback.domain.entity.feedback.FeedbackConfig;
import namoo.nara.share.util.json.JsonUtil;

public class ReplyConfig extends FeedbackConfig {
    //
    private boolean commentAllowed;

    public ReplyConfig() {
        //
        super();
        this.commentAllowed = true;
    }

    public ReplyConfig(boolean anonymous) {
        //
        super(anonymous);
        this.commentAllowed = true;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ReplyConfig{");
        sb.append(super.toString());
        sb.append("commentAllowed=").append(commentAllowed);
        sb.append('}');
        return sb.toString();
    }

    public static ReplyConfig getSample() {
        //
        return new ReplyConfig();
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static ReplyConfig fromJson(String json) {
        //
        return JsonUtil.fromJson(json, ReplyConfig.class);
    }

    public boolean isCommentAllowed() {
        return commentAllowed;
    }

    public void setCommentAllowed(boolean commentAllowed) {
        this.commentAllowed = commentAllowed;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}