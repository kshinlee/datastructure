package namoo.drama.feedback.domain.store;

public interface FeedbackStoreLycler {
    //
    FeedbackStore requestFeedbackStore();
    ReplyStore requestReplyStore();
    ReviewStore requestReviewStore();
    ReviewSummaryStore requestReviewSummaryStore();
    HelpCommentStore requestHelpCommentStore();
}
