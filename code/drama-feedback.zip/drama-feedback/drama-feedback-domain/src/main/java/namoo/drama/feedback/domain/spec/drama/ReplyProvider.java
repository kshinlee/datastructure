package namoo.drama.feedback.domain.spec.drama;

import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.spec.shared.CommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReplyCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;

public interface ReplyProvider {
    //
    String registerReply(String feedbackId, ReplyCdo replyCdo);
    Reply findReply(String replyId);
    OffsetList<Reply> findReplies(String feedbackId, int offset, int limit);
    void modifyReply(String replyId, NameValueList nameValues);
    void removeReply(String replyId);
    int addComment(String replyId, CommentCdo commentCdo);
    void modifyComment(String replyId, int sequence, String text);
    void removeComment(String replyId, int sequence);
}
