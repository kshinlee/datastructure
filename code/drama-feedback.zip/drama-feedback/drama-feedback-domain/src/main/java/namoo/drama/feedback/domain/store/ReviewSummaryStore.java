package namoo.drama.feedback.domain.store;

import namoo.drama.feedback.domain.entity.review.ReviewSummary;

public interface ReviewSummaryStore {
    //
    void create(ReviewSummary reviewSummary);
    ReviewSummary retrieve(String id);
    void update(ReviewSummary reviewSummary);
    void delete(String id);
}
