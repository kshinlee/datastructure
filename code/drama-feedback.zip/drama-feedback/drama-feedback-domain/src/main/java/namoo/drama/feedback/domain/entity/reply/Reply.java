package namoo.drama.feedback.domain.entity.reply;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.nara.share.domain.*;
import namoo.nara.share.exception.ValueOutOfBoundsException;
import namoo.nara.share.util.json.JsonUtil;
import namoo.nara.share.util.string.StringUtil;

public class Reply extends Entity implements Aggregate {
	//
	private Actor writer;				// anonymous --> temp id : password
	private String text;
	private int commentSequence;

	private CommentList comments;
	private Long time;
	private String feedbackId;

	public Reply(String id) {
		//
		super(id);
	}

	public Reply(Actor writer, String text, String feedbackId) {
		//
		super();
		this.writer = writer;
		this.text = text;
		this.commentSequence = 0;
		this.comments = new CommentList();
		this.time = System.currentTimeMillis();
		this.feedbackId = feedbackId;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("Reply{");
		sb.append("writer=").append(writer);
		sb.append(", text='").append(text).append('\'');
		sb.append(", commentSequence=").append(commentSequence);
		sb.append(", comments=").append(comments);
		sb.append(", time=").append(time);
		sb.append(", feedbackId='").append(feedbackId).append('\'');
		sb.append('}');
		return sb.toString();
	}

	public static Reply getSample() {
		//
		Actor writer = Actor.getSample();
		String text = "It's great.";
		String feedbackId = Feedback.getSample().getId();

		Reply sample = new Reply(writer, text, feedbackId);

		return sample;
	}

	public String toJson() {
		//
		return JsonUtil.toJson(this);
	}

	public static Reply fromJson(String json) {
		//
		return JsonUtil.fromJson(json, Reply.class);
	}

	public void setValues(NameValueList nameValues) {
		//
        if (nameValues == null || nameValues.size() == 0) return;
        for(NameValue nameValue : nameValues.getList()) {
            String name = nameValue.getName();
            String value = nameValue.getValue();
            if (StringUtil.isEmpty(value)) continue;
			switch(name) {
				case "text":     	this.text = value; break;
                case "comments":    this.comments = CommentList.fromJson(value); break;
			}
		}
	}

	public int nextCommentSequence() {
		//
		commentSequence++;
		if(comments.size() >= Comment.MAX_SEQUENCE) {
			throw new ValueOutOfBoundsException("max sequence is " + Comment.MAX_SEQUENCE + ", but it's " + commentSequence);
		}

		return commentSequence++;
	}

	public Actor getWriter() {
		return writer;
	}

	public void setWriter(Actor writer) {
		this.writer = writer;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getCommentSequence() {
		return commentSequence;
	}

	public void setCommentSequence(int commentSequence) {
		this.commentSequence = commentSequence;
	}

	public CommentList getComments() {
		return comments;
	}

	public void setComments(CommentList comments) {
		this.comments = comments;
	}

	public Long getTime() {
		return time;
	}

	public void setTime(Long time) {
		this.time = time;
	}

	public String getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(String feedbackId) {
		this.feedbackId = feedbackId;
	}

	public static void main(String[] args) {
		//
		System.out.println(getSample());
	}
}
