package namoo.drama.feedback.domain.store;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.domain.ScreenId;

import java.util.List;

public interface FeedbackStore {
    //
    void create(Feedback feedback);
    Feedback retrieve(String id);
    OffsetList<Feedback> retrieveAllByPavilionId(String pavilionId, int offset, int limit);
    OffsetList<Feedback> retrieveAllByPavilionIdAndCineroomId(String pavilionId, String cineroomId, int offset, int limit);
    OffsetList<Feedback> retrieveAllByPavilionIdAndDramaId(String pavilionId, String dramaId, int offset, int limit);
    OffsetList<Feedback> retrieveAllByScreenId(ScreenId screenId, int offset, int limit);
    List<Feedback> retrieveAllBySourceEntityName(String sourceEntityName);
    void update(Feedback feedback);
    void delete(String id);


}
