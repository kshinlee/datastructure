package namoo.drama.feedback.domain.logic;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.reply.Comment;
import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.proxy.FeedbackProxyLycler;
import namoo.drama.feedback.domain.spec.front.ReplyService;
import namoo.drama.feedback.domain.spec.shared.CommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReplyCdo;
import namoo.drama.feedback.domain.spec.drama.ReplyProvider;
import namoo.drama.feedback.domain.store.FeedbackStore;
import namoo.drama.feedback.domain.store.FeedbackStoreLycler;
import namoo.drama.feedback.domain.store.ReplyStore;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;

import java.util.NoSuchElementException;

public class ReplyLogic implements ReplyProvider, ReplyService {
    //
    private FeedbackStore feedbackStore;
    private ReplyStore replyStore;

    public ReplyLogic(FeedbackStoreLycler storeLycler, FeedbackProxyLycler proxyLycler) {
        //
        this.feedbackStore = storeLycler.requestFeedbackStore();
        this.replyStore = storeLycler.requestReplyStore();
    }

    @Override
    public String registerReply(String feedbackId, ReplyCdo replyCdo) {
        //
        Feedback feedback = feedbackStore.retrieve(feedbackId);
        if(feedback == null) {
            throw new NoSuchElementException("feedback id: " + feedbackId);
        }

        Reply reply = new Reply(replyCdo.getWriter(), replyCdo.getText(), feedback.getId());
        replyStore.create(reply);

        return reply.getId();
    }

    @Override
    public Reply findReply(String replyId) {
        //
        return replyStore.retrieve(replyId);
    }

    @Override
    public OffsetList<Reply> findReplies(String feedbackId, int offset, int limit) {
        //
        return replyStore.retrieveAll(feedbackId, offset, limit);
    }

    @Override
    public void modifyReply(String replyId, NameValueList nameValues) {
        //
        Reply reply = requestReply(replyId);

        reply.setValues(nameValues);
        replyStore.update(reply);
    }

    @Override
    public void removeReply(String replyId) {
        //
        Reply reply = requestReply(replyId);
        replyStore.delete(reply);
    }

    @Override
    public int addComment(String replyId, CommentCdo commentCdo) {
        //
        Reply reply = requestReply(replyId);
        Comment comment = new Comment(reply.nextCommentSequence(), commentCdo.getWriter(), commentCdo.getText());
        reply.getComments().add(comment);
        replyStore.update(reply);

        return comment.getSequence();
    }

    @Override
    public void modifyComment(String replyId, int sequence, String text) {
        //
        Reply reply = requestReply(replyId);
        Comment comment = reply.getComments().get(sequence);
        comment.setText(text);

        replyStore.update(reply);
    }

    @Override
    public void removeComment(String replyId, int sequence) {
        //
        Reply reply = requestReply(replyId);
        Comment comment = reply.getComments().get(sequence);
        reply.getComments().remove(comment);

        replyStore.update(reply);
    }

    private Reply requestReply(String replyId) {
        //
        Reply reply = replyStore.retrieve(replyId);
        if (reply == null) {
            throw new NoSuchElementException("reply id: " + replyId);
        }

        return reply;
    }
}
