package namoo.drama.feedback.domain.entity.report;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.nara.share.domain.*;
import namoo.nara.share.exception.ValueOutOfBoundsException;
import namoo.nara.share.util.json.JsonUtil;
import namoo.nara.share.util.string.StringUtil;

import java.util.ArrayList;
import java.util.List;

public class Report extends Entity implements Aggregate {
    //
    private Actor writer;
    private String title;
    private String opinion;
    private String captureeImageId;
    private List<AttachedFile> attachedFiles;
    private Long time;
    private int answerSequence;
    private AnswerList answers;

    private String feedbackId;

    public Report() {
        //
    }

    public Report(String id) {
        //
        super(id);
    }

    public Report(Actor writer, String title, String opinion, String captureeImageId, String feedbackId) {
        //
        super();
        this.writer = writer;
        this.title = title;
        this.opinion = opinion;
        this.captureeImageId = captureeImageId;
        this.feedbackId = feedbackId;
        this.time = System.currentTimeMillis();
        this.attachedFiles = new ArrayList<>();
        this.answerSequence = 0;
        this.answers = new AnswerList();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Report{");
        sb.append("writer=").append(writer);
        sb.append(", title='").append(title).append('\'');
        sb.append(", opinion='").append(opinion).append('\'');
        sb.append(", captureeImageId='").append(captureeImageId).append('\'');
        sb.append(", attachedFiles=").append(attachedFiles);
        sb.append(", time=").append(time);
        sb.append(", answerSequence=").append(answerSequence);
        sb.append(", answers=").append(answers);
        sb.append(", feedbackId='").append(feedbackId).append('\'');
        sb.append('}');
        return sb.toString();
    }

    public static Report getSample() {
        //
        Actor actor = Actor.getSample();
        String title = "텍스트 라벨 오탈자";
        String opinion = "텍스트 라벨이 담담강사 --> 담당강사로 변경해주세요 ";
        String capturedImageId = "1234465";
        String feedbackId = Feedback.getSample().getId();

        Report sample = new Report(actor, title, opinion, capturedImageId, feedbackId);

        return sample;
    }

    public String toJson() {
        //
        return JsonUtil.toJson(this);
    }

    public static Report fromJson(String json) {
        //
        return JsonUtil.fromJson(json, Report.class);
    }

    public void setValues(NameValueList nameValues) {
        //
        if (nameValues == null || nameValues.size() == 0) return;
        for(NameValue nameValue : nameValues.getList()) {
            String name = nameValue.getName();
            String value = nameValue.getValue();
            if (StringUtil.isEmpty(value)) continue;
            switch(name) {
                case "title":           this.title = value; break;
                case "opinion":         this.opinion = value; break;
                case "capturedImageId":     this.captureeImageId = value; break;
            }
        }
    }

    public int nextCommentSequence() {
        //
        answerSequence++;
        if(answers.size() >= Answer.MAX_SEQUENCE) {
            throw new ValueOutOfBoundsException("max sequence is " + Answer.MAX_SEQUENCE + ", but it's " + answerSequence);
        }

        return answerSequence++;
    }

    public Actor getWriter() {
        return writer;
    }

    public void setWriter(Actor writer) {
        this.writer = writer;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOpinion() {
        return opinion;
    }

    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }

    public String getCaptureeImageId() {
        return captureeImageId;
    }

    public void setCaptureeImageId(String captureeImageId) {
        this.captureeImageId = captureeImageId;
    }

    public List<AttachedFile> getAttachedFiles() {
        return attachedFiles;
    }

    public void setAttachedFiles(List<AttachedFile> attachedFiles) {
        this.attachedFiles = attachedFiles;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public static void main(String[] args) {
        //
        System.out.println(getSample());
    }
}
