package namoo.drama.feedback;

import namoo.drama.feedback.cp.spring.FeedbackLocalInitializer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-10
 */
@SpringBootApplication
@Import(value = {FeedbackLocalInitializer.class})
public class FeedbackApplication {
    //
    public static void main(String[] args) {
        SpringApplication.run(FeedbackApplication.class, args);
    }
}
