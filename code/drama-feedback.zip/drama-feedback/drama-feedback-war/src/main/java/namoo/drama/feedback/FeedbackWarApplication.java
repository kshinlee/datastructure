package namoo.drama.feedback;

import namoo.drama.feedback.cp.spring.FeedbackInitializer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import(value = {FeedbackInitializer.class})
public class FeedbackWarApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(FeedbackWarApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(FeedbackWarApplication.class, args);
    }
}
