package namoo.drama.feedback.cp.spring;

import namoo.nara.stage.dramaspec.DramaSettings;
import namoo.nara.stage.dramaspec.DramaSpec;
import namoo.nara.stage.dramaspec.loader.spring.SpringAnnotationSpecLoader;
import namoo.nara.stage.envoy.DramaContext;
import org.springframework.beans.factory.annotation.Value;

import javax.annotation.PostConstruct;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
public class FeedbackLocalInitializer {
    //
    @Value("${nara.stage.api.host}")
    private String stageHost;

    @PostConstruct
    public void initialize() {

        DramaSettings settings = new DramaSettings();
        settings.setHost("http://127.0.0.1:19991");
        settings.setPlayPath("");
        settings.setResourcePath("resources");
        settings.setApiPath("feedback-api");

        DramaSpec spec = new DramaSpec("17-000F", "0.0.1-SNAPSHOT");
        spec.setSettings(settings);

        DramaContext dramaContext = DramaContext.getInstance();
        dramaContext.setSpecLoader(new SpringAnnotationSpecLoader("namoo.drama.feedback"));
        dramaContext.initialize(stageHost, spec);
    }
}
