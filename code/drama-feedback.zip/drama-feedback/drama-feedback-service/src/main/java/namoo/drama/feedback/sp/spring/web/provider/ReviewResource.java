package namoo.drama.feedback.sp.spring.web.provider;

import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.drama.feedback.domain.spec.drama.ReviewProvider;
import namoo.drama.feedback.domain.spec.shared.HelpCommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReviewCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RestController("reviewProviderResource")
@RequestMapping("feedback-prov-api/reviews")
public class ReviewResource implements ReviewProvider {
    //
    @Autowired
    @Qualifier(value = "reviewLogic")
    private ReviewProvider reviewProvider;

    @Override
    @PostMapping
    public String registerReview(
        @RequestParam("feedbackId") String feedbackId,
        @RequestBody ReviewCdo reviewCdo) {
        //
        return reviewProvider.registerReview(feedbackId, reviewCdo);
    }

    @Override
    @PostMapping(value = "version/{version}")
    public String registerVersionedReview(
        @RequestParam("feedbackId") String feedbackId,
        @PathVariable("version") String version,
        @RequestBody ReviewCdo reviewCdo) {
        //
        return reviewProvider.registerVersionedReview(feedbackId, version, reviewCdo);
    }

    @Override
    @GetMapping(value = "{reviewId}")
    public Review findReview(@PathVariable("reviewId") String reviewId) {
        //
        return reviewProvider.findReview(reviewId);
    }

    @Override
    @GetMapping
    public OffsetList<Review> findReviews(
        @RequestParam("feedbackId") String feedbackId,
        @RequestParam(value = "offset", defaultValue = "0") int offset,
        @RequestParam(value = "limit", defaultValue = "10") int limit) {
        //
        return reviewProvider.findReviews(feedbackId, offset, limit);
    }

    @Override
    @GetMapping(value = "version/{version}")
    public OffsetList<Review> findReviews(
        @PathVariable("version") String version,
        @RequestParam("feedbackId") String feedbackId,
        @RequestParam(value = "offset", defaultValue = "0") int offset,
        @RequestParam(value = "limit", defaultValue = "10") int limit) {
        //
        return reviewProvider.findReviews(feedbackId, version, offset, limit);
    }

    @Override
    @PutMapping(value = "{reviewId}")
    public void modifyReview(
        @PathVariable("reviewId") String reviewId,
        @RequestBody NameValueList nameValues) {
        //
        reviewProvider.modifyReview(reviewId, nameValues);
    }

    @Override
    @DeleteMapping(value = "{reviewId}")
    public void removeReview(@PathVariable("reviewId") String reviewId) {
        //
        reviewProvider.removeReview(reviewId);
    }

    @Override
    @PostMapping(value = "{reviewId}/help")
    public void addHelpComment(
        @PathVariable("reviewId") String reviewId,
        @RequestBody HelpCommentCdo helpCommentCdo) {
        //
        reviewProvider.addHelpComment(reviewId, helpCommentCdo);
    }

    @Override
    @DeleteMapping("{reviewId}/help/{helpCommentId}")
    public void removeHelpComment(@PathVariable("helpCommentId") String helpCommentId) {
        //
        reviewProvider.removeHelpComment(helpCommentId);
    }

    @Override
    @DeleteMapping("{reviewId}/help/reviewer/{reviewerId}")
    public void removeHelpComment(
        @PathVariable("reviewId") String reviewId,
        @PathVariable("reviewerId") String reviewerId) {
        //
        reviewProvider.removeHelpComment(reviewId, reviewerId);
    }

    @Override
    @GetMapping(value = "summary")
    public ReviewSummary findReviewSummary(@RequestParam("feedbackId") String feedbackId) {
        //
        return reviewProvider.findReviewSummary(feedbackId);
    }
}
