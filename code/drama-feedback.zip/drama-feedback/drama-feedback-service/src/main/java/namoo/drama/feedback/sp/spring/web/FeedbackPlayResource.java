package namoo.drama.feedback.sp.spring.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-04-25
 */
@Controller
public class FeedbackPlayResource {
    //
    @RequestMapping("/**")
    public String index(
            Model model
    ) {
        //
        return "index";
    }
}
