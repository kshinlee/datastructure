package namoo.drama.feedback.es.handler;

import namoo.drama.feedback.domain.event.HelpCommentRemovedByReviewIdEvent;
import namoo.drama.feedback.domain.spec.front.HelpCommentService;
import namoo.nara.share.event.NaraEventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
@Component
public class HelpCommentRemovedByReviewIdEventHandler implements NaraEventHandler<HelpCommentRemovedByReviewIdEvent> {
    //
    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    @Qualifier("helpCommentLogic")
    private HelpCommentService helpCommentService;

    @Override
    public void handle(HelpCommentRemovedByReviewIdEvent event) {
        //
        String reviewId = event.getReviewId();
        helpCommentService.removeHelpCommentsByReviewId(reviewId);
    }
}
