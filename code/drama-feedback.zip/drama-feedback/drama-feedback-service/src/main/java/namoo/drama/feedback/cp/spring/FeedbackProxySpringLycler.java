package namoo.drama.feedback.cp.spring;

import namoo.drama.feedback.domain.proxy.EnvoyProxy;
import namoo.drama.feedback.domain.proxy.FeedbackProxyLycler;
import namoo.nara.share.event.NaraEventProxy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-10
 */
@Component
public class FeedbackProxySpringLycler implements FeedbackProxyLycler {
    //
    @Autowired
    private EnvoyProxy envoyProxy;
    @Autowired
    private NaraEventProxy eventProxy;

    @Override
    public EnvoyProxy requestEnvoyProxy() {
        //
        return envoyProxy;
    }

    @Override
    public NaraEventProxy requestEventProxy() {
        return eventProxy;
    }
}
