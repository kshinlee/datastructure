package namoo.drama.feedback.es.config.memory;

import namoo.drama.feedback.es.handler.*;
import namoo.nara.share.event.memory.InMemoryEventQueue;
import namoo.nara.share.event.memory.InMemoryEventQueueListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component
public class FeedbackMemoryEventListenerConfig {

    @Autowired
    private HelpCommentRemovedByReviewIdEventHandler helpCommentRemovedByReviewIdEventHandler;
    @Autowired
    private ReviewModifiedEventHandler reviewModifiedEventHandler;
    @Autowired
    protected ReviewSummaryChangedStarRateByStarsEventHandler reviewSummaryChangedStarRateByStarsEventHandler;
    @Autowired
    protected ReviewSummaryChangedStarRateEventHandler reviewSummaryChangedStarRateEventHandler;
    @Autowired
    private VersionedReviewSummaryChangedStarRateByStarsEventHandler versionedReviewSummaryChangedStarRateByStarsEventHandler;
    @Autowired
    private VersionedReviewSummaryChangedStarRateEventHandler versionedReviewSummaryChangedStarRateEventHandler;

    @Autowired private InMemoryEventQueue helpCommentRemovedByReviewIdEventQueue;
    @Autowired private InMemoryEventQueue reviewModifiedEventQueue;
    @Autowired private InMemoryEventQueue reviewSummaryChangedStarRateByStarsEventQueue;
    @Autowired private InMemoryEventQueue reviewSummaryChangedStarRateEventQueue;
    @Autowired private InMemoryEventQueue versionedReviewSummaryChangedStarRateByStarsEventQueue;
    @Autowired private InMemoryEventQueue versionedReviewSummaryChangedStarRateEventQueue;

    @Bean
    public InMemoryEventQueueListener helpCommentRemovedByReviewIdEventListener() {
        InMemoryEventQueueListener listener = new InMemoryEventQueueListener(helpCommentRemovedByReviewIdEventQueue);
        listener.addHandler(helpCommentRemovedByReviewIdEventHandler);
        new Thread(listener).start();
        return listener;
    }
    @Bean
    public InMemoryEventQueueListener reviewModifiedEventListener() {
        InMemoryEventQueueListener listener = new InMemoryEventQueueListener(reviewModifiedEventQueue);
        listener.addHandler(reviewModifiedEventHandler);
        new Thread(listener).start();
        return listener;
    }
    @Bean
    public InMemoryEventQueueListener reviewSummaryChangedStarRateByStarsEventListener() {
        InMemoryEventQueueListener listener = new InMemoryEventQueueListener(reviewSummaryChangedStarRateByStarsEventQueue);
        listener.addHandler(reviewSummaryChangedStarRateByStarsEventHandler);
        new Thread(listener).start();
        return listener;
    }
    @Bean
    public InMemoryEventQueueListener reviewSummaryChangedStarRateEventListener() {
        InMemoryEventQueueListener listener = new InMemoryEventQueueListener(reviewSummaryChangedStarRateEventQueue);
        listener.addHandler(reviewSummaryChangedStarRateEventHandler);
        new Thread(listener).start();
        return listener;
    }
    @Bean
    public InMemoryEventQueueListener versionedReviewSummaryChangedStarRateByStarsEventListener() {
        InMemoryEventQueueListener listener = new InMemoryEventQueueListener(versionedReviewSummaryChangedStarRateByStarsEventQueue);
        listener.addHandler(versionedReviewSummaryChangedStarRateByStarsEventHandler);
        new Thread(listener).start();
        return listener;
    }
    @Bean
    public InMemoryEventQueueListener versionedReviewSummaryChangedStarRateEventListener() {
        InMemoryEventQueueListener listener = new InMemoryEventQueueListener(versionedReviewSummaryChangedStarRateEventQueue);
        listener.addHandler(versionedReviewSummaryChangedStarRateEventHandler);
        new Thread(listener).start();
        return listener;
    }

}
