package namoo.drama.feedback.sp.spring.web;

import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.spec.front.ReplyService;
import namoo.drama.feedback.domain.spec.shared.CommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReplyCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RestController
@RequestMapping("feedback-api/replies")
public class ReplyResource implements ReplyService{
    //
    @Autowired
    @Qualifier(value = "replyLogic")
    private ReplyService replyService;

    @Override
    @PostMapping
    public String registerReply(
        @RequestParam("feedbackId") String feedbackId,
        @RequestBody ReplyCdo replyCdo) {
        //
        return replyService.registerReply(feedbackId, replyCdo);
    }

    @Override
    @GetMapping(value = "{replyId}")
    public Reply findReply(@PathVariable("replyId") String replyId) {
        //
        return replyService.findReply(replyId);
    }

    @Override
    @GetMapping
    public OffsetList<Reply> findReplies(
        @RequestParam("feedbackId") String feedbackId,
        @RequestParam(value = "offset", defaultValue = "0") int offset,
        @RequestParam(value = "limit", defaultValue = "10") int limit) {
        //
        return replyService.findReplies(feedbackId, offset, limit);
    }

    @Override
    @PutMapping(value = "{replyId}")
    public void modifyReply(
        @PathVariable("replyId") String replyId,
        @RequestBody NameValueList nameValues) {
        //
        replyService.modifyReply(replyId, nameValues);
    }

    @Override
    @DeleteMapping(value = "{replyId}")
    public void removeReply(@PathVariable("replyId") String replyId) {
        //
        replyService.removeReply(replyId);
    }

    @Override
    @PostMapping(value = "{replyId}/comment")
    public int addComment(
        @PathVariable("replyId") String replyId,
        @RequestBody CommentCdo commentCdo) {
        //
        return replyService.addComment(replyId, commentCdo);
    }

    @Override
    @PutMapping(value = "{replyId}/comment/{sequence}")
    public void modifyComment(
        @PathVariable("replyId") String replyId,
        @PathVariable("sequence") int sequence,
        @RequestBody String text) {
        //
        replyService.modifyComment(replyId, sequence, text);
    }

    @Override
    @DeleteMapping(value = "{replyId}/comment/{sequence}")
    public void removeComment(
        @PathVariable("replyId") String replyId,
        @PathVariable("sequence") int sequence) {
        //
        replyService.removeComment(replyId, sequence);
    }
}
