package namoo.drama.feedback.cp.spring;

import namoo.drama.feedback.domain.store.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-10
 */
@Component
public class FeedbackStoreSpringLycler implements FeedbackStoreLycler {
    //
    @Autowired
    private FeedbackStore feedbackStore;
    @Autowired
    private ReplyStore replyStore;
    @Autowired
    private ReviewStore reviewStore;
    @Autowired
    private ReviewSummaryStore reviewSummaryStore;
    @Autowired
    private HelpCommentStore helpCommentStore;

    @Override
    public FeedbackStore requestFeedbackStore() {
        return feedbackStore;
    }

    @Override
    public ReplyStore requestReplyStore() {
        return replyStore;
    }

    @Override
    public ReviewStore requestReviewStore() {
        return reviewStore;
    }

    @Override
    public ReviewSummaryStore requestReviewSummaryStore() {
        return reviewSummaryStore;
    }

    @Override
    public HelpCommentStore requestHelpCommentStore() {
        return helpCommentStore;
    }
}
