package namoo.drama.feedback.es.handler;

import namoo.drama.feedback.domain.event.VersionedReviewSummaryChangedStarRateEvent;
import namoo.drama.feedback.domain.logic.shared.ReviewSummaryEventHelper;
import namoo.nara.share.event.NaraEventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-18
 */
@Component
public class VersionedReviewSummaryChangedStarRateEventHandler implements NaraEventHandler<VersionedReviewSummaryChangedStarRateEvent> {
    //
    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    @Qualifier("reviewSummaryEventHelper")
    private ReviewSummaryEventHelper reviewSummaryEventHelper;

    @Override
    public void handle(VersionedReviewSummaryChangedStarRateEvent event) {
        //
        String feedbackId = event.getFeedbackId();
        String version = event.getVersion();
        int selectedStar = event.getSelectedStar();
        boolean increased = event.isIncreased();
        reviewSummaryEventHelper.changeStarRateInVersionedReviewSummary(feedbackId, version, selectedStar, increased);
    }
}
