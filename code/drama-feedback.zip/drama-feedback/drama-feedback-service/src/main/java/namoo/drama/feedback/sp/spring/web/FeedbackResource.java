package namoo.drama.feedback.sp.spring.web;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.spec.front.FeedbackService;
import namoo.drama.feedback.domain.spec.shared.FeedbackCdo;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.domain.ScreenId;
import namoo.nara.stage.envoy.dramareq.DramaRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RestController
@RequestMapping("feedback-api/feedback")
public class FeedbackResource implements FeedbackService{
    //
    @Autowired
    @Qualifier(value = "feedbackLogic")
    private FeedbackService feedbackService;

    @Override
    @PostMapping(value = "reply")
    public String registerReplyFeedback(
        @RequestBody FeedbackCdo feedbackCdo) {
        //
        if (feedbackCdo.getInformant() != null && feedbackCdo.getInformant().getScreenId() != null) {
            String pavilionId = DramaRequest.getCurrentRequest() != null ? DramaRequest.getCurrentRequest().getPavilionId() : "testPav";
            feedbackCdo.getInformant().getScreenId().setPavilionId(pavilionId);
        }
        return feedbackService.registerReplyFeedback(feedbackCdo);
    }

    @Override
    @PostMapping(value = "review")
    public String registerReviewFeedback(
        @RequestBody FeedbackCdo feedbackCdo) {
        //
        if (feedbackCdo.getInformant() != null && feedbackCdo.getInformant().getScreenId() != null) {
            String pavilionId = DramaRequest.getCurrentRequest() != null ? DramaRequest.getCurrentRequest().getPavilionId() : "testPav";
            feedbackCdo.getInformant().getScreenId().setPavilionId(pavilionId);
        }
        return feedbackService.registerReviewFeedback(feedbackCdo);
    }
    @Override
    @GetMapping(value = "{feedbackId}")
    public Feedback findFeedback(@PathVariable("feedbackId") String feedbackId) {
        //
        return feedbackService.findFeedback(feedbackId);
    }

    @Override
    @PutMapping(value = "{feedbackId}")
    public void modifyFeedback(
        @PathVariable("feedbackId")String feedbackId,
        @RequestBody NameValueList nameValues) {
        //
        feedbackService.modifyFeedback(feedbackId, nameValues);
    }

    @Override
    @GetMapping
    public OffsetList<Feedback> findFeedback(
        @RequestParam(value = "pavilionId") String pavilionId,
        @RequestParam(value = "offset", defaultValue = "0") int offset,
        @RequestParam(value = "limit", defaultValue ="100")int limit) {
        pavilionId =  DramaRequest.getCurrentRequest() != null ? DramaRequest.getCurrentRequest().getPavilionId() : "testPav";
        return feedbackService.findFeedback(pavilionId, offset, limit);
    }

    @Override
    @GetMapping(value = "cine")
    public OffsetList<Feedback> findFeedbackByCineroomId(String pavilionId, String cineroomId, int offset, int limit) {
        return null;
    }

    @Override
    @GetMapping(value = "screen")
    public OffsetList<Feedback> findFeedback(ScreenId screenId, int offset, int limit) {
        return null;
    }

    @Override
    @GetMapping(value = "drama")
    public OffsetList<Feedback> findFeedbackByDramaId(String pavilionId, String dramaId, int offset, int limit) {
        return null;
    }
}
