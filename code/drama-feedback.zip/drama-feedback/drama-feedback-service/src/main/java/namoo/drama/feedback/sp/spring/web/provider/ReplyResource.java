package namoo.drama.feedback.sp.spring.web.provider;

import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.spec.shared.CommentCdo;
import namoo.drama.feedback.domain.spec.shared.ReplyCdo;
import namoo.drama.feedback.domain.spec.drama.ReplyProvider;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.share.domain.OffsetList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RestController("replyProviderResource")
@RequestMapping("feedback-prov-api/replies")
public class ReplyResource implements ReplyProvider{
    //
    @Autowired
    @Qualifier(value = "replyLogic")
    private ReplyProvider replyProvider;

    @Override
    @PostMapping
    public String registerReply(
        @RequestParam("feedbackId") String feedbackId,
        @RequestBody ReplyCdo replyCdo) {
        //
        return replyProvider.registerReply(feedbackId, replyCdo);
    }

    @Override
    @GetMapping(value = "{replyId}")
    public Reply findReply(@PathVariable("replyId") String replyId) {
        //
        return replyProvider.findReply(replyId);
    }

    @Override
    @GetMapping
    public OffsetList<Reply> findReplies(
        @RequestParam("feedbackId") String feedbackId,
        @RequestParam(value = "offset", defaultValue = "0") int offset,
        @RequestParam(value = "limit", defaultValue = "10") int limit) {
        //
        return replyProvider.findReplies(feedbackId, offset, limit);
    }

    @Override
    @PutMapping(value = "{replyId}")
    public void modifyReply(
        @PathVariable("replyId") String replyId,
        @RequestBody NameValueList nameValues) {
        //
        replyProvider.modifyReply(replyId, nameValues);
    }

    @Override
    @DeleteMapping(value = "{replyId}")
    public void removeReply(@PathVariable("replyId") String replyId) {
        //
        replyProvider.removeReply(replyId);
    }

    @Override
    @PostMapping(value = "{replyId}/comment")
    public int addComment(
        @PathVariable("replyId") String replyId,
        @RequestBody CommentCdo commentCdo) {
        //
        return replyProvider.addComment(replyId, commentCdo);
    }

    @Override
    @PutMapping(value = "{replyId}/comment/{sequence}")
    public void modifyComment(
        @PathVariable("replyId") String replyId,
        @PathVariable("sequence") int sequence,
        @RequestBody String text) {
        //
        replyProvider.modifyComment(replyId, sequence, text);
    }

    @Override
    @DeleteMapping(value = "{replyId}/comment/{sequence}")
    public void removeComment(
        @PathVariable("replyId") String replyId,
        @PathVariable("sequence") int sequence) {
        //
        replyProvider.removeComment(replyId, sequence);
    }
}
