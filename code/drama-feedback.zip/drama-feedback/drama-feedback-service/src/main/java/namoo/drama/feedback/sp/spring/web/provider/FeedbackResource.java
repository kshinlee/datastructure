package namoo.drama.feedback.sp.spring.web.provider;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.spec.shared.FeedbackCdo;
import namoo.drama.feedback.domain.spec.drama.FeedbackProvider;
import namoo.nara.share.domain.NameValueList;
import namoo.nara.stage.envoy.dramareq.DramaRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RestController("feedbackProviderResource")
@RequestMapping("feedback-prov-api/feedback")
public class FeedbackResource implements FeedbackProvider{
    //
    @Autowired
    @Qualifier(value = "feedbackLogic")
    private FeedbackProvider feedbackProvider;

    @Override
    @PostMapping(value = "reply")
    public String registerReplyFeedback(
        @RequestBody FeedbackCdo feedbackCdo) {
        //
        return feedbackProvider.registerReplyFeedback(feedbackCdo);
    }

    @Override
    @PostMapping(value = "review")
    public String registerReviewFeedback(
        @RequestBody FeedbackCdo feedbackCdo) {
        //
        return feedbackProvider.registerReviewFeedback(feedbackCdo);
    }

    @Override
    @GetMapping(value = "{feedbackId}")
    public Feedback findFeedback(@PathVariable("feedbackId") String feedbackId) {
        //
        return feedbackProvider.findFeedback(feedbackId);
    }

    @Override
    @PutMapping(value = "{feedbackId}/anonymous")
    public void makeAnonymous(@PathVariable("feedbackId") String feedbackId) {
        //
        feedbackProvider.makeAnonymous(feedbackId);
    }

    @Override
    @PutMapping(value = "{feedbackId}")
    public void modifyFeedback(
        @PathVariable("feedbackId")String feedbackId,
        @RequestBody NameValueList nameValues) {
        //
        feedbackProvider.modifyFeedback(feedbackId, nameValues);
    }

    @Override
    @DeleteMapping(value = "{feedbackId}/reply")
    public void removeReplyFeedback(@PathVariable("feedbackId")String feedbackId) {
        //
        feedbackProvider.removeReplyFeedback(feedbackId);
    }

    @Override
    @DeleteMapping(value = "{feedbackId}/review")
    public void removeReviewFeedback(@PathVariable("feedbackId")String feedbackId) {
        //
        feedbackProvider.removeReviewFeedback(feedbackId);
    }
}
