package namoo.drama.feedback.es.config.memory;

import namoo.drama.feedback.domain.event.*;
import namoo.drama.feedback.domain.proxy.EnvoyProxy;
import namoo.nara.share.event.NaraEventProxy;
import namoo.nara.share.event.memory.InMemoryEventQueue;
import namoo.nara.share.event.memory.InMemoryEventQueueProxy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class FeedbackMemoryEventQueueConfig {
    @Bean
    public EnvoyProxy envoyProxy() {
        return null;
    }

    @Bean
    public InMemoryEventQueue helpCommentRemovedByReviewIdEventQueue() {
        return new InMemoryEventQueue(100);
    }
    @Bean
    public InMemoryEventQueue reviewModifiedEventQueue() {
        return new InMemoryEventQueue(100);
    }
    @Bean
    public InMemoryEventQueue reviewSummaryChangedStarRateByStarsEventQueue() {
        return new InMemoryEventQueue(100);
    }
    @Bean
    public InMemoryEventQueue reviewSummaryChangedStarRateEventQueue() {
        return new InMemoryEventQueue(100);
    }
    @Bean
    public InMemoryEventQueue versionedReviewSummaryChangedStarRateByStarsEventQueue() {
        return new InMemoryEventQueue(100);
    }
    @Bean
    public InMemoryEventQueue versionedReviewSummaryChangedStarRateEventQueue() {
        return new InMemoryEventQueue(100);
    }

    @Bean
    public NaraEventProxy FeedbackEventProxy() {
        InMemoryEventQueueProxy eventProxy = new InMemoryEventQueueProxy();
        eventProxy.addEventQueue(HelpCommentRemovedByReviewIdEvent.class.getTypeName(), helpCommentRemovedByReviewIdEventQueue());
        eventProxy.addEventQueue(ReviewModifiedEvent.class.getTypeName(), reviewModifiedEventQueue());
        eventProxy.addEventQueue(ReviewSummaryChangedStarRateByStarsEvent.class.getTypeName(), reviewSummaryChangedStarRateByStarsEventQueue());
        eventProxy.addEventQueue(ReviewSummaryChangedStarRateEvent.class.getTypeName(), reviewSummaryChangedStarRateEventQueue());
        eventProxy.addEventQueue(VersionedReviewSummaryChangedStarRateByStarsEvent.class.getTypeName(), versionedReviewSummaryChangedStarRateByStarsEventQueue());
        eventProxy.addEventQueue(VersionedReviewSummaryChangedStarRateEvent.class.getTypeName(), versionedReviewSummaryChangedStarRateEventQueue());
        return eventProxy;
    }

}
