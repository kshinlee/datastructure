package namoo.drama.feedback.cp.spring;

import namoo.drama.feedback.domain.logic.FeedbackLogic;
import namoo.drama.feedback.domain.logic.ReplyLogic;
import namoo.drama.feedback.domain.logic.ReviewLogic;
import namoo.drama.feedback.domain.proxy.FeedbackProxyLycler;
import namoo.drama.feedback.domain.store.FeedbackStoreLycler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-10
 */
@Configuration
@Component
public class FeedbackProviderSpringLycler {
    //
    @Autowired
    private FeedbackStoreLycler feedbackStoreLycler;
    @Autowired
    private FeedbackProxyLycler feedbackProxyLycler;

    @Bean
    public FeedbackLogic feedbackLogic(){
        return new FeedbackLogic(feedbackStoreLycler, feedbackProxyLycler);
    }

    @Bean
    public ReplyLogic replyLogic(){
        return new ReplyLogic(feedbackStoreLycler, feedbackProxyLycler);
    }

    @Bean
    public ReviewLogic reviewLogic(){
        return new ReviewLogic(feedbackStoreLycler, feedbackProxyLycler);
    }

}
