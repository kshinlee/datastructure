import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { replyActionBuilder } from '../module/reply';

import ContentWrapper from '../../common/ContentWrapper';
import ReplyList from '../component/ReplyList';

class ReplyListContainer extends Component {
  //
  constructor(props) {
    super(props);
    autoBind(this);
  }

  componentWillMount() {
    //
    const props = this.props;

    if (props.params.feedbackId) {
      props.replyActions.findReplies(props.params.feedbackId);
    }
  }

  componentWillReceiveProps(nextProps) {
    //
    const props = this.props;
    const feedbackId = props.params.feedbackId;
    const nextFeedbackId = nextProps.params.feedbackId;

    if ((nextFeedbackId || feedbackId) && feedbackId !== nextFeedbackId) {
      props.replyActions.findReplies(nextFeedbackId || feedbackId);
    }
  }

  registerReply() {
    const feedbackId = this.props.params.feedbackId;
    const replyCdo = {
      writer: {
        id: DRAMA_CONTEXT.userId,
        name: DRAMA_CONTEXT.userName,
      },
      text: this.props.replyState.text,
    };

    this.props.replyActions.registerReply(feedbackId, replyCdo);
  }

  removeReply(replyId, index) {
    const feedbackId = this.props.params.feedbackId;

    this.props.replyActions.removeReply(feedbackId, replyId, index);
  }

  addReplies() {
    const feedbackId = this.props.params.feedbackId;
    const offset = this.props.replyState.offset + this.props.replyState.limit;

    this.props.replyActions.addReplies(feedbackId, offset);
  }

  saveComment(replyId, comment, replyIndex) {
    if (comment.sequence) {
      this.props.replyActions.modifyComment(replyId, comment, replyIndex);
    }
    else {
      this.props.replyActions.registerComment(replyId, comment, replyIndex);
    }
  }

  render() {
    //
    const props = this.props;
    const replyState = props.replyState;
    const replies = replyState.replies === null ?
      null : props.replyState.replies;

    return (
      <ContentWrapper>
        <ReplyList
          text={replyState.text}
          replies={replies}
          registerReply={this.registerReply}
          modifyReply={props.replyActions.modifyReply}
          removeReply={this.removeReply}
          addReplies={this.addReplies}
          addComment={props.replyActions.addComment}
          saveComment={this.saveComment}
          removeComment={props.replyActions.removeComment}
          changeText={props.replyActions.changeText}
          changeReplyText={props.replyActions.changeReplyText}
          changeCommentText={props.replyActions.changeCommentText}
          toggleReplyModifiable={props.replyActions.toggleReplyModifiable}
          toggleCommentModifiable={props.replyActions.toggleCommentModifiable}
        />
      </ContentWrapper>
    );
  }
}

const mapStateToProps = ({ reply }) => ({
  replyState: reply,
});

const mapDispatchToProps = (dispatch) => ({
  replyActions: bindActionCreators(replyActionBuilder(DRAMA_CONTEXT.basePath), dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(ReplyListContainer);

