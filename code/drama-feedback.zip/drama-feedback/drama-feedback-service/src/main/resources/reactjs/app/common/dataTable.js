export const initialGridConfig = (gridId) => {
  let config = {
    'paging': false,
    'ordering': true,
    'info': false,
    'responsive': true,
    'searching': false,
    'scrollY': '96px',
    'scrollCollapse': true,
    dom: 'lTfgitp'/* table padding과 관련되어 있음 */
  };
  let grid = $(`#${gridId}`);
  if (!$.fn.dataTable) return;
  grid.dataTable(config);

  return grid;
};

export const destroyGrid = (grid) => {
  if (grid !== null && grid !== undefined && grid.dataTable) grid.dataTable({destroy: true});
}
