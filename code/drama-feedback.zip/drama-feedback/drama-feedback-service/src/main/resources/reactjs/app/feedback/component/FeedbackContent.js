import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { initialGridConfig, destroyGrid } from '../../common/dataTable';
import { Col, Button, Table, FormGroup, FormControl } from 'react-bootstrap';

class FeedbackContent extends Component {

  constructor(props) {
    super(props);
    autoBind(this);
    // Grid
    this.grid = null;
  }

  componentDidMount() {
    this.grid = initialGridConfig('memoTable');
  }

  componentWillUnmount() {
    destroyGrid(this.grid);
  }

  render() {
    //
    const feedback = this.props.feedback;
    const config = feedback.config;

    return (

      <div className="panel panel-flat">
        { /* START panel-body */ }
        <div className="panel-body bb-dashed pt0">
          <form className="form-horizontal">
            <FormGroup>
              <label className="col-md-2 control-label">피드백 타입</label>
              <Col md={ 10 }>
                <FormControl
                  componentClass="select"
                  name="type"
                  value={feedback.type || ''}
                  onChange={(e) => this.props.changeFeedbackProps('type', e.target.value)}
                  className="form-control m-b" disabled={!!feedback.id}
                >
                  <option>구분을 선택해 주세요.</option>
                  <option value="Reply">Reply</option>
                  <option value="Review">Review</option>
                  <option value="Report">Report</option>
                </FormControl>
              </Col>
            </FormGroup>
            <FormGroup>
              <label className="col-md-2 control-label">피드백명</label>
              <Col md={ 10 }>
                <FormControl
                  type="text"
                  className="form-control"
                  value={feedback.title || ''}
                  onChange={(e) => this.props.changeFeedbackProps('title', e.target.value)}
                />
              </Col>
            </FormGroup>
            <FormGroup>
              <label className="col-md-2 control-label">익명여부</label>
              <Col md={ 9 }>
                <label className="switch switch-lg">
                  <FormControl
                    type="checkbox"
                    checked={config && config.anonymous ? config.anonymous : false}
                    onChange={(e) => this.props.changeFeedbackConfigProps('anonymous', e.target.checked)}/>
                  <em></em>
                </label>
              </Col>
            </FormGroup>
            {
              feedback && feedback.type === 'Reply' ?
              <FormGroup>
                <label className="col-md-2 control-label">덧글여부</label>
                <Col md={ 9 }>
                  <label className="switch switch-lg">
                    <FormControl
                      type="checkbox"
                      checked={config && config.commentAllowed ? config.commentAllowed : false}
                      onChange={(e) => this.props.changeFeedbackConfigProps('commentAllowed', e.target.checked)}/>
                    <em></em>
                  </label>
                </Col>
              </FormGroup> : ''
            }
            {
              feedback && feedback.type === 'Review' ?
              <div>
                <FormGroup>
                  <label className="col-md-2 control-label">버전여부</label>
                  <Col md={ 9 }>
                    <label className="switch switch-lg">
                      <FormControl
                        type="checkbox"
                        checked={config && config.versionBased ? config.versionBased : false}
                        onChange={(e) => this.props.changeFeedbackConfigProps('versionBased', e.target.checked)}/>
                      <em></em>
                    </label>
                  </Col>
                </FormGroup>
                <FormGroup>
                  <label className="col-md-2 control-label">별점</label>
                  <Col md={ 10 }>
                    <FormControl
                      type="number" className="form-control"
                      value={config && config.maxStarCount ? config.maxStarCount : ''}
                      onChange={(e) => this.props.changeFeedbackConfigProps('maxStarCount', e.target.value)}
                    />
                  </Col>
                </FormGroup>
              </div> : ''
            }
          </form>
        </div>
      </div>
    );
  }
}

export default FeedbackContent;
