import React from 'react';
import { Grid, Row, Col, Button, FormGroup, FormControl } from 'react-bootstrap';
import ReplyContent from './ReplyContent';

const ReplyList = (props) =>
  //
   (
    <Grid fluid>
      <Row>
        <Col md={ 12 }>
          { /* START panel */ }
          <div className="panel panel-default">
            <div className="panel-body">
              <div className="media">
                <small className="pull-right">
                  <Button
                    bsStyle="primary"
                    onClick={props.registerReply}
                  >저장</Button>
                </small>
                <div className="media-body">
                  <textarea
                    placeholder="댓글을 입력하세요."
                    rows="3"
                    className="form-control no-resize"
                    value={props.text || ''}
                    onChange={(e) => props.changeText(e.target.value)}
                  >
                  </textarea>
                </div>
              </div>
            </div>
            {
              props.replies !== null && props.replies.results !== null ?
                props.replies.results.map((reply, index) => (
                  <ReplyContent
                    key={reply.id}
                    reply={reply}
                    modifyReply={() => props.modifyReply(reply, index)}
                    removeReply={() => props.removeReply(reply.id, index)}
                    addComment={() => props.addComment(reply.id, index)}
                    saveComment={(comment) => props.saveComment(reply.id, comment, index)}
                    removeComment={(sequence) => props.removeComment(reply.id, sequence, index)}
                    changeReplyText={
                      (text) => props.changeReplyText(index, text)
                    }
                    changeCommentText={
                      (commentIndex, text) => props.changeCommentText(index, commentIndex, text)
                    }
                    toggleReplyModifiable={
                      () => props.toggleReplyModifiable(index, !reply.modifiable)
                    }
                    toggleCommentModifiable={
                      (commentIndex, commentModifiable) =>
                        props.toggleCommentModifiable(index, commentIndex, commentModifiable)
                    }
                  />
                )) : ''
            }
            {
              props.replies !== null && props.replies.results !== null &&
              props.replies.results.length < props.replies.totalCount ?
                <div className="panel-body bg-gray-lighter">
                  <a
                    className="link-unstyled"
                    style={{ cursor: 'pointer' }}
                    onClick={props.addReplies}
                  >댓글 더보기</a>
                </div> : ''
            }
          </div>
        </Col>
      </Row>
    </Grid>
  );

export default ReplyList;
