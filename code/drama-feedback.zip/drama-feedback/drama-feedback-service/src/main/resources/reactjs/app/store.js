import { applyMiddleware, combineReducers, compose, createStore } from 'redux';
import { browserHistory } from 'react-router';
import { routerMiddleware, routerReducer } from 'react-router-redux';
import thunk from 'redux-thunk';
import feedbackReducer from './feedback/module/feedback';
import replyReducer from './reply/module/reply';
import reviewReducer from './review/module/review';
import reviewSummaryReducer from './review/module/reviewSummary';
/**
 * logger middleware 적용
 * @param store
 */
const logger = (store) => (next) => (action) => {
  console.log('dispatching', action);
  return next(action);
};
const rootReducer = combineReducers({
  routing: routerReducer,
  feedback: feedbackReducer,
  reply: replyReducer,
  review: reviewReducer,
  reviewSummary: reviewSummaryReducer,
});


const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const routerHistoryMiddleware = routerMiddleware(browserHistory);

/**
 * Store
 * @type {Store<S>}
 */
const feedbackStore = createStore(
  rootReducer,
  composeEnhancers(
    applyMiddleware(logger, thunk, routerHistoryMiddleware),
  ),
);

export default feedbackStore;
