import NaraAjax from '../../../nara_modules/naraAjax';

export default (baseUrl) => {
  //
  const url = baseUrl ? baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/` : '';

  return {
    findReplies: (feedbackId, offset, limit) => NaraAjax.getJSON(`${url}feedback-api/replies?feedbackId=${feedbackId}&offset=${offset}&limit=${limit}`),
    findReply: (replyId) => NaraAjax.getJSON(`${url}feedback-api/replies/${replyId}`),
    registerReply: (feedbackId, replyCdo) => NaraAjax.postJSON(`${url}feedback-api/replies?feedbackId=${feedbackId}`, replyCdo),
    modifyReply: (replyId, nameValueList) => NaraAjax.putJSON(`${url}feedback-api/replies/${replyId}`, nameValueList),
    removeReply: (replyId) => NaraAjax.deleteJSON(`${url}feedback-api/replies/${replyId}`),
    addComment: (replyId, commentCdo) => NaraAjax.postJSON(`${url}feedback-api/replies/${replyId}/comment`, commentCdo),
    modifyComment: (replyId, sequence, text) => NaraAjax.putJSON(`${url}feedback-api/replies/${replyId}/comment/${sequence}`, text),
    removeComment: (replyId, sequence) => NaraAjax.deleteJSON(`${url}feedback-api/replies/${replyId}/comment/${sequence}`),
  };
};
