import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Grid, Row, Col } from 'react-bootstrap';

import { feedbackActionBuilder } from '../module/feedback';

import ContentWrapper from '../../common/ContentWrapper';
import FeedbackHeader from '../component/FeedbackHeader';
import FeedbackList from '../component/FeedbackList';
import FeedbackModal from '../component/FeedbackModal';

class FeedbackListContainer extends Component {
  //
  constructor(props) {
    super(props);
    autoBind(this);
  }

  componentWillMount() {
    //
    const props = this.props;

    this.initStore(props);
  }

  componentWillReceiveProps(nextProps) {
    //
    const props = this.props;

    this.initStore(props, nextProps);
  }

  initStore(props, nextProps) {
    //
    const feedbackId = props.params.feedbackId;
    const nextFeedbackId = nextProps ? nextProps.params.feedbackId : '';
    const pathname = nextProps ? nextProps.location.pathname : props.location.pathname;
    const nextPathname = nextProps ? nextProps.location.pathname : '';

    if (pathname.indexOf('creator') !== -1 && props.location.pathname !== nextPathname) {
      props.feedbackActions.toggleFeedbackModal(true);
    }

    if ((nextFeedbackId || feedbackId) && feedbackId !== nextFeedbackId) {
      const id = nextFeedbackId || feedbackId;

      props.feedbackActions.toggleFeedbackModal(true);
      props.feedbackActions.findFeedback(id);
    }

    if (pathname.indexOf('creator') === -1 &&
      !nextFeedbackId && !feedbackId &&
      props.feedbackState.showModal
    ) {
      props.feedbackActions.toggleFeedbackModal(false);
    }
  }

  routeToFeedback(id) {
    //
    this.props.router.push(`${DRAMA_CONTEXT.basePath}base/feedback/${id}`);
  }

  routeToFeedbackCreator() {
    this.props.router.push(`${DRAMA_CONTEXT.basePath}base/feedback/creator`);
  }

  closeModal() {
    this.props.router.push(`${DRAMA_CONTEXT.basePath}base/feedback`);
  }

  saveFeedback() {
    const props = this.props;
    const feedback = props.feedbackState.feedback;

    if (feedback.id) {
      const nameValues = [];

      for (const prop in feedback) {
        const value = feedback[prop] !== null && typeof feedback[prop] === 'object' ?
          JSON.stringify(feedback[prop]) : feedback[prop];

        nameValues.push({ name: prop, value });
      }
      props.feedbackActions.modifyFeedback(feedback.id, { nameValues }, this.closeModal);
    } else {
      const informant = {
        screenId: {
          pavilionId: null,
          cineroomId: DRAMA_CONTEXT.stageId,
          dramaId: DRAMA_CONTEXT.contextId,
        },
        player: {
          id: DRAMA_CONTEXT.userId,
          name: DRAMA_CONTEXT.userName,
        },
        sourceEntity: {
          id: DRAMA_CONTEXT.contextId,
          name: 'Feedback',
        },
      };
      const feedbackCdo = { informant, title: feedback.title };

      if (feedback.type === 'Reply') props.feedbackActions.registerReplyFeedback(feedbackCdo, this.closeModal);
      else if (feedback.type === 'Review') props.feedbackActions.registerReviewFeedback(feedbackCdo, this.closeModal);
    }
  }

  render() {
    //
    const props = this.props;
    const feedbackState = props.feedbackState;
    const feedbackList = feedbackState.feedbackList === null ?
      null : props.feedbackState.feedbackList;

    return (
      <ContentWrapper>
        <FeedbackHeader/>
        <Grid fluid>
          <Row>
            <Col md={ 12 }>
              <FeedbackList
                routeToFeedback={(id) => this.routeToFeedback(id)}
                routeToFeedbackCreator={() => this.routeToFeedbackCreator()}
                feedbackList={feedbackList}
              />
            </Col>
          </Row>
        </Grid>
        <FeedbackModal
          feedback={this.props.feedbackState.feedback}
          showModal={this.props.feedbackState.showModal}
          saveFeedback={this.saveFeedback}
          changeFeedbackProps={(prop, value) =>
            props.feedbackActions.changeFeedbackProps(prop, value)}
          changeFeedbackConfigProps={(prop, value) =>
            props.feedbackActions.changeFeedbackConfigProps(prop, value)}
          closeModal={this.closeModal}
        />
      </ContentWrapper>
    );
  }
}

const mapStateToProps = ({ feedback }) => ({
  feedbackState: feedback,
});

const mapDispatchToProps = (dispatch) => ({
  feedbackActions: bindActionCreators(feedbackActionBuilder(DRAMA_CONTEXT.basePath), dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(FeedbackListContainer);

