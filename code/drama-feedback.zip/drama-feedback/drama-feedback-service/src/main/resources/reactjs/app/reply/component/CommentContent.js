import React from 'react';
import { Grid, Row, Col, Button, FormGroup, FormControl } from 'react-bootstrap';

const CommentContent = (props) => (
      <div className="panel-body pt0">
        {
          props.comment.modifiable ?
            <div className="media">
              <small className="pull-right">
                <Button
                  bsStyle="primary"
                  onClick={props.saveComment}
                >저장</Button>
                <Button
                  bsStyle="default"
                  onClick={props.toggleCommentModifiable}
                >취소</Button>
              </small>
              <div className="media-left pl-xl">
                <em className="fa fa-mail-reply fa-rotate-180 text-muted"></em>
              </div>
              <div className="media-body">
                <textarea
                  placeholder="덧글을 입력하세요." rows="1" className="form-control no-resize"
                  value={
                    props.comment.text || props.comment.beforeText ?
                      (props.comment.text !== props.comment.beforeText ? props.comment.text : props.comment.beforeText) : ''
                  }
                  onChange={(e) => props.changeCommentText(e.target.value)}
                >
                </textarea>
              </div>
            </div> :
            <div className="media">
              <small className="pull-right text-muted">
                {
                  DRAMA_CONTEXT.userId === props.comment.writer.id ?
                    <Button
                      bsStyle="default" bsSize="xsmall"
                      onClick={props.toggleCommentModifiable}
                    >수정</Button> : ''
                }
                {
                  DRAMA_CONTEXT.userId === props.comment.writer.id ?
                    < Button
                      bsStyle="default" bsSize="xsmall"
                      onClick={props.removeComment}
                    >삭제</Button> : ''
                }
              </small>
              <div className="media-left pl-xl">
                <em className="fa fa-mail-reply fa-rotate-180 text-muted"></em>
              </div>
              <div className="media-body">
              <span className="media-heading">
                <p className="m0">
                  <a href="#">
                    <strong>
                      {props.comment.writer && props.comment.writer.name ? props.comment.writer.name : ''}
                    </strong>
                  </a>
                  <small className="text-muted pl">
                    {props.comment.time ? new Date(props.comment.time).toLocaleDateString() : ''}
                  </small>
                </p>
                <p className="m0">
                  {
                    props.comment.text ? props.comment.text.split(/\r?\n/g).map((item, key) => (
                        <span key={key}>
                          {item}
                          <br/>
                        </span>
                      )) : ''
                  }
                </p>
              </span>
              </div>
            </div>
        }
      </div>
  );

export default CommentContent;
