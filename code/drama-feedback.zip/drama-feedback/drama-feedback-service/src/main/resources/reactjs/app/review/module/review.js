import ReviewApiBuilder from '../api/review';

export const actionTypes = {
  FIND_REVIEWS: 'FIND_REVIEWS',
  ADD_REVIEWS: 'ADD_REVIEWS',
  RESET_REVIEW: 'RESET_REVIEW',
  RESET_REVIEWS: 'RESET_REVIEWS',

  CHANGE_REVIEW_PROPS: 'CHANGE_REVIEW_PROPS',

  TOGGLE_REVIEW_CREATOR: 'TOGGLE_REVIEW_CREATOR',
};

let ReviewApi = null;

const reviewAction = {
  //
  findReviews(feedbackId) {
    //
    const loadSuccess = (reviews, version) => ({
      type: actionTypes.FIND_REVIEWS,
      reviews,
      version,
      offset: initialState.offset,
      limit: initialState.limit,
    });

    return (dispatch, getState) => {
      ReviewApi.findReviews(feedbackId, initialState.offset, initialState.limit)
        .then((reviews) => {
          const version = getState().review.version;

          dispatch(loadSuccess(reviews, version));
        });
    };
  },

  findReviewsByVersion(feedbackId, version) {
    //
    const loadSuccess = (reviews) => ({
      type: actionTypes.FIND_REVIEWS,
      reviews,
      version,
      offset: initialState.offset,
      limit: initialState.limit,
    });

    return (dispatch) => {
      ReviewApi.findReviewsByVersion(feedbackId, version, initialState.offset, initialState.limit)
        .then((reviews) => dispatch(loadSuccess(reviews)));
    };
  },

  addReviews(feedbackId, offset, limit) {
    //
    const loadSuccess = (reviews, version) => ({
      type: actionTypes.ADD_REVIEWS,
      reviews,
      version,
      offset,
      limit,
    });

    return (dispatch, getState) => {
      ReviewApi.findReviews(feedbackId, offset, limit)
        .then((reviews) => {
          const version = getState().review.version;

          dispatch(loadSuccess(reviews, version));
        });
    };
  },

  addVersionedReviews(feedbackId, version, offset, limit) {
    //
    const loadSuccess = (reviews) => ({
      type: actionTypes.ADD_REVIEWS,
      reviews,
      version,
      offset,
      limit,
    });

    return (dispatch) => {
      ReviewApi.findReviewsByVersion(feedbackId, version, offset, limit)
        .then((reviews) => {
          dispatch(loadSuccess(reviews, version));
        });
    };
  },

  registerReview(feedbackId, reviewCdo, callback) {
    //
    return () => {
      ReviewApi.registerReview(feedbackId, reviewCdo)
        .then(() => {
          if (callback && typeof callback === 'function') callback();
        });
    };
  },

  registerVersionedReview(feedbackId, version, reviewCdo, callback) {
    //
    return () => {
      ReviewApi.registerVersionedReview(feedbackId, version, reviewCdo)
        .then(() => {
          if (callback && typeof callback === 'function') callback();
        });
    };
  },

  resetReview(reviewId, index) {
    //
    const loadSuccess = (review) => ({
      type: actionTypes.RESET_REVIEW,
      review,
      index,
    });

    return (dispatch) => {
      ReviewApi.findReview(reviewId)
        .then((review) => dispatch(loadSuccess(review, index)));
    };
  },

  resetReviews() {
    //
    return {
      type: actionTypes.RESET_REVIEWS,
    };
  },

  addHelpComment(reviewId, helpCommentCdo, reviewIndex) {
    //
    return (dispatch) => {
      ReviewApi.addHelpComment(reviewId, helpCommentCdo)
        .then(() => reviewAction.resetReview(reviewId, reviewIndex)(dispatch));
    };
  },

  changeReviewProps(prop, value) {
    //
    return {
      type: actionTypes.CHANGE_REVIEW_PROPS,
      prop,
      value,
    };
  },

  toggleReviewCreator(creatorViewable) {
    //
    return {
      type: actionTypes.TOGGLE_REVIEW_CREATOR,
      creatorViewable,
    };
  },
};

export const reviewActionBuilder = (baseUrl) => {
  //
  ReviewApi = ReviewApiBuilder(baseUrl);

  return reviewAction;
};

const initialState = {
  reviews: null,
  review: {
    title: null,
    opinion: null,
    selectedStar: 0,
  },

  offset: 0,
  limit: 5,
  version: null,
  creatorViewable: false,
};

const makeReviewUIObject = (review) =>
  //
   ({
     ...review,
     modifiable: false,
     beforeText: review.text,
   });

const reviewReducer = (state = initialState, action) => {
  //
  let reviews = [];
  let review = {};
  let version = null;

  switch (action.type) {
    //
    case actionTypes.FIND_REVIEWS:
      version = action.version;
      reviews = action.reviews.results.map((reviewObj) => makeReviewUIObject(reviewObj));
      return {
        ...state,
        reviews: { ...action.reviews, results: reviews },
        version,
        offset: action.offset,
        limit: action.limit,
      };

    case actionTypes.ADD_REVIEWS:
      version = action.version;
      reviews = state.reviews.results ?
        [...state.reviews.results, ...action.reviews.results] : action.reviews.results;
      reviews = reviews.map((reviewObj) => makeReviewUIObject(reviewObj));
      return {
        ...state,
        reviews: { ...action.reviews, results: reviews },
        version,
        offset: action.offset,
        limit: action.limit,
      };

    case actionTypes.RESET_REVIEW:
      reviews = { ...state.reviews };
      if (state.reviews && state.reviews.results) {
        state.reviews.results[action.index] = makeReviewUIObject(action.review);
      }
      return { ...state, reviews };

    case actionTypes.RESET_REVIEWS:
      reviews = { ...state.reviews };
      if (state.reviews && state.reviews.results) {
        state.reviews.results[action.index] = makeReviewUIObject(action.review);
      }
      return { ...state, reviews };

    case actionTypes.CHANGE_REVIEW_PROPS:
      reviews = null;
      return { ...state, reviews };

    case actionTypes.TOGGLE_REVIEW_CREATOR:
      review = { ...state.review, title: null, opinion: null, selectedStar: 0 };
      return { ...state, creatorViewable: action.creatorViewable, review };

    default :
      return state;
  }
};

export default reviewReducer;
