const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path');

module.exports = {

  entry: {
    'vendor': './app/Vendor.js',
    'app': './app/App.js',
    'drama-feedback': './app/shared.js',
  },

  resolve: {
    modules: [path.resolve(__dirname, 'app'), 'node_modules', 'bower_components'],
    descriptionFiles: ['package.json', 'bower.json'],
    extensions: ['.js', '.jsx'],
  },

  module: {
    loaders: [
      {
        test: /\.js/,
        loader: 'imports-loader?define=>false',
      },
      {
        test: /\.js?$/,
        exclude: /(node_modules|bower_components)/,
        loaders: ['react-hot-loader'],
      },
      {
        test: /\.js?$/,
        exclude: /(node_modules|bower_components)/,
        loader: 'babel-loader',
        query: {
          presets: ['es2015', 'stage-2', 'react'],
          compact: false,
          plugins: [
            'dev-expression',
            'transform-runtime',
            'transform-es3-member-expression-literals',
            'transform-es3-property-literals',
            'add-module-exports',
          ],
        },
      },
    ],
  },

  plugins: [
    new HtmlWebpackPlugin({
      template: 'app/index.html',
      baseUrl: '/',
      xhtml: true,
    }),
    new webpack.ProvidePlugin({
      $: 'jquery',
      jQuery: 'jquery',
      'window.jQuery': 'jquery',
    }),
    new webpack.ContextReplacementPlugin(/\.\/locale$/, 'empty-module', false, /js$/),
  ],

  externals: {
    'jquery': 'var NaraVendor.JQuery',
    'react': 'var NaraVendor.React',
    'react-dom': 'var NaraVendor.ReactDOM',
    'react-autobind': 'var NaraVendor.ReactAutobind',
    'react-router': 'var NaraVendor.ReactRouter',
    'redux': 'var NaraVendor.Redux',
    'redux-thunk': 'var NaraVendor.ReduxThunk',
    'react-redux': 'var NaraVendor.ReactRedux',
    'react-router-redux': 'var NaraVendor.ReactRouterRedux',
    'react-bootstrap': 'var NaraVendor.ReactBootstrap',
    'react-router-bootstrap': 'var NaraVendor.ReactRouterBootstrap',
    'whatwg-fetch': 'var NaraVendor.WhatwgFetch',

    'nara-core': 'var NaraLib.NaraCore',
    'nara-react': 'var NaraLib.NaraReact',
  },
};
