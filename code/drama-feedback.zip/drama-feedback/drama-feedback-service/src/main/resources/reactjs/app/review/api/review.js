import NaraAjax from '../../../nara_modules/naraAjax';

export default (baseUrl) => {
  //
  const url = baseUrl ? baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/` : '';

  return {
    findReview: (reviewId) => NaraAjax.getJSON(`${url}feedback-api/reviews/${reviewId}`),
    findReviews: (feedbackId, offset, limit) => NaraAjax.getJSON(`${url}feedback-api/reviews?feedbackId=${feedbackId}&offset=${offset}&limit=${limit}`),
    findReviewsByVersion: (feedbackId, version, offset, limit) => NaraAjax.getJSON(`${url}feedback-api/reviews/version/${version}?feedbackId=${feedbackId}&offset=${offset}&limit=${limit}`),
    registerReview: (feedbackId, reviewCdo) => NaraAjax.postJSON(`${url}feedback-api/reviews?feedbackId=${feedbackId}`, reviewCdo),
    registerVersionedReview: (feedbackId, version, reviewCdo) => NaraAjax.postJSON(`${url}feedback-api/reviews/version/${version}?feedbackId=${feedbackId}`, reviewCdo),
    addHelpComment: (reviewId, helpCommentCdo) => NaraAjax.postJSON(`${url}feedback-api/reviews/${reviewId}/help`, helpCommentCdo),
  };

};
