import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { feedbackActionBuilder } from '../feedback/module/feedback';

import Sidebar from './Sidebar';

class BaseContainer extends Component {
  //
  constructor(props) {
    //
    super(props);
    autoBind(this);
  }

  // override
  componentWillMount() {
    //
    this.props.feedbackActions.findFeedbackList();
  }

  render() {
    const props = this.props;

    return (
      <div className="wrapper">
        <Sidebar
          feedbackList= {props.feedbackState.feedbackList}
        />
        <section>
          {props.children != null ? React.cloneElement(props.children, {}) : ''}
        </section>
      </div>
    );
  }
}


const mapStateToProps = ({ feedback }) => ({
  feedbackState: feedback,
});

const mapDispatchToProps = (dispatch) => ({
  feedbackActions: bindActionCreators(feedbackActionBuilder(DRAMA_CONTEXT.basePath), dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(BaseContainer);
