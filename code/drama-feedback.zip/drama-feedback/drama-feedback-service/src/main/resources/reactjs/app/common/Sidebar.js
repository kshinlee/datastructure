import React, { Component } from 'react';
import { Router, Route, Link, History, withRouter } from 'react-router';
import { Collapse } from 'react-bootstrap';
import SidebarRun from './Sidebar.run';

class Sidebar extends Component {

  constructor(props, context) {
    super(props, context);
    this.state = {
    };
  }

  componentDidMount() {
    // pass navigator to access router api
    SidebarRun(this.navigator.bind(this));
  }

  navigator(route) {
    this.props.router.push(route);
  }

  componentWillUnmount() {
    // React removed me from the DOM, I have to unsubscribe from the pubsub using my token
  }

  routeActive(paths) {
    const pathArr = Array.isArray(paths) ? paths : [paths];

    for (const p in pathArr) {
      if (this.props.router.isActive(pathArr[p]) === true) { return true; }
    }
    return false;
  }

  render() {
    const rootPath = `${DRAMA_CONTEXT.basePath}`;
    const feedbackList = this.props.feedbackList === null ?
    null : this.props.feedbackList;

    return (
      <aside className="aside">
        <div className="aside-inner">
          <nav data-sidebar-anyclick-close="" className="sidebar">
            <ul className="nav">
              <li className={ this.routeActive([`${rootPath}feedback`]) ? 'active' : '' }>
                <Link to="feedback" title="피드백 관리">
                  <em className="icon-grid"></em>
                  <span data-localize="sidebar.nav.WIDGETS">피드백 관리</span>
                </Link>
              </li>
              {
                feedbackList && feedbackList.results && feedbackList.results.length ?
                  feedbackList.results.map((feedback) => (
                      <li key={feedback.id} className={ this.routeActive([`${rootPath}feedback/${feedback.id}`]) ? 'active' : '' }>
                        {
                          feedback.type === 'Reply' ?
                            <Link to={`${rootPath}feedback/${feedback.id}/reply`} title={feedback.title}>
                              <em className="icon-grid"></em>
                              <span data-localize="sidebar.nav.WIDGETS">{feedback.title}</span>
                            </Link> :
                            feedback.type === 'Review' ?
                              <Link to={`${rootPath}feedback/${feedback.id}/review${feedback.config.versionBased ? '/v1' : ''}`} title={feedback.title}>
                                <em className="icon-grid"></em>
                                <span data-localize="sidebar.nav.WIDGETS">{feedback.title}</span>
                              </Link> :
                              <Link to={`${rootPath}feedback/${feedback.id}/${feedback.type.toString().toLowerCase()}`} title={feedback.title}>
                                <em className="icon-grid"></em>
                                <span data-localize="sidebar.nav.WIDGETS">{feedback.title}</span>
                              </Link>
                        }

                      </li>
                    ))
                  : ''
              }
            </ul>
          </nav>
        </div>
      </aside>
    );
  }
}
export default withRouter(Sidebar);
