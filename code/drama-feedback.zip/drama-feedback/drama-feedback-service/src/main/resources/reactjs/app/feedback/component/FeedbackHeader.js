import React from 'react';

const FeedbackHeader = () =>
  //
   (
    <h3>
      <span className="mr">피드백관리</span>
      <ol className="breadcrumb">
        <li className="active">피드백관리</li>
      </ol>
    </h3>
    );

export default FeedbackHeader;

