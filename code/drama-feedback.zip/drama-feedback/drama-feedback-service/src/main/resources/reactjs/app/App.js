import React from "react";
import ReactDOM from "react-dom";
import {browserHistory, IndexRoute, Link, Route, Router, IndexRedirect} from "react-router";
import {Provider} from "react-redux";
import {syncHistoryWithStore} from "react-router-redux";
import feedbackStore from "./store";
import Base from "./common/BaseContainer";
import FeedbackList from "./feedback/container/FeedbackListContainer";
import ReplyList from "./reply/container/ReplyListContainer";
import ReviewList from "./review/container/ReviewListContainer";

const feedbackHistory = syncHistoryWithStore(browserHistory, feedbackStore, {
});

ReactDOM.render(
  <Provider store={feedbackStore}>
    <Router history={feedbackHistory}>
      <Route path={DRAMA_CONTEXT.basePath}>
        <IndexRedirect to="base"/>
        <Route path="base" component={Base}>
          <IndexRedirect to="feedback"/>
          <Route path="feedback" component={FeedbackList}>
            <Route path="creator" component={FeedbackList}/>
            <Route path=":feedbackId" component={FeedbackList}/>
          </Route>
        </Route>
        <Route path="feedback/:feedbackId">
          <Route path="reply" component={ReplyList}/>
          <Route path="review" component={ReviewList}>
            <Route path=":version" component={ReviewList}/>
          </Route>
        </Route>
      </Route>
    </Router>
  </Provider>,
  document.getElementById('app'),
);
// Auto close sidebar on route changes
feedbackHistory.listen(function(ev) {
  $('body').removeClass('aside-toggled');
});
