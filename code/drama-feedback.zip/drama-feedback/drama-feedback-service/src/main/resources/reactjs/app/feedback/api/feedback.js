import NaraAjax from '../../../nara_modules/naraAjax';

export default (baseUrl) => {
  //
  const url = baseUrl ? baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/` : '';

  return {
    findFeedbackList: (pavilionId) => NaraAjax.getJSON(`${url}feedback-api/feedback?pavilionId=${pavilionId}`),
    findFeedback: (id) => NaraAjax.getJSON(`${url}feedback-api/feedback/${id}`),
    registerReplyFeedback: (feedbackCdo) => NaraAjax.postJSON(`${url}feedback-api/feedback/reply`, feedbackCdo),
    registerReviewFeedback: (feedbackCdo) => NaraAjax.postJSON(`${url}feedback-api/feedback/review`, feedbackCdo),
    modifyFeedback: (id, nameValueList) => NaraAjax.putJSON(`${url}feedback-api/feedback/${id}`, nameValueList),
  };
};
