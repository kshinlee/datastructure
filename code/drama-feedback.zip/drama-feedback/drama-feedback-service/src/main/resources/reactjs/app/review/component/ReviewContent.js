import React from 'react';

const ReviewContent = (props) =>
  //
  (
    <div className={props.isLast ? 'panel-body p-lg' : 'panel-body p-lg bb-dashed'}>
      <div className="media">
        <div className="pull-right text-muted">
          {props.review.time ? new Date(props.review.time).toLocaleDateString() : ''}
        </div>
        <div className="media-body">
          <span className="media-heading">
            <p className="m0">
              <span className="">{props.review.title || ''}</span>
            </p>
            <div className="ant-rate-wrap">
              <ul className="ant-rate ant-rate-disabled">
                {
                  props.maxStartCountArray && props.maxStartCountArray.length > 0 ?
                    props.maxStartCountArray.map((value, index) => (
                      <li
                        className={`ant-rate-star ant-rate-star-${props.review.selectedStar > index ? 'full' : 'zero'}`}
                        key={`${props.review.id}_review_star_${index}`}
                      >
                        <div className="ant-rate-star-second">
                          <em className="fa fa-star"></em>
                        </div>
                      </li>
                    )) : ''
                }
              </ul>
              <span className="ant-rate-text text-sm">
                {props.review.writer && props.review.writer.name ? props.review.writer.name : ''} 님 작성
              </span>
            </div>
            <p className="m0">
              {
                props.review.opinion ? props.review.opinion.split(/\r?\n/g).map((item, key) => (
                  <span key={key}>
                      {item}
                    <br/>
                    </span>
                )) : ''
              }
            </p>
            <div className="mt">
              <div
                className="ant-rate-like" title="도움이 됐어요."
                onClick={props.addHelpComment}
              >
                <em className="fa fa-thumbs-o-up"></em>
                <span className="text-muted ml-sm">{props.review.helpCount.left}</span>
              </div>
              {/*<div className="ant-rate-unlike" title="도움이 되지 않았어요.">
                <em className="fa fa-thumbs-o-down"></em>
                <span className="text-muted ml-sm">2,234</span>
              </div>*/}
            </div>
           </span>
        </div>
      </div>
    </div>
  )


export default ReviewContent;
