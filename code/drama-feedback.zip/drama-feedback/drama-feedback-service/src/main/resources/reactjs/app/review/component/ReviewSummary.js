import React from 'react';
import { Row, Col, Button, ButtonGroup, ProgressBar } from 'react-bootstrap';

const ReviewSummary = (props) => {
  //
  const totalSummary = [], starSummary = [];
  const reviewerCount = props.isCurrently && props.reviewSummary.versionBased &&
    props.reviewSummary.versionReviewerCountMap ?
    props.reviewSummary.versionReviewerCountMap[props.version] ?
    props.reviewSummary.versionReviewerCountMap[props.version] : 0 :
    props.reviewSummary.reviewerCount;
  const maxStarCount = props.reviewSummary.maxStarCount ? props.reviewSummary.maxStarCount : 0;
  const starCounts = props.isCurrently && props.reviewSummary.versionBased &&
    props.reviewSummary.versionStarCountMap ?
    props.reviewSummary.versionStarCountMap[props.version] ?
    props.reviewSummary.versionStarCountMap[props.version].list : [] :
    props.reviewSummary.starCounts ? props.reviewSummary.starCounts.list : [];
  let average = props.reviewSummary.average ? parseInt(props.reviewSummary.average) : 0;

  if (props.isCurrently && props.reviewSummary.versionBased && props.reviewSummary && props.reviewSummary.versionStarCountMap) {
    const intPairs = props.reviewSummary.versionStarCountMap ?
      props.reviewSummary.versionStarCountMap[props.version] &&
      props.reviewSummary.versionStarCountMap[props.version].list ?
      props.reviewSummary.versionStarCountMap[props.version].list : [] : [];
    let totalStarCount = 0;

    intPairs.forEach((intPair) => totalStarCount += (intPair.left * intPair.right));
    average = parseInt(totalStarCount / reviewerCount);
  }

  for (let index = 0; index < maxStarCount; index++) {
    const starSummaryLi = [];

    totalSummary.push(
      <li className={`ant-rate-star ant-rate-star-${average>index ? 'full' : 'zero'}`} key={`totalSummary_${index}`}>
        <div className="ant-rate-star-second"><em className="fa fa-star"></em></div>
      </li>,
    );
    for (let idx = 0; idx < maxStarCount; idx++) {
      starSummaryLi.push(
        <li className={`ant-rate-star ant-rate-star-${index>=idx ? 'full' : 'zero'}`} key={`starSummaryLi_${idx}`}>
          <div className="ant-rate-star-second"><em className="fa fa-star"></em></div>
        </li>,
      );
    }
    starSummary.push(
      <Col md={ 12 }>
        <div className="pull-left">
          <ul className="ant-rate ant-rate-disabled ant-rate-gray">
            {starSummaryLi}
          </ul>
        </div>
        <div className="ant-rate-progress">
          <ProgressBar
            className="progress-xs"
            bsClass="progress-bar progress-bar-gray"
            now={ starCounts[index] && starCounts[index].right ?
              parseInt(starCounts[index].right/reviewerCount * 100)  : 0 } />
        </div>
      </Col>
    );
  }


  return (
    <div>
      <div className="panel-body bb">
        <div className="pull-right">
          {
            props.creatorViewable ? '' :
            <Button
              bsStyle="primary"
              onClick={() => props.toggleReviewCreator(true)}
            >리뷰 작성</Button>
          }
          {
            props.reviewSummary.versionBased ?
            <ButtonGroup>
              <Button
                bsStyle={props.isCurrently ? 'default active' : 'default'}
                onClick={() => props.toggleCurrently(true)}
              >현재버전</Button>
              <Button
                bsStyle={!props.isCurrently ? 'default active' : 'default'}
                onClick={() => props.toggleCurrently(false)}
              >모든버전</Button>
            </ButtonGroup> : ''
          }
        </div>
        <div className="panel-title panel-title-small">평가 및 리뷰</div>
      </div>
      <div className="panel-body p-lg bb-dashed">
        <Row>
          <Col md={ 12 }>
            <ul className="ant-rate ant-rate-disabled">
              {totalSummary}
            </ul>
            <span className="ant-rate-text">{reviewerCount}개의 평가</span>
          </Col>
          {starSummary}
        </Row>
      </div>
    </div>
  );
};

export default ReviewSummary;
