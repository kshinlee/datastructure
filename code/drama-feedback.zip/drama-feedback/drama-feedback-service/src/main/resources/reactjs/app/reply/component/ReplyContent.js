import React from 'react';
import { Grid, Row, Col, Button, FormGroup, FormControl } from 'react-bootstrap';
import CommentList from './CommentList';

const ReplyContent = (props) => (
  <div>
    <div className="panel-body">
      {
        props.reply.modifiable ?
        <div className="media">
          <small className="pull-right">
            <Button
              bsStyle="primary"
              onClick={props.modifyReply}
            >저장</Button>
            <Button
              bsStyle="default"
              onClick={props.toggleReplyModifiable}
            >취소</Button>
          </small>
          <div className="media-body">
            <span className="media-heading">
              <textarea
                placeholder="댓글을 입력하세요." rows="1" className="form-control no-resize"
                value={
                  props.reply.text || props.reply.beforeText ?
                    (props.reply.text !== props.reply.beforeText ? props.reply.text : props.reply.beforeText) : ''
                }
                onChange={(e) => props.changeReplyText(e.target.value)}
              >
              </textarea>
            </span>
          </div>
        </div> :
        <div className="media">
          <small className="pull-right text-muted">
            <Button
              bsStyle="success" bsSize="xsmall"
              onClick={props.addComment}
            >덧글</Button>
            {
              DRAMA_CONTEXT.userId === props.reply.writer.id ?
                <Button
                  bsStyle="default" bsSize="xsmall"
                  onClick={props.toggleReplyModifiable}
                >수정</Button> : ''
            }
            {
              DRAMA_CONTEXT.userId === props.reply.writer.id ?
              < Button
                bsStyle="default" bsSize="xsmall"
                onClick={props.removeReply}
              >삭제</Button> : ''
            }
          </small>
          <div className="media-body">
        <span className="media-heading">
          <p className="m0">
            <a href="#">
              <strong>
                {props.reply.writer && props.reply.writer.name ? props.reply.writer.name : ''}
              </strong>
            </a>
            <small className="text-muted pl">
              {props.reply.time ? new Date(props.reply.time).toLocaleDateString() : ''}
            </small>
          </p>
          <p className="m0">
            {
              props.reply.text ? props.reply.text.split(/\r?\n/g).map((item, key) => (
                  <span key={key}>
                    {item}
                    <br/>
                  </span>
                )) : ''
            }
          </p>
        </span>
          </div>
        </div>
      }
    </div>
    <CommentList
      comments={props.reply.comments ? props.reply.comments.list : []}
      saveComment={props.saveComment}
      removeComment={props.removeComment}
      toggleCommentModifiable={props.toggleCommentModifiable}
      changeCommentText={props.changeCommentText}
    />

  </div>
);

export default ReplyContent;
