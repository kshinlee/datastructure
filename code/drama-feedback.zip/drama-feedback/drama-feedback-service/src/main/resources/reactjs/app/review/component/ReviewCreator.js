import React from 'react';
import { Button, FormGroup, FormControl } from 'react-bootstrap';

const ReviewCreator = (props) => {
  const maxStartCountArray = [];

  if (props.maxStarCount && props.maxStarCount > 0) {
    for (let index = 0; index < props.maxStarCount; index++) maxStartCountArray.push(0);
  }

  return (
    <div className="panel-body bb-dashed" style={{ display: props.creatorViewable ? 'block' : 'none' }}>
      <div className="media">
        <small className="pull-right">
          <Button
            bsStyle="primary"
            onClick={props.registerReview}
          >저장</Button>
          <Button
            bsStyle="default"
            onClick={() => props.toggleReviewCreator(false)}
          >취소</Button>
        </small>
        <div className="media-body">
          <form>
            <div className="ant-rate-wrap mb ml">
              <ul className="ant-rate">
                {
                  maxStartCountArray && maxStartCountArray.length > 0 ?
                    maxStartCountArray.map((value, index) => (
                        <li
                          className={`ant-rate-star ant-rate-star-${props.review.selectedStar > index ? 'full' : 'zero'}`}
                          onClick={() => props.changeReviewProps('selectedStar', index + 1)}
                        >
                          <div className="ant-rate-star-second">
                            <em className="fa fa-star"></em>
                          </div>
                        </li>
                      )) : ''
                }
              </ul>
              <span className="ant-rate-text text-sm text-muted">평가하려면 별표 선택하기</span>
            </div>
            <FormGroup>
              <FormControl
                type="text" className="form-control" placeholder="제목을 입력하세요."
                value={props.review.title || ''}
                onChange={(e) => props.changeReviewProps('title', e.target.value)}
              />
            </FormGroup>
            <FormGroup>
              <textarea
                rows="3" className="form-control resize-none" placeholder="내용을 입력하세요."
                value={props.review.opinion || ''}
                onChange={(e) => props.changeReviewProps('opinion', e.target.value)}
              >
              </textarea>
            </FormGroup>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ReviewCreator;
