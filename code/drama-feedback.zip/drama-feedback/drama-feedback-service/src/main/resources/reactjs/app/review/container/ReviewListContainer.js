import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Grid, Row, Col } from 'react-bootstrap';

import { reviewActionBuilder } from '../module/review';
import { reviewSummaryActionBuilder } from '../module/reviewSummary';

import ContentWrapper from '../../common/ContentWrapper';
import ReviewCreator from '../component/ReviewCreator';
import ReviewSummary from '../component/ReviewSummary';
import ReviewList from '../component/ReviewList';

class ReviewListContainer extends Component {
  //
  constructor(props) {
    super(props);
    autoBind(this);
  }

  componentWillMount() {
    //
    const props = this.props;

    if (props.params.feedbackId) {
      props.reviewActions.findReviewSummary(props.params.feedbackId, (versionBased) => {
        this.findReviews(props.params.feedbackId, versionBased, props.params.version);
      });
    }
  }

  componentWillReceiveProps(nextProps) {
    //
    const props = this.props;
    const feedbackId = props.params.feedbackId;
    const nextFeedbackId = nextProps.params.feedbackId;
    const version = props.params.version;
    const nextVersion = nextProps.params.version;

    if ((nextFeedbackId || feedbackId) && feedbackId !== nextFeedbackId) {
      props.reviewActions.findReviewSummary(nextFeedbackId || feedbackId, (versionBased) => {
        this.findReviews(nextFeedbackId || feedbackId, versionBased, nextVersion || version);
      });
    }
  }

  findReviews(feedbackId, versionBased, version) {
    if (!versionBased) {
      this.props.reviewActions.findReviews(feedbackId);
    } else {
      this.props.reviewActions.findReviewsByVersion(feedbackId, version);
    }
  }

  addReviews() {
    const feedbackId = this.props.params.feedbackId;
    const version = this.props.params.version;
    const versionBased = this.props.reviewState.reviewSummary.versionBased;
    const offset = this.props.reviewState.offset + this.props.reviewState.limit;
    const limit = this.props.reviewState.limit;

    if (!versionBased || (versionBased && !this.props.reviewState.isCurrently)) {
      this.props.reviewActions.addReviews(feedbackId, offset, limit);
    } else {
      this.props.reviewActions.addVersionedReviews(feedbackId, version, offset, limit);
    }
  }

  toggleCurrently(isCurrently) {
    this.props.reviewActions.toggleCurrently(this.props.params.feedbackId, isCurrently);
  }

  registerReview() {
    const feedbackId = this.props.params.feedbackId;
    const version = this.props.params.version;
    const reviewCdo = {
      writer: {
        id: DRAMA_CONTEXT.userId,
        name: DRAMA_CONTEXT.userName,
      },
      title: this.props.reviewState.review.title,
      opinion: this.props.reviewState.review.opinion,
      selectedStar: this.props.reviewState.review.selectedStar,
    };
    const callback = () => {
      const versionBased = this.props.reviewState.versionBased ?
        this.props.reviewState.isCurrently ? true : false : false;

      this.props.reviewActions.findReviewSummary(feedbackId, () => {
        this.findReviews(feedbackId, versionBased, version);
      });
      this.props.reviewActions.toggleReviewCreator(false);
    }

    if (!version) {
      this.props.reviewActions.registerReview(feedbackId, reviewCdo, callback);
    } else {
      this.props.reviewActions.registerVersionedReview(feedbackId, version, reviewCdo, callback);
    }
  }

  addHelpComment(reviewId, reviewIndex) {
    //
    const helpCommentCdo = {
      reviewerId: DRAMA_CONTEXT.userId,
      helpful: true,
    }

    this.props.reviewActions.addHelpComment(reviewId, helpCommentCdo, reviewIndex);
  }

  render() {
    //
    const props = this.props;

    return (
      <ContentWrapper>
        <Grid fluid>
          <Row>
            <Col md={ 12 }>
              <div className="panel panel-default">
                <ReviewCreator
                  review={props.reviewState.review}
                  maxStarCount={
                    props.reviewState.reviewSummary.maxStarCount ?
                      props.reviewState.reviewSummary.maxStarCount : 0
                  }
                  registerReview={this.registerReview}
                  changeReviewProps={props.reviewActions.changeReviewProps}
                  toggleReviewCreator={props.reviewActions.toggleReviewCreator}
                  creatorViewable={props.reviewState.creatorViewable}
                />
                <ReviewSummary
                  version={props.params.version}
                  isCurrently={props.reviewState.isCurrently}
                  reviewSummary={props.reviewState.reviewSummary}
                  creatorViewable={props.reviewState.creatorViewable}
                  toggleCurrently={(isCurrently) => this.toggleCurrently(isCurrently)}
                  toggleReviewCreator={props.reviewActions.toggleReviewCreator}
                />
                <ReviewList
                  maxStarCount={
                    props.reviewState.reviewSummary.maxStarCount ?
                    props.reviewState.reviewSummary.maxStarCount : 0
                  }
                  reviews={props.reviewState.reviews}
                  addHelpComment={this.addHelpComment}
                />
                {
                  props.reviewState.reviews && props.reviewState.reviews.results &&
                  props.reviewState.reviews.results.length < props.reviewState.reviews.totalCount ?
                  <div className="panel-body bg-gray-lighter">
                    <a
                      className="link-unstyled"
                      onClick={this.addReviews}
                    >
                      리뷰 더보기
                    </a>
                  </div> : ''
                }
              </div>
            </Col>
          </Row>
        </Grid>
      </ContentWrapper>
    );
  }
}

const mapStateToProps = ({ review, reviewSummary }) => ({
  reviewState: { ...review, ...reviewSummary },
});

const mapDispatchToProps = (dispatch) => ({
  reviewActions: bindActionCreators({
    ...reviewActionBuilder(DRAMA_CONTEXT.basePath),
    ...reviewSummaryActionBuilder(DRAMA_CONTEXT.basePath)
  }, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(ReviewListContainer);

