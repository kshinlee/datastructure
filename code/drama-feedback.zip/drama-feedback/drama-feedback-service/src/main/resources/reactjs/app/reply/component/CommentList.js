import React from 'react';
import { Grid, Row, Col, Button, FormGroup, FormControl } from 'react-bootstrap';
import CommentContent from './CommentContent';

const CommentList = (props) => (
  <div>
    {
      props.comments && props.comments.length > 0 ?
        props.comments.map((comment, index) => (
          <CommentContent
            key={`${comment.replyId}_${index}`}
            comment={comment}
            saveComment={() => props.saveComment(comment)}
            removeComment={() => props.removeComment(comment.sequence)}
            changeCommentText={(text) => props.changeCommentText(index, text)}
            toggleCommentModifiable={
              () => props.toggleCommentModifiable(index, !comment.modifiable)
            }
          />
        )) :
        ''
    }
  </div>
);

export default CommentList;
