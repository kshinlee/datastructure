import ReviewSummaryApiBuilder from '../api/reviewSummary';
import { reviewActionBuilder } from './review';

export const actionTypes = {
  FIND_REVIEW_SUMMARY: 'FIND_REVIEW_SUMMARY',
  RESET_REVIEW_SUMMARY: 'RESET_REVIEW_SUMMARY',

  TOGGLE_CURRENTLY: 'TOGGLE_CURRENTLY',
};

let ReviewSummaryApi = null;
let reviewAction = null;

const reviewSummaryAction = {
  //
  findReviewSummary(feedbackId, callback) {
    //
    const loadSuccess = (reviewSummary) => ({
      type: actionTypes.FIND_REVIEW_SUMMARY,
      reviewSummary,
    });

    return (dispatch) => {
      ReviewSummaryApi.findReviewSummary(feedbackId)
        .then((reviewSummary) => {
          dispatch(loadSuccess(reviewSummary));
          if (callback && typeof callback === 'function') {
            callback(reviewSummary.versionBased);
          }
        });
    };
  },

  resetReviewSummary() {
    //
    return {
      type: actionTypes.RESET_REVIEW_SUMMARY,
    };
  },

  toggleCurrently(feedbackId, isCurrently) {
    //
    const loadSuccess = () => ({
      type: actionTypes.TOGGLE_CURRENTLY,
      isCurrently,
    });


    return (dispatch, getState) => {
      const version = getState().review.version;

      dispatch(loadSuccess());

      if (!isCurrently) reviewAction.findReviews(feedbackId)(dispatch, getState);
      else reviewAction.findReviewsByVersion(feedbackId, version)(dispatch, getState);
    };
  },
};

export const reviewSummaryActionBuilder = (baseUrl) => {
  //
  ReviewSummaryApi = ReviewSummaryApiBuilder(baseUrl);
  reviewAction = reviewActionBuilder(baseUrl);

  return reviewSummaryAction;
};

const initialState = {
  reviewSummary: {},
  isCurrently: true,
};

const reviewSummaryReducer = (state = initialState, action) => {
  //
  switch (action.type) {
    //
    case actionTypes.FIND_REVIEW_SUMMARY:
      return { ...state, reviewSummary: action.reviewSummary };

    case actionTypes.RESET_REVIEW_SUMMARY:
      return { ...state, reviewSummary: null };

    case actionTypes.TOGGLE_CURRENTLY:
      return { ...state, isCurrently: action.isCurrently };

    default :
      return state;
  }
};

export default reviewSummaryReducer;
