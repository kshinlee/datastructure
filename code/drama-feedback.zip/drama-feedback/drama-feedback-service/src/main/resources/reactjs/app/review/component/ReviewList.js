import React from 'react';
import ReviewContent from './ReviewContent';

const ReviewList = (props) => {
  //
  const maxStartCountArray = [];

  if (props.maxStarCount && props.maxStarCount > 0) {
    for (let index = 0; index < props.maxStarCount; index++) maxStartCountArray.push(0);
  }

  return (
    <div
      className={
        props.reviews && props.reviews.results &&
        props.reviews.results.length < props.reviews.totalCount ?
        'bb-dashed' : ''
      }
    >
      {
        props.reviews && props.reviews.results ?
          props.reviews.results.map((review, index) => (
            <ReviewContent
              review={review}
              isLast={props.reviews.results.length === index+1}
              maxStartCountArray={maxStartCountArray}
              addHelpComment={() => props.addHelpComment(review.id, index)}
            />
          )) : ''
      }
    </div>
  );
};

export default ReviewList;
