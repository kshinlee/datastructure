import ReplyApiBuilder from '../api/reply';

export const actionTypes = {
  FIND_REPLIES: 'FIND_REPLIES',
  ADD_REPLY: 'ADD_REPLY',
  ADD_NEW_REPLY: 'ADD_NEW_REPLY',
  ADD_REPLIES: 'ADD_REPLIES',
  REMOVE_REPLY: 'REMOVE_REPLY',
  RESET_REPLY: 'RESET_REPLY',
  RESET_REPLIES: 'RESET_REPLIES',

  ADD_COMMENT: 'ADD_COMMENT',

  CHANGE_TEXT: 'CHANGE_TEXT',
  CHANGE_REPLY_TEXT: 'CHANGE_REPLY_TEXT',
  CHANGE_COMMENT_TEXT: 'CHANGE_COMMENT_TEXT',

  TOGGLE_REPLY_MODIFIABLE: 'TOGGLE_REPLY_MODIFIABLE',
  TOGGLE_COMMENT_MODIFIABLE: 'TOGGLE_COMMENT_MODIFIABLE',
};

let ReplyApi = null;

const replyAction = {
  //
  findReplies(feedbackId) {
    //
    const loadSuccess = (replies) => ({
      type: actionTypes.FIND_REPLIES,
      replies,
    });

    return (dispatch) => {
      ReplyApi.findReplies(feedbackId, initialState.offset, initialState.limit)
        .then((replies) => dispatch(loadSuccess(replies)));
    };
  },

  registerReply(feedbackId, replyCdo) {
    //
    return (dispatch) => {
      ReplyApi.registerReply(feedbackId, replyCdo)
        .then((id) => {
          replyAction.addNewReply(id)(dispatch);
        });
    };
  },

  modifyReply(reply, index) {
    //
    let nameValues = [];
    for (const prop in reply) {
      const value = reply[prop] !== null && typeof reply[prop] === 'object' ?
        JSON.stringify(reply[prop]) : reply[prop];

      nameValues.push({ name: prop, value });
    }

    return (dispatch) => {
      ReplyApi.modifyReply(reply.id, { nameValues })
        .then(() => {
          dispatch(replyAction.changeReplyText(index, reply.text, true));
          dispatch(replyAction.toggleReplyModifiable(index, false));
        });
    };
  },

  removeReply(feedbackId, replyId, index) {
    //
    const loadSuccess = (index) => ({
      type: actionTypes.REMOVE_REPLY,
      index,
    });

    return (dispatch, getState) => {
      ReplyApi.removeReply(replyId)
        .then(() => {
          const replyState = getState().reply;
          const offset = replyState.offset + replyState.limit -1;
          const limit = 1;

          ReplyApi.findReplies(feedbackId, offset, limit)
            .then((replies) => {
              if (replies && replies.results && replies.results.length > 0) {
                dispatch(loadSuccess(index));
                dispatch(replyAction.addReply(replies.results[0]));
              }
            });
        });
    };
  },

  resetReply(replyId, index) {
    //
    const loadSuccess = (reply) => ({
      type: actionTypes.RESET_REPLY,
      reply,
      index,
    });

    return (dispatch) => {
      ReplyApi.findReply(replyId)
        .then((reply) => dispatch(loadSuccess(reply, index)));
    };
  },

  resetReplies() {
    //
    return {
      type: actionTypes.RESET_REPLIES,
    };
  },

  addNewReply(replyId) {
    //
    const loadSuccess = (reply) => ({
      type: actionTypes.ADD_NEW_REPLY,
      reply,
    });

    return (dispatch) => {
      ReplyApi.findReply(replyId)
        .then((reply) => dispatch(loadSuccess(reply)));
    };
  },

  addReply(reply) {
    //
    return {
      type: actionTypes.ADD_REPLY,
      reply,
    }
  },

  addReplies(feedbackId, offset, limit) {
    //
    const loadSuccess = (replies, offset, limit) => ({
      type: actionTypes.ADD_REPLIES,
      replies,
      offset,
      limit,
    });

    offset = offset ? offset : initialState.offset;
    limit = limit ? limit : initialState.limit;

    return (dispatch) => {
      ReplyApi.findReplies(feedbackId, offset, limit)
        .then((replies) => dispatch(loadSuccess(replies, offset, limit)));
    };
  },

  registerComment(replyId, commentCdo, replyIndex) {
    //
    return (dispatch) => {
      ReplyApi.addComment(replyId, commentCdo)
        .then(() => {
          replyAction.resetReply(replyId, replyIndex)(dispatch);
        });
    };
  },

  modifyComment(replyId, comment, replyIndex) {
    //
    return (dispatch) => {
      ReplyApi.modifyComment(replyId, comment.sequence, comment.text)
        .then(() => {
          replyAction.resetReply(replyId, replyIndex)(dispatch);
        });
    };
  },

  removeComment(replyId, sequence, replyIndex) {
    //
    return (dispatch) => {
      ReplyApi.removeComment(replyId, sequence)
        .then(() => {
          replyAction.resetReply(replyId, replyIndex)(dispatch);
        });
    };
  },

  addComment(replyId, index) {
    //
    const comment = {
      replyId,
      writer: {
        id: DRAMA_CONTEXT.userId,
        name: DRAMA_CONTEXT.userName,
      },
      text: null,
      modifiable: true,
    };

    return {
      type: actionTypes.ADD_COMMENT,
      comment,
      index,
    };
  },

  changeText(text) {
    //
    return {
      type: actionTypes.CHANGE_TEXT,
      text,
    };
  },

  changeReplyText(index, text, isBefore) {
    //
    return {
      type: actionTypes.CHANGE_REPLY_TEXT,
      index,
      text,
      isBefore,
    };
  },

  changeCommentText(replyIndex, index, text, isBefore) {
    //
    return {
      type: actionTypes.CHANGE_COMMENT_TEXT,
      replyIndex,
      index,
      text,
      isBefore,
    };
  },

  toggleReplyModifiable(index, modifiable) {
    //
    return {
      type: actionTypes.TOGGLE_REPLY_MODIFIABLE,
      index,
      modifiable,
    };
  },

  toggleCommentModifiable(replyIndex, index, modifiable) {
    //
    return {
      type: actionTypes.TOGGLE_COMMENT_MODIFIABLE,
      replyIndex,
      index,
      modifiable,
    };
  },
};

export const replyActionBuilder = (baseUrl) => {
  //
  ReplyApi = ReplyApiBuilder(baseUrl);

  return replyAction;
};

const initialState = {
  replies: null,
  text: null,

  offset: 0,
  limit: 5,
};

const makeReplyUIObject = (reply) => {
  //
  const comments = { ...reply.comments };

  if (comments.list !== null && comments.list.length > 0) {
    comments.list = comments.list.map(
      (comment) => ({ ...comment, modifiable: false, beforeText: comment.text }),
    );
  }
  return {
    ...reply,
    modifiable: false,
    beforeText: reply.text,
    comments,
  };
};

const replyReducer = (state = initialState, action) => {
  //
  let replies = [];

  switch (action.type) {
    //
    case actionTypes.FIND_REPLIES:
      replies = action.replies.results.map((reply) => makeReplyUIObject(reply));
      return { ...state, replies: { ...action.replies, results: replies } };

    case actionTypes.ADD_REPLY:
      replies = state.replies.results === null ? [] : [...state.replies.results];
      replies.push(makeReplyUIObject(action.reply));
      return { ...state, replies : { ...state.replies, results: replies }};

    case actionTypes.ADD_NEW_REPLY:
      if (state.replies.results !== null &&
        state.replies.results.length >= state.offset + state.limit) {
        replies = state.replies.results.slice(0, -1);
      } else replies = state.replies.results === null ? [] : [...state.replies.results];

      replies.reverse().push(action.reply);
      return { ...state, replies: { ...state.replies, results: replies.reverse(), totalCount: state.replies.totalCount+1 }, text: null };

    case actionTypes.ADD_REPLIES:
      replies = state.replies.results ?
        [...state.replies.results, ...action.replies.results] : action.replies.results;
      replies = replies.map((reply) => makeReplyUIObject(reply));
      return { ...state, replies: { ...state.replies, results: replies }, offset: action.offset, limit: action.limit };

    case actionTypes.REMOVE_REPLY:
      replies = { ...state.replies };
      if (state.replies && state.replies.results) state.replies.results.splice(action.index, 1);
      replies.totalCount = state.replies && state.replies.totalCount ? state.replies.totalCount-1 : 0;
      return { ...state, replies };

    case actionTypes.RESET_REPLY:
      replies = { ...state.replies };
      if (state.replies && state.replies.results) state.replies.results[action.index] = makeReplyUIObject(action.reply);
      return { ...state, replies };

    case actionTypes.RESET_REPLIES:
      replies = null;
      return { ...state, replies };

    case actionTypes.ADD_COMMENT:
      replies = { ...state.replies };
      if (state.replies && state.replies.results) {
        const comments = state.replies.results[action.index].comments;
        if (comments && comments.list) {
          comments.list.push(action.comment);
        }
      }
      return { ...state, replies };

    case actionTypes.CHANGE_TEXT:
      return { ...state, text: action.text };

    case actionTypes.CHANGE_REPLY_TEXT:
      replies = { ...state.replies };
      if (action.isBefore) replies.results[action.index].beforeText = action.text;
      else replies.results[action.index].text = action.text;
      return { ...state, replies };

    case actionTypes.CHANGE_COMMENT_TEXT:
      replies = { ...state.replies };
      if (action.isBefore) replies.results[action.replyIndex].comments.list[action.index].beforeText = action.text;
      else replies.results[action.replyIndex].comments.list[action.index].text = action.text;
      return { ...state, replies };

    case actionTypes.TOGGLE_REPLY_MODIFIABLE:
      replies = { ...state.replies };
      replies.results[action.index].modifiable = action.modifiable;
      if (!action.modifiable) replies.results[action.index].text = replies.results[action.index].beforeText;
      return { ...state, replies };

    case actionTypes.TOGGLE_COMMENT_MODIFIABLE:
      replies = { ...state.replies };
      replies.results[action.replyIndex].comments.list[action.index].modifiable = action.modifiable;
      const comment = replies.results[action.replyIndex].comments.list[action.index];

      if (!comment.sequence) replies.results[action.replyIndex].comments.list.splice(action.index, 1);
      else replies.results[action.replyIndex].comments.list[action.index].text = comment.beforeText;
      return { ...state, replies };

    default :
      return state;
  }
};

export default replyReducer;
