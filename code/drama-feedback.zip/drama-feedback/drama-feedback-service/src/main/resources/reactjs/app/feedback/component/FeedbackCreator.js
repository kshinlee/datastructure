import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { initialGridConfig, destroyGrid } from '../../common/dataTable';
import { Col, Button, Table, FormGroup, FormControl } from 'react-bootstrap';

class FeedbackCreator extends Component {

  constructor(props) {
    super(props);
    autoBind(this);
    // Grid
    this.grid = null;
  }

  componentDidMount() {
    this.grid = initialGridConfig('memoTable');
  }

  componentWillUnmount() {
    destroyGrid(this.grid);
  }

  render() {
    //
    const feedback = this.props.feedback;

    return (

      <div className="panel panel-flat">
        { /* START panel-body */ }
        <div className="panel-body bb-dashed pt0">
          <form className="form-horizontal">
            <FormGroup>
              <label className="col-md-2 control-label">피드백 타입</label>
              <Col md={ 10 }>
                <FormControl
                  componentClass="select"
                  name="type"
                  value={feedback.type || ''}
                  onChange={(e) => this.props.changeFeedbackProps('type', e.target.value)}
                  className="form-control m-b" disabled={!!feedback.id}
                >
                  <option>구분을 선택해 주세요.</option>
                  <option value="Reply">Reply</option>
                  <option value="Review">Review</option>
                  <option value="Report">Report</option>
                </FormControl>
              </Col>
            </FormGroup>
            <FormGroup>
              <label className="col-md-2 control-label">피드백명</label>
              <Col md={ 10 }>
                <FormControl
                  type="text"
                  className="form-control"
                  value={feedback.title || ''}
                  onChange={(e) => this.props.changeFeedbackProps('title', e.target.value)}
                />
              </Col>
            </FormGroup>
          </form>
        </div>
      </div>
    );
  }
}

export default FeedbackCreator;
