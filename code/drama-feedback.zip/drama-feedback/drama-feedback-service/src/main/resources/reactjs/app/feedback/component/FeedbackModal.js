import React from 'react';
import { Modal, Button } from 'react-bootstrap';

import FeedbackCreator from './FeedbackCreator';
import FeedbackContent from './FeedbackContent';

const FeedbackModal = ({ showModal, feedback, saveFeedback, closeModal, changeFeedbackProps, changeFeedbackConfigProps }) =>
  //

   (
    <Modal show={showModal} dialogClassName="modal-size-sm" onHide={closeModal}>
      <Modal.Header closeButton>
        <Modal.Title>{feedback.id ? feedback.title : '피드백 생성'}</Modal.Title>
      </Modal.Header>
      <Modal.Body className="p0">
        <div className="clearfix p bb">
          <div className="pull-left">
            <Button
              bsStyle="success" bsSize="small"
              onClick={saveFeedback}
            >저장</Button>
            {feedback.id ? <Button bsStyle="default" bsSize="small">삭제</Button> : ''}
          </div>
        </div>
      </Modal.Body>
      <Modal.Body>
        {
          feedback.id ?
            <FeedbackContent
              feedback={feedback}
              changeFeedbackProps={changeFeedbackProps}
              changeFeedbackConfigProps={changeFeedbackConfigProps}
            /> :
            <FeedbackCreator
              feedback={feedback}
              changeFeedbackProps={changeFeedbackProps}
              changeFeedbackConfigProps={changeFeedbackConfigProps}
            />
        }
      </Modal.Body>
    </Modal>
  );


export default FeedbackModal;
