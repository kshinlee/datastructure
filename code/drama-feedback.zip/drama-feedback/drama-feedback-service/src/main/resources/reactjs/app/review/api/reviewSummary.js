import NaraAjax from '../../../nara_modules/naraAjax';

export default (baseUrl) => {
  //
  const url = baseUrl ? baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/` : '';

  return {
    findReviewSummary: (feedbackId) => NaraAjax.getJSON(`${DRAMA_CONTEXT.basePath}feedback-api/reviews/summary?feedbackId=${feedbackId}`),
  };
};
