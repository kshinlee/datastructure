import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { destroyGrid, initialGridConfig } from '../../common/dataTable';
import { Button, Row, Col, Table } from 'react-bootstrap';

class FeedbackList extends Component {
  //
  constructor(props) {
    super(props);
    autoBind(this);
    // Grid
    this.grid = null;
  }

  componentDidMount() {
    // Grid
    //this.grid = initialGridConfig('feedbackTable');
  }

  componentWillUnmount() {
    //destroyGrid(this.grid);
  }

  render() {
    //
    const feedbackList = this.props.feedbackList;

    return (
      <div className="panel panel-default">
        { /* START panel-body */ }
        <div className="panel-body bb pt pb">
          <div className="pull-left">
            <Button
              bsStyle="primary" bsSize="small"
              onClick={() => this.props.routeToFeedbackCreator()}
            >
              <i className="fa fa-plus"></i> 새로만들기
            </Button>
          </div>
        </div>
        { /* END panel-body */ }
        { /* START panel-body */ }
        <div className="panel-body">
          <Row>
            <Col md={ 12 }>
              { /* START table */ }
              <Table id="feedbackTable" responsive hover bordered>
                <thead>
                  <tr>
                    <th>구분</th>
                    <th>피드백명</th>
                    <th>익명여부</th>
                    <th>등록시간</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    feedbackList && feedbackList.results && feedbackList.results.length ?
                      feedbackList.results.map((feedback) => (
                        <tr key={feedback.id}>
                          <td>{feedback.type}</td>
                          <td
                            onClick={() => this.props.routeToFeedback(feedback.id)}
                          >{feedback.title}</td>
                          <td>{feedback.config.anonymous ? '익명' : '기명'}</td>
                          <td>{new Date(feedback.time).toLocaleString()}</td>
                        </tr>
                      )) :
                      <tr className="text-center">
                        <td colSpan="4">현재 등록 된 피드백이 없습니다.</td>
                      </tr>
                  }
                </tbody>
              </Table>
              { /* END table */ }
            </Col>
          </Row>
        </div>
        { /* END panel-body */ }
      </div>
    );
  }
}

export default FeedbackList;
