import { push } from 'react-router-redux';
import FeedbackApiBuilder from '../api/feedback';

export const actionTypes = {
  FIND_FEEDBACK_LIST: 'FIND_FEEDBACK_LIST',
  FIND_FEEDBACK: 'FIND_FEEDBACK',

  REGISTER_REPLY_FEEDBACK: 'REGISTER_REPLY_FEEDBACK',
  REGISTER_REVIEW_FEEDBACK: 'REGISTER_REVIEW_FEEDBACK',

  MODIFY_FEEDBACK: 'MODIFY_FEEDBACK',

  TOGGLE_FEEDBACK_MODAL: 'TOGGLE_FEEDBACK_MODAL',

  CHANGE_FEEDBACK_PROPS: 'CHANGE_FEEDBACK_PROPS',
  CHANGE_FEEDBACK_CONFIG_PROPS: 'CHANGE_FEEDBACK_CONFIG_PROPS',
};
let FeedbackApi = null;

const feedbackAction = {
  //
  findFeedbackList() {
    //
    const loadSuccess = (feedbackList) => ({
      type: actionTypes.FIND_FEEDBACK_LIST,
      feedbackList,
    });

    return (dispatch) => {
      FeedbackApi.findFeedbackList()
        .then((feedbackList) => dispatch(loadSuccess(feedbackList)));
    };
  },

  findFeedback(id, callback) {
    //
    const loadSuccess = (feedback) => ({
      type: actionTypes.FIND_FEEDBACK,
      feedback,
    });

    return (dispatch) => {
      FeedbackApi.findFeedback(id)
        .then((feedback) => {
          dispatch(loadSuccess(feedback));
          if (callback && typeof callback === 'function') callback();
        });
    };
  },

  registerReplyFeedback(feedbackCdo, callback) {
    //
    return (dispatch) => {
      FeedbackApi.registerReplyFeedback(feedbackCdo)
        .then(() => {
          feedbackAction.findFeedbackList()(dispatch);
          if (callback && typeof callback === 'function') callback();
        });
    };
  },

  registerReviewFeedback(feedbackCdo, callback) {
    //
    return (dispatch) => {
      FeedbackApi.registerReviewFeedback(feedbackCdo)
        .then(() => {
          feedbackAction.findFeedbackList()(dispatch);
          if (callback && typeof callback === 'function') callback();
        });
    };
  },

  modifyFeedback(id, nameValueList, callback) {
    //
    return (dispatch) => {
      FeedbackApi.modifyFeedback(id, nameValueList)
        .then(() => {
          feedbackAction.findFeedbackList()(dispatch);
          if (callback && typeof callback === 'function') callback();
        });
    };
  },

  toggleFeedbackModal(showModal) {
    //
    return {
      type: actionTypes.TOGGLE_FEEDBACK_MODAL,
      showModal,
    };
  },

  changeFeedbackProps(prop, value) {
    //
    return {
      type: actionTypes.CHANGE_FEEDBACK_PROPS,
      prop,
      value,
    };
  },

  changeFeedbackConfigProps(prop, value) {
    //
    return {
      type: actionTypes.CHANGE_FEEDBACK_CONFIG_PROPS,
      prop,
      value,
    };
  },
};

export const feedbackActionBuilder = (baseUrl) => {
  //
  FeedbackApi = FeedbackApiBuilder(baseUrl);

  return feedbackAction;
};

const initialState = {
  feedbackList: null,
  feedback: {},
  showModal: false,
};

const feedbackReducer = (state = initialState, action) => {
  //
  let feedback = {};

  switch (action.type) {
    //
    case actionTypes.FIND_FEEDBACK_LIST:
      return { ...state, feedbackList: action.feedbackList };

    case actionTypes.FIND_FEEDBACK:
      return { ...state, feedback: action.feedback };

    case actionTypes.TOGGLE_FEEDBACK_MODAL:
      return { ...state, showModal: action.showModal, feedback: {} };

    case actionTypes.CHANGE_FEEDBACK_PROPS:
      feedback = { ...state.feedback };
      feedback[action.prop] = action.value;
      return { ...state, feedback };

    case actionTypes.CHANGE_FEEDBACK_CONFIG_PROPS:
      feedback = { ...state.feedback };
      feedback.config = feedback.config ? feedback.config : {};
      feedback.config[action.prop] = action.value;
      return { ...state, feedback };

    default :
      return state;
  }
};

export default feedbackReducer;
