import CommentContent from './reply/component/CommentContent';
import CommentList from './reply/component/CommentList';
import ReplyContent from './reply/component/ReplyContent';
import ReplyList from './reply/component/ReplyList';
import replyReducer, { replyActionBuilder } from './reply/module/reply';

import ReviewContent from './review/component/ReviewContent';
import ReviewCreator from './review/component/ReviewCreator';
import ReviewList from './review/component/ReviewList';
import ReviewSummary from './review/component/ReviewSummary';
import reviewReducer, { reviewActionBuilder } from './review/module/review';
import reviewSummaryReducer, { reviewSummaryActionBuilder } from './review/module/reviewSummary';

const Feedback = {
  CommentContent,
  CommentList,
  ReplyContent,
  ReplyList,
  replyReducer,
  replyActionBuilder,

  ReviewContent,
  ReviewCreator,
  ReviewList,
  ReviewSummary,
  reviewReducer,
  reviewActionBuilder,
  reviewSummaryReducer,
  reviewSummaryActionBuilder,
};

export { Feedback };
