package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.FeedbackStoreTestApplication;
import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import namoo.drama.feedback.domain.entity.review.ReviewConfig;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.drama.feedback.domain.store.FeedbackStore;
import namoo.drama.feedback.domain.store.ReviewSummaryStore;
import namoo.nara.share.domain.IntPairList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = FeedbackStoreTestApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ReviewSummaryMongoStoreTest {
    //
    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private FeedbackStore feedbackStore;
    @Autowired
    private ReviewSummaryStore reviewSummaryStore;

    private String feedbackId;

    @Before
    public void beforeTest() {
        //
        Feedback feedback = Feedback.getSample();
        feedback.setType(FeedbackType.Review);
        feedbackStore.create(feedback);
        feedbackId = feedback.getId();

        ReviewSummary reviewSummary = new ReviewSummary(feedbackId, ReviewConfig.getSample());
        IntPairList startCounts = reviewSummary.getStarCounts();
        startCounts.increaseRight(1);
        startCounts.increaseRight(2);
        startCounts.increaseRight(3);
        startCounts.increaseRight(4);
        startCounts.increaseRight(5);

        reviewSummaryStore.create(reviewSummary);
    }

    @Test
    public void retrieveTest() {
        //
        ReviewSummary reviewSummary = ReviewSummary.getSample();
        ReviewSummary result = reviewSummaryStore.retrieve(feedbackId);

        Assert.assertEquals(reviewSummary.isVersionBased(), result.isVersionBased());
        Assert.assertEquals(reviewSummary.getMaxStarCount(), result.getMaxStarCount());
        Assert.assertEquals((int)reviewSummary.getAverage(), (int) result.getAverage());
        Assert.assertEquals(reviewSummary.getStarCounts().toString(), result.getStarCounts().toString());
        Assert.assertEquals(reviewSummary.getVersionStarCountMap().toString(), result.getVersionStarCountMap().toString());
        Assert.assertEquals(reviewSummary.getVersionReviewerCountMap().toString(), result.getVersionReviewerCountMap().toString());
        Assert.assertEquals(feedbackId, result.getId());
    }


    @Test
    public void updateTest() {
        //
        ReviewSummary reviewSummary = reviewSummaryStore.retrieve(feedbackId);
        int maxStarCount = 5;

        reviewSummary.setMaxStarCount(maxStarCount);
        reviewSummary.getStarCounts().increaseRight(1);
        reviewSummary.getStarCounts().increaseRight(2);
        reviewSummary.getStarCounts().increaseRight(3);
        reviewSummary.getStarCounts().increaseRight(4);
        reviewSummary.getStarCounts().increaseRight(5);

        reviewSummaryStore.update(reviewSummary);

        ReviewSummary result = reviewSummaryStore.retrieve(feedbackId);

        Assert.assertEquals(reviewSummary.isVersionBased(), result.isVersionBased());
        Assert.assertEquals(reviewSummary.getMaxStarCount(), result.getMaxStarCount());
        Assert.assertEquals((int)reviewSummary.getAverage(), (int) result.getAverage());
        Assert.assertEquals(reviewSummary.getStarCounts().toString(), result.getStarCounts().toString());
        Assert.assertEquals(reviewSummary.getVersionStarCountMap().toString(), result.getVersionStarCountMap().toString());
        Assert.assertEquals(reviewSummary.getVersionReviewerCountMap().toString(), result.getVersionReviewerCountMap().toString());
        Assert.assertEquals(feedbackId, result.getId());
    }

    @Test
    public void deleteTest() {
        //
        reviewSummaryStore.delete(feedbackId);
        ReviewSummary result = reviewSummaryStore.retrieve(feedbackId);
        Assert.assertEquals(null, result.getVersionStarCountMap());
    }
}
