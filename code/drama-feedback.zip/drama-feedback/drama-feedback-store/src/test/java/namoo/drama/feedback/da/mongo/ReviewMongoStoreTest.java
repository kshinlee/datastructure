package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.FeedbackStoreTestApplication;
import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.store.FeedbackStore;
import namoo.drama.feedback.domain.store.ReviewStore;
import namoo.nara.share.domain.OffsetList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = FeedbackStoreTestApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ReviewMongoStoreTest {
    //
    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private FeedbackStore feedbackStore;
    @Autowired
    private ReviewStore reviewStore;

    private String feedbackId;
    private String reviewId;

    @Before
    public void beforeTest() {
        //
        Feedback feedback = Feedback.getSample();
        feedback.setType(FeedbackType.Review);
        feedbackStore.create(feedback);
        feedbackId = feedback.getId();

        Review review = Review.getSample();
        review.setFeedbackId(feedbackId);
        reviewStore.create(review);
        reviewId = review.getId();
    }

    @Test
    public void retrieveTest() {
        //
        Review review = Review.getSample();
        Review result = reviewStore.retrieve(reviewId);

        Assert.assertEquals(review.getVersion(), result.getVersion());
        Assert.assertEquals(review.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(review.getTitle(), result.getTitle());
        Assert.assertEquals(review.getOpinion(), result.getOpinion());
        Assert.assertEquals(review.getSelectedStar(), result.getSelectedStar());
        Assert.assertEquals(review.getHelpCount().toPairString(), result.getHelpCount().toPairString());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void retrieveAllByFeedbackIdTest() {
        //
        Review review = Review.getSample();
        List<Review> results = reviewStore.retrieveAllByFeedbackId(feedbackId);
        Review result = results.get(0);

        Assert.assertEquals(1, results.size());
        Assert.assertEquals(review.getVersion(), result.getVersion());
        Assert.assertEquals(review.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(review.getTitle(), result.getTitle());
        Assert.assertEquals(review.getOpinion(), result.getOpinion());
        Assert.assertEquals(review.getSelectedStar(), result.getSelectedStar());
        Assert.assertEquals(review.getHelpCount().toPairString(), result.getHelpCount().toPairString());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void retrieveAllTest() {
        //
        Review review = Review.getSample();
        OffsetList<Review> results = reviewStore.retrieveAll(feedbackId, 0, Integer.MAX_VALUE);
        Review result = results.get(0);

        Assert.assertEquals(1, results.size());
        Assert.assertEquals(1, results.getTotalCount());
        Assert.assertEquals(review.getVersion(), result.getVersion());
        Assert.assertEquals(review.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(review.getTitle(), result.getTitle());
        Assert.assertEquals(review.getOpinion(), result.getOpinion());
        Assert.assertEquals(review.getSelectedStar(), result.getSelectedStar());
        Assert.assertEquals(review.getHelpCount().toPairString(), result.getHelpCount().toPairString());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void retrieveAllWithVersionTest() {
        //
        Review review = Review.getSample();
        OffsetList<Review> results = reviewStore.retrieveAll(feedbackId, null, 0, Integer.MAX_VALUE);
        Review result = results.get(0);

        Assert.assertEquals(1, results.size());
        Assert.assertEquals(1, results.getTotalCount());
        Assert.assertEquals(review.getVersion(), result.getVersion());
        Assert.assertEquals(review.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(review.getTitle(), result.getTitle());
        Assert.assertEquals(review.getOpinion(), result.getOpinion());
        Assert.assertEquals(review.getSelectedStar(), result.getSelectedStar());
        Assert.assertEquals(review.getHelpCount().toPairString(), result.getHelpCount().toPairString());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void updateTest() {
        //
        Review review = reviewStore.retrieve(reviewId);
        review.setTitle("update Test");
        review.setOpinion("update Test");
        review.setSelectedStar(5);
        review.getHelpCount().increaseLeft();
        reviewStore.update(review);

        Review result = reviewStore.retrieve(reviewId);

        Assert.assertEquals(review.getVersion(), result.getVersion());
        Assert.assertEquals(review.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(review.getTitle(), result.getTitle());
        Assert.assertEquals(review.getOpinion(), result.getOpinion());
        Assert.assertEquals(review.getSelectedStar(), result.getSelectedStar());
        Assert.assertEquals(review.getHelpCount().toPairString(), result.getHelpCount().toPairString());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void deleteTest() {
        //
        Review result = reviewStore.retrieve(reviewId);
        reviewStore.delete(result);
        List<Review> results = reviewStore.retrieveAllByFeedbackId(feedbackId);
        Assert.assertEquals(0, results.size());
    }
}
