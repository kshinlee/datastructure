package namoo.drama.feedback.da;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@SpringBootApplication
public class FeedbackStoreTestApplication {
}
