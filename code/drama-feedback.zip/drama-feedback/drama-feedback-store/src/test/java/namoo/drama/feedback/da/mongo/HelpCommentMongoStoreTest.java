package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.FeedbackStoreTestApplication;
import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import namoo.drama.feedback.domain.entity.review.HelpComment;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.store.FeedbackStore;
import namoo.drama.feedback.domain.store.HelpCommentStore;
import namoo.drama.feedback.domain.store.ReviewStore;
import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.OffsetList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = FeedbackStoreTestApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class HelpCommentMongoStoreTest {
    //
    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private HelpCommentStore helpCommentStore;
    @Autowired
    private FeedbackStore feedbackStore;
    @Autowired
    private ReviewStore reviewStore;

    private String feedbackId;
    private String reviewId;
    private String helpCommentId;

    @Before
    public void beforeTest() {
        //
        Feedback feedback = Feedback.getSample();
        feedback.setType(FeedbackType.Review);
        feedbackStore.create(feedback);
        feedbackId = feedback.getId();

        Review review = Review.getSample();
        review.setFeedbackId(feedbackId);
        reviewStore.create(review);
        reviewId = review.getId();

        HelpComment helpComment = HelpComment.getSample();
        helpComment.setReviewId(reviewId);
        helpCommentStore.create(helpComment);
        helpCommentId = helpComment.getId();
    }

    @Test
    public void retrieveTest() {
        //
        HelpComment helpComment = HelpComment.getSample();
        HelpComment result = helpCommentStore.retrieve(helpCommentId);

        Assert.assertEquals(helpComment.isAnonymous(), result.isAnonymous());
        Assert.assertEquals(helpComment.isHelpful(), result.isHelpful());
        Assert.assertEquals(result.getReviewId(), reviewId);
        Assert.assertEquals(helpComment.getReviewerId(), result.getReviewerId());
    }

    @Test
    public void retrieveByReviewIdAndReviewerIdTest() {
        //
        HelpComment helpComment = HelpComment.getSample();
        HelpComment result = helpCommentStore.retrieve(reviewId, Actor.getSample().getId());

        Assert.assertEquals(helpComment.isAnonymous(), result.isAnonymous());
        Assert.assertEquals(helpComment.isHelpful(), result.isHelpful());
        Assert.assertEquals(result.getReviewId(), reviewId);
        Assert.assertEquals(helpComment.getReviewerId(), result.getReviewerId());
    }

    @Test
    public void retrieveAllTest() {
        //
        HelpComment helpComment = HelpComment.getSample();
        OffsetList<HelpComment> results = helpCommentStore.retrieveAll(reviewId, 0, Integer.MAX_VALUE);
        HelpComment result = results.get(0);

        Assert.assertEquals(results.getTotalCount(), 1);
        Assert.assertEquals(results.size(), 1);
        Assert.assertEquals(helpComment.isAnonymous(), result.isAnonymous());
        Assert.assertEquals(helpComment.isHelpful(), result.isHelpful());
        Assert.assertEquals(result.getReviewId(), reviewId);
        Assert.assertEquals(helpComment.getReviewerId(), result.getReviewerId());
    }

    @Test
    public void updateTest() {
        //
        HelpComment helpComment = helpCommentStore.retrieve(helpCommentId);
        helpComment.setAnonymous(true);
        helpComment.setHelpful(false);
        helpCommentStore.update(helpComment);

        HelpComment result = helpCommentStore.retrieve(helpCommentId);

        Assert.assertEquals(helpComment.isAnonymous(), result.isAnonymous());
        Assert.assertEquals(helpComment.isHelpful(), result.isHelpful());
        Assert.assertEquals(result.getReviewId(), reviewId);
        Assert.assertEquals(helpComment.getReviewerId(), result.getReviewerId());
    }

    @Test
    public void deleteTest() {
        //
        HelpComment result = helpCommentStore.retrieve(helpCommentId);
        helpCommentStore.delete(result);
        Assert.assertEquals(0, helpCommentStore.countByReviewId(reviewId));
    }

    @Test
    public void deleteAllByReviewIdTest() {
        //
        helpCommentStore.deleteAllByReviewId(reviewId);
        Assert.assertEquals(0, helpCommentStore.countByReviewId(reviewId));
    }

    @Test
    public void countByReviewIdTest() {
        //
        Assert.assertEquals(1, helpCommentStore.countByReviewId(reviewId));
    }

}
