package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.FeedbackStoreTestApplication;
import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import namoo.drama.feedback.domain.store.FeedbackStore;
import namoo.nara.share.domain.Informant;
import namoo.nara.share.domain.OffsetList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = FeedbackStoreTestApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class FeedbackMongoStoreTest {
    //
    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private FeedbackStore feedbackStore;

    private String feedbackId;

    @Before
    public void beforeTest() {
        //
        Feedback feedback = Feedback.getSample();
        feedbackStore.create(feedback);
        feedbackId = feedback.getId();
    }

    @Test
    public void retrieveTest() {
        //
        Feedback feedback = Feedback.getSample();
        Feedback result = feedbackStore.retrieve(feedbackId);

        Assert.assertEquals(feedback.getTitle(), result.getTitle());
        Assert.assertEquals(feedback.getConfig().toString(), result.getConfig().toString());
        Assert.assertEquals(feedback.getType(), result.getType());
        Assert.assertEquals(feedback.getInformant().toString(), result.getInformant().toString());
    }

    @Test
    public void retrieveAllTest() {
        //
        Feedback feedback = Feedback.getSample();
        OffsetList<Feedback> results = feedbackStore.retrieveAllByPavilionId(Informant.getSample().getScreenId().getPavilionId(), 0 , Integer.MAX_VALUE);
        Feedback result = results.get(0);

        Assert.assertEquals(1, results.size());
        Assert.assertEquals(feedback.getTitle(), result.getTitle());
        Assert.assertEquals(feedback.getConfig().toString(), result.getConfig().toString());
        Assert.assertEquals(feedback.getType(), result.getType());
        Assert.assertEquals(feedback.getInformant().toString(), result.getInformant().toString());
    }

    @Test
    public void retrieveAllBySourceEntityNameTest() {
        //
        Feedback feedback = Feedback.getSample();
        List<Feedback> results = feedbackStore.retrieveAllBySourceEntityName("Customer");
        Feedback result = results.get(0);

        Assert.assertEquals(1, results.size());
        Assert.assertEquals(feedback.getTitle(), result.getTitle());
        Assert.assertEquals(feedback.getConfig().toString(), result.getConfig().toString());
        Assert.assertEquals(feedback.getType(), result.getType());
        Assert.assertEquals(feedback.getInformant().toString(), result.getInformant().toString());
    }

    @Test
    public void updateTest() {
        //
        Feedback feedback = feedbackStore.retrieve(feedbackId);
        feedback.setTitle("update Test");
        feedback.getConfig().setAnonymous(true);
        feedback.setType(FeedbackType.Review);
        feedbackStore.update(feedback);

        Feedback result = feedbackStore.retrieve(feedbackId);

        Assert.assertEquals(feedback.getTitle(), result.getTitle());
        Assert.assertEquals(feedback.getConfig().toString(), result.getConfig().toString());
        Assert.assertEquals(feedback.getType(), result.getType());
        Assert.assertEquals(feedback.getInformant().toString(), result.getInformant().toString());
    }

    @Test
    public void deleteTest() {
        //
        feedbackStore.delete(feedbackId);
        OffsetList<Feedback> results = feedbackStore.retrieveAllByPavilionId(Informant.getSample().getScreenId().getPavilionId(), 0 , Integer.MAX_VALUE);
        Assert.assertEquals(0, results.size());
    }
}
