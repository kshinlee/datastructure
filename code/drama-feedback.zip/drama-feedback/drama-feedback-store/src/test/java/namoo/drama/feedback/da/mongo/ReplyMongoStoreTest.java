package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.FeedbackStoreTestApplication;
import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import namoo.drama.feedback.domain.entity.reply.Comment;
import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.store.FeedbackStore;
import namoo.drama.feedback.domain.store.ReplyStore;
import namoo.nara.share.domain.OffsetList;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = FeedbackStoreTestApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ReplyMongoStoreTest {
    //
    Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private FeedbackStore feedbackStore;
    @Autowired
    private ReplyStore replyStore;

    private String feedbackId;
    private String replyId;

    @Before
    public void beforeTest() {
        //
        Feedback feedback = Feedback.getSample();
        feedbackStore.create(feedback);
        feedbackId = feedback.getId();

        Reply reply = Reply.getSample();
        reply.setFeedbackId(feedbackId);
        replyStore.create(reply);
        replyId = reply.getId();
    }

    @Test
    public void retrieveTest() {
        //
        Reply reply = Reply.getSample();
        Reply result = replyStore.retrieve(replyId);

        Assert.assertEquals(reply.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(reply.getText(), result.getText());
        Assert.assertEquals(reply.getComments().size(), result.getComments().size());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void retrieveAllByFeedbackIdTest() {
        //
        Reply reply = Reply.getSample();
        List<Reply> results = replyStore.retrieveAllByFeedbackId(feedbackId);
        Reply result = results.get(0);

        Assert.assertEquals(1, results.size());
        Assert.assertEquals(reply.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(reply.getText(), result.getText());
        Assert.assertEquals(reply.getComments().size(), result.getComments().size());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void retrieveAllTest() {
        //
        Reply reply = Reply.getSample();
        OffsetList<Reply> results = replyStore.retrieveAll(feedbackId, 0, Integer.MAX_VALUE);
        Reply result = results.get(0);

        Assert.assertEquals(1, results.size());
        Assert.assertEquals(1, results.getTotalCount());
        Assert.assertEquals(reply.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(reply.getText(), result.getText());
        Assert.assertEquals(reply.getComments().size(), result.getComments().size());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void updateTest() {
        //
        Reply reply = replyStore.retrieve(replyId);
        reply.setText("update Test");
        reply.getComments().add(Comment.getSample());
        replyStore.update(reply);

        Reply result = replyStore.retrieve(replyId);

        Assert.assertEquals(reply.getWriter().toString(), result.getWriter().toString());
        Assert.assertEquals(reply.getText(), result.getText());
        Assert.assertEquals(reply.getComments().size(), result.getComments().size());
        Assert.assertEquals(feedbackId, result.getFeedbackId());
    }

    @Test
    public void deleteTest() {
        //
        Reply result = replyStore.retrieve(replyId);
        replyStore.delete(result);
        List<Reply> results = replyStore.retrieveAllByFeedbackId(feedbackId);
        Assert.assertEquals(0, results.size());
    }
}
