package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.mongo.document.review.ReviewSummaryDoc;
import namoo.drama.feedback.da.mongo.springdata.ReviewSummaryMongoRepository;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.drama.feedback.domain.store.ReviewSummaryStore;
import namoo.nara.share.exception.store.NonExistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Repository
public class ReviewSummaryMongoStore implements ReviewSummaryStore {
    //
    @Autowired
    private ReviewSummaryMongoRepository repository;

    @Override
    public void create(ReviewSummary reviewSummary) {
        //
        repository.insert(ReviewSummaryDoc.toDocument(reviewSummary));
    }

    @Override
    public ReviewSummary retrieve(String id) {
        //
        if (!repository.exists(id)) {
            create(new ReviewSummary(id));
        }
        return repository.findOne(id).toDomain();
    }

    @Override
    public void update(ReviewSummary reviewSummary) {
        //
        if (!repository.exists(reviewSummary.getId())) throw new NonExistenceException(String.format("No such a reviewSummary[%s] to update.", reviewSummary.getId()));
        repository.save(ReviewSummaryDoc.toDocument(reviewSummary));
    }

    @Override
    public void delete(String id) {
        //
        if (!repository.exists(id)) throw new NonExistenceException(String.format("No such a reviewSummary[%s] to delete.", id));
        repository.delete(id);
    }
}
