package namoo.drama.feedback.da.mongo.springdata;

import namoo.drama.feedback.da.mongo.document.review.ReviewDoc;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
public interface ReviewMongoRepository extends MongoRepository<ReviewDoc, String> {
    //
    List<ReviewDoc> findAllByFeedbackId(String feedbackId);
    Page<ReviewDoc> findAllByFeedbackId(String feedbackId, Pageable pageable);
    Page<ReviewDoc> findAllByFeedbackIdAndVersion(String feedbackId, String version, Pageable pageable);
    void deleteAllByFeedbackId(String feedbackId);
}
