package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.mongo.document.review.HelpCommentDoc;
import namoo.drama.feedback.da.mongo.springdata.HelpCommentMongoRepository;
import namoo.drama.feedback.domain.entity.review.HelpComment;
import namoo.drama.feedback.domain.store.HelpCommentStore;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.exception.store.NonExistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Repository
public class HelpCommentMongoStore implements HelpCommentStore {
    //
    @Autowired
    private HelpCommentMongoRepository repository;

    @Override
    public void create(HelpComment helpComment) {
        //
        repository.insert(HelpCommentDoc.toDocument(helpComment));
    }

    @Override
    public HelpComment retrieve(String id) {
        //
        if (!repository.exists(id)) {
            create(new HelpComment(id));
        }
        return repository.findOne(id).toDomain();
    }

    @Override
    public HelpComment retrieve(String reviewId, String reviewerId) {
        //
        HelpCommentDoc doc = repository.findOneByReviewIdAndReviewerId(reviewId, reviewerId);
        if (doc == null) return null;
        return doc.toDomain();
    }

    @Override
    public OffsetList<HelpComment> retrieveAll(String reviewId, int offset, int limit) {
        //
        int page = offset/limit;

        PageRequest pageRequest = new PageRequest(page, limit);
        Page<HelpCommentDoc> helpCommentDocPage = repository.findAllByReviewId(reviewId, pageRequest);
        List<HelpComment> helpComments = HelpCommentDoc.toDomains(helpCommentDocPage.getContent());
        OffsetList<HelpComment> offsetList = new OffsetList<>(helpComments, (int)helpCommentDocPage.getTotalElements());
        return offsetList;
    }

    @Override
    public void update(HelpComment helpComment) {
        //
        if (!repository.exists(helpComment.getId())) throw new NonExistenceException(String.format("No such a helpComment[%s] to update.", helpComment.getId()));
        repository.save(HelpCommentDoc.toDocument(helpComment));
    }

    @Override
    public void delete(HelpComment helpComment) {
        //
        if (!repository.exists(helpComment.getId())) throw new NonExistenceException(String.format("No such a helpComment[%s] to delete.", helpComment.getId()));
        repository.delete(HelpCommentDoc.toDocument(helpComment));
    }

    @Override
    public void deleteAllByReviewId(String reviewId) {
        //
        repository.deleteAllByReviewId(reviewId);
    }

    @Override
    public int countByReviewId(String reviewId) {
        //
        return repository.countByReviewId(reviewId);
    }

}
