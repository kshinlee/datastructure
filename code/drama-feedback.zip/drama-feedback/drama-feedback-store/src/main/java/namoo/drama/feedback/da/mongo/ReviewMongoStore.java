package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.mongo.document.review.ReviewDoc;
import namoo.drama.feedback.da.mongo.springdata.ReviewMongoRepository;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.drama.feedback.domain.store.ReviewStore;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.exception.store.NonExistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Repository
public class ReviewMongoStore implements ReviewStore {
    //
    @Autowired
    private ReviewMongoRepository repository;

    @Override
    public void create(Review review) {
        //
        repository.insert(ReviewDoc.toDocument(review));
    }

    @Override
    public Review retrieve(String id) {
        //
        if (!repository.exists(id)) {
            create(new Review(id));
        }
        return repository.findOne(id).toDomain();
    }

    @Override
    public List<Review> retrieveAllByFeedbackId(String feedbackId) {
        //
        return ReviewDoc.toDomains(repository.findAllByFeedbackId(feedbackId));
    }

    @Override
    public OffsetList<Review> retrieveAll(String feedbackId, String version, int offset, int limit) {
        //
        int page = offset/limit;

        PageRequest pageRequest = new PageRequest(page, limit, new Sort(Sort.Direction.DESC, "time"));
        Page<ReviewDoc> reviewDocPage = repository.findAllByFeedbackIdAndVersion(feedbackId, version, pageRequest);
        List<Review> reviews = ReviewDoc.toDomains(reviewDocPage.getContent());
        OffsetList<Review> offsetList = new OffsetList<>(reviews, (int)reviewDocPage.getTotalElements());
        return offsetList;
    }

    @Override
    public OffsetList<Review> retrieveAll(String feedbackId, int offset, int limit) {
        //
        int page = offset/limit;

        PageRequest pageRequest = new PageRequest(page, limit, new Sort(Sort.Direction.DESC, "time"));
        Page<ReviewDoc> reviewDocPage = repository.findAllByFeedbackId(feedbackId, pageRequest);
        List<Review> reviews = ReviewDoc.toDomains(reviewDocPage.getContent());
        OffsetList<Review> offsetList = new OffsetList<>(reviews, (int)reviewDocPage.getTotalElements());
        return offsetList;
    }

    @Override
    public void update(Review review) {
        //
        if (!repository.exists(review.getId())) throw new NonExistenceException(String.format("No such a review[%s] to update.", review.getId()));
        repository.save(ReviewDoc.toDocument(review));
    }

    @Override
    public void delete(Review review) {
        //
        if (!repository.exists(review.getId())) throw new NonExistenceException(String.format("No such a review[%s] to delete.", review.getId()));
        repository.delete(ReviewDoc.toDocument(review));
    }

    @Override
    public void deleteByFeedbackId(String feedbackId) {
        //
        repository.deleteAllByFeedbackId(feedbackId);
    }

    @Override
    public int countAllByFeedbackId(String feedbackId) {
        //
        Page<ReviewDoc> reviewDocPage = repository.findAllByFeedbackId(feedbackId, new PageRequest(0, Integer.MAX_VALUE));
        return (int) reviewDocPage.getTotalElements();
    }
}
