package namoo.drama.feedback.da.mongo.springdata;

import namoo.drama.feedback.da.mongo.document.feedback.FeedbackDoc;
import namoo.nara.share.domain.ScreenId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
public interface FeedbackMongoRepository extends MongoRepository<FeedbackDoc, String> {
    //
    Page<FeedbackDoc> findAllByInformantScreenIdPavilionId(String pavilionId, Pageable pageable);
    Page<FeedbackDoc> findAllByInformantScreenIdPavilionIdAndInformantScreenIdCineroomId(String pavilionId, String cineroomId, Pageable pageable);
    Page<FeedbackDoc> findAllByInformantScreenId(ScreenId screenId, Pageable pageable);
    Page<FeedbackDoc> findAllByInformantScreenIdPavilionIdAndInformantScreenIdDramaId(String pavilionId, String dramaId, Pageable pageable);
    List<FeedbackDoc> findAllByInformantSourceEntityName(String sourceEntityName);

}
