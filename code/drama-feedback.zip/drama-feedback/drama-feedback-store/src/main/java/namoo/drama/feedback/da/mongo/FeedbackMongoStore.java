package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.mongo.document.feedback.FeedbackDoc;
import namoo.drama.feedback.da.mongo.springdata.FeedbackMongoRepository;
import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.store.FeedbackStore;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.domain.ScreenId;
import namoo.nara.share.exception.store.NonExistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Repository
public class FeedbackMongoStore implements FeedbackStore {
    //
    @Autowired
    private FeedbackMongoRepository repository;

    @Override
    public void create(Feedback feedback) {
        //
        repository.insert(FeedbackDoc.toDocument(feedback));
    }

    @Override
    public Feedback retrieve(String id) {
        //
        if (!repository.exists(id)) {
            create(new Feedback(id));
        }
        return repository.findOne(id).toDomain();
    }

    @Override
    public OffsetList<Feedback> retrieveAllByPavilionId(String pavilionId, int offset, int limit) {
        //
        int page = offset/limit; // zero-based page index.
        PageRequest pageRequest = new PageRequest(page, limit);
        Page<FeedbackDoc> feedbackDocPage = repository.findAllByInformantScreenIdPavilionId(pavilionId, pageRequest);


        return new OffsetList<>(FeedbackDoc.toDomains(feedbackDocPage.getContent()), (int) feedbackDocPage.getTotalElements());
    }

    @Override
    public OffsetList<Feedback> retrieveAllByPavilionIdAndCineroomId(String pavilionId, String cineroomId, int offset, int limit) {
        //
        int page = offset/limit; // zero-based page index.
        PageRequest pageRequest = new PageRequest(page, limit);
        Page<FeedbackDoc> feedbackDocPage =
            repository.findAllByInformantScreenIdPavilionIdAndInformantScreenIdCineroomId(pavilionId, cineroomId, pageRequest);


        return new OffsetList<>(FeedbackDoc.toDomains(feedbackDocPage.getContent()), (int) feedbackDocPage.getTotalElements());
    }

    @Override
    public OffsetList<Feedback> retrieveAllByScreenId(ScreenId screenId, int offset, int limit) {
        //
        int page = offset/limit; // zero-based page index.
        PageRequest pageRequest = new PageRequest(page, limit);
        Page<FeedbackDoc> feedbackDocPage = repository.findAllByInformantScreenId(screenId, pageRequest);


        return new OffsetList<>(FeedbackDoc.toDomains(feedbackDocPage.getContent()), (int) feedbackDocPage.getTotalElements());
    }

    @Override
    public OffsetList<Feedback> retrieveAllByPavilionIdAndDramaId(String pavilionId, String dramaId, int offset, int limit) {
        //
        int page = offset/limit; // zero-based page index.
        PageRequest pageRequest = new PageRequest(page, limit);
        Page<FeedbackDoc> feedbackDocPage =
            repository.findAllByInformantScreenIdPavilionIdAndInformantScreenIdDramaId(pavilionId, dramaId, pageRequest);


        return new OffsetList<>(FeedbackDoc.toDomains(feedbackDocPage.getContent()), (int) feedbackDocPage.getTotalElements());
    }

    @Override
    public List<Feedback> retrieveAllBySourceEntityName(String sourceEntityName) {
        //
        return FeedbackDoc.toDomains(repository.findAllByInformantSourceEntityName(sourceEntityName));
    }

    @Override
    public void update(Feedback feedback) {
        //
        if (!repository.exists(feedback.getId())) throw new NonExistenceException(String.format("No such a feedback[%s] to update.", feedback.getId()));
        repository.save(FeedbackDoc.toDocument(feedback));
    }

    @Override
    public void delete(String id) {
        //
        if (!repository.exists(id)) throw new NonExistenceException(String.format("No such a feedback[%s] to delete.", id));
        repository.delete(id);
    }
}
