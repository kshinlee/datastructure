package namoo.drama.feedback.da.mongo.springdata;

import namoo.drama.feedback.da.mongo.document.review.HelpCommentDoc;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
public interface HelpCommentMongoRepository extends MongoRepository<HelpCommentDoc, String> {
    //
    HelpCommentDoc findOneByReviewIdAndReviewerId(String reviewId, String reviewerId);
    Page<HelpCommentDoc> findAllByReviewId(String reviewId, Pageable pageable);
    void deleteAllByReviewId(String reviewId);
    int countByReviewId(String reviewId);
}
