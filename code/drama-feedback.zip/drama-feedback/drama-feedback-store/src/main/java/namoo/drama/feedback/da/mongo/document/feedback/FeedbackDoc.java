package namoo.drama.feedback.da.mongo.document.feedback;

import namoo.drama.feedback.domain.entity.feedback.Feedback;
import namoo.drama.feedback.domain.entity.feedback.FeedbackConfig;
import namoo.drama.feedback.domain.entity.feedback.FeedbackType;
import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import namoo.nara.share.domain.*;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Document(collection = "DR_FEEDBACK_FEEDBACK")
public class FeedbackDoc {
    //
    @Id
    private String id;

    private String title;
    private Informant informant;
    private FeedbackType type;
    private FeedbackConfig config;
    private Long time;

    @Version
    private Long entityVersion;

    public FeedbackDoc() {

    }

    public static FeedbackDoc toDocument(Feedback feedback) {
        //
        FeedbackDoc feedbackDoc = new FeedbackDoc();
        feedbackDoc.setId(feedback.getId());
        feedbackDoc.setEntityVersion(feedback.getEntityVersion());
        BeanUtils.copyProperties(feedback, feedbackDoc);

        return  feedbackDoc;
    }

    public Feedback toDomain() {
        //
        Feedback feedback = new Feedback(id);
        feedback.setEntityVersion(entityVersion);
        BeanUtils.copyProperties(this, feedback);
        return feedback;
    }

    public static List<Feedback> toDomains(List<FeedbackDoc> feedbackDocs) {
        //
        if (feedbackDocs == null) return Collections.EMPTY_LIST;
        return feedbackDocs.stream().map(feedbackDoc -> feedbackDoc.toDomain()).collect(Collectors.toList());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public FeedbackConfig getConfig() {
        return config;
    }

    public void setConfig(FeedbackConfig config) {
        this.config = config;
    }

    public FeedbackType getType() {
        return type;
    }

    public void setType(FeedbackType type) {
        this.type = type;
    }

    public Informant getInformant() {
        return informant;
    }

    public void setInformant(Informant informant) {
        this.informant = informant;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Long getEntityVersion() {
        return entityVersion;
    }

    public void setEntityVersion(Long entityVersion) {
        this.entityVersion = entityVersion;
    }
}
