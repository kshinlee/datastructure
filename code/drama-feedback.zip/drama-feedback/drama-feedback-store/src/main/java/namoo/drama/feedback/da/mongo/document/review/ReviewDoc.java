package namoo.drama.feedback.da.mongo.document.review;

import namoo.drama.feedback.da.mongo.document.reply.ReplyDoc;
import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.entity.review.Review;
import namoo.nara.share.domain.Actor;
import namoo.nara.share.domain.IntPair;
import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Document(collection = "DR_FEEDBACK_REVIEW")
public class ReviewDoc {
    //
    @Id
    private String id;

    private String version;
    private Actor writer;
    private String title;
    private String opinion;
    private int selectedStar;
    private Long time;
    private IntPair helpCount;          // helpful/total

    private String feedbackId;

    @Version
    private Long entityVersion;

    public static ReviewDoc toDocument(Review review) {
        //
        ReviewDoc reviewDoc = new ReviewDoc();
        reviewDoc.setId(review.getId());
        reviewDoc.setEntityVersion(review.getEntityVersion());
        BeanUtils.copyProperties(review, reviewDoc);

        return  reviewDoc;
    }

    public Review toDomain() {
        //
        Review review = new Review(id);
        review.setEntityVersion(entityVersion);
        BeanUtils.copyProperties(this, review);
        return review;
    }

    public static List<Review> toDomains(List<ReviewDoc> reviewDocs) {
        //
        if (reviewDocs == null) return Collections.EMPTY_LIST;
        return reviewDocs.stream().map(reviewDoc -> reviewDoc.toDomain()).collect(Collectors.toList());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Actor getWriter() {
        return writer;
    }

    public void setWriter(Actor writer) {
        this.writer = writer;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOpinion() {
        return opinion;
    }

    public void setOpinion(String opinion) {
        this.opinion = opinion;
    }

    public Integer getSelectedStar() {
        return selectedStar;
    }

    public void setSelectedStar(Integer selectedStar) {
        this.selectedStar = selectedStar;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public IntPair getHelpCount() {
        return helpCount;
    }

    public void setHelpCount(IntPair helpCount) {
        this.helpCount = helpCount;
    }

    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public Long getEntityVersion() {
        return entityVersion;
    }

    public void setEntityVersion(Long entityVersion) {
        this.entityVersion = entityVersion;
    }
}
