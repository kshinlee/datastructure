package namoo.drama.feedback.da.mongo.springdata;

import namoo.drama.feedback.da.mongo.document.review.ReviewSummaryDoc;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
public interface ReviewSummaryMongoRepository extends MongoRepository<ReviewSummaryDoc, String> {
}
