package namoo.drama.feedback.da.mongo.document.reply;

import namoo.drama.feedback.domain.entity.reply.CommentList;
import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.nara.share.domain.Actor;
import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Document(collection = "DR_FEEDBACK_REPLY")
public class ReplyDoc {
    //
    @Id
    private String id;

    private Actor writer;				// anonymous --> temp id : password
    private String text;
    private Integer commentSequence;

    private CommentList comments;
    private Long time;
    private String feedbackId;

    @Version
    private Long entityVersion;

    public ReplyDoc() {

    }

    public static ReplyDoc toDocument(Reply reply) {
        //
        ReplyDoc replyDoc = new ReplyDoc();
        replyDoc.setId(reply.getId());
        replyDoc.setEntityVersion(reply.getEntityVersion());
        BeanUtils.copyProperties(reply, replyDoc);

        return  replyDoc;
    }

    public Reply toDomain() {
        //
        Reply reply = new Reply(id);
        reply.setEntityVersion(entityVersion);
        BeanUtils.copyProperties(this, reply);
        return reply;
    }

    public static List<Reply> toDomains(List<ReplyDoc> replyDocs) {
        //
        if (replyDocs == null) return Collections.EMPTY_LIST;
        return replyDocs.stream().map(replyDoc -> replyDoc.toDomain()).collect(Collectors.toList());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Actor getWriter() {
        return writer;
    }

    public void setWriter(Actor writer) {
        this.writer = writer;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getCommentSequence() {
        return commentSequence;
    }

    public void setCommentSequence(Integer commentSequence) {
        this.commentSequence = commentSequence;
    }

    public CommentList getComments() {
        return comments;
    }

    public void setComments(CommentList comments) {
        this.comments = comments;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public Long getEntityVersion() {
        return entityVersion;
    }

    public void setEntityVersion(Long entityVersion) {
        this.entityVersion = entityVersion;
    }
}
