package namoo.drama.feedback.da.mongo;

import namoo.drama.feedback.da.mongo.document.reply.ReplyDoc;
import namoo.drama.feedback.da.mongo.springdata.ReplyMongoRepository;
import namoo.drama.feedback.domain.entity.reply.Reply;
import namoo.drama.feedback.domain.store.ReplyStore;
import namoo.nara.share.domain.OffsetList;
import namoo.nara.share.exception.store.NonExistenceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Repository
public class ReplyMongoStore implements ReplyStore {
    //
    @Autowired
    private ReplyMongoRepository repository;

    @Override
    public void create(Reply reply) {
        //
        repository.insert(ReplyDoc.toDocument(reply));
    }

    @Override
    public Reply retrieve(String id) {
        //
        if (!repository.exists(id)) {
            create(new Reply(id));
        }
        return repository.findOne(id).toDomain();
    }

    @Override
    public List<Reply> retrieveAllByFeedbackId(String feedbackId) {
        //
        return ReplyDoc.toDomains(repository.findAllByFeedbackId(feedbackId));
    }

    @Override
    public OffsetList<Reply> retrieveAll(String feedbackId, int offset, int limit) {
        //
        int page = offset/limit;

        PageRequest pageRequest = new PageRequest(page, limit, new Sort(Sort.Direction.DESC, "time"));
        Page<ReplyDoc> replyDocPage = repository.findAllByFeedbackId(feedbackId, pageRequest);
        List<Reply> replies = ReplyDoc.toDomains(replyDocPage.getContent());
        OffsetList<Reply> offsetList = new OffsetList<>(replies, (int)replyDocPage.getTotalElements());
        return offsetList;
    }

    @Override
    public void update(Reply reply) {
        //
        if (!repository.exists(reply.getId())) throw new NonExistenceException(String.format("No such a reply[%s] to update.", reply.getId()));
        repository.save(ReplyDoc.toDocument(reply));
    }

    @Override
    public void delete(Reply reply) {
        //
        if (!repository.exists(reply.getId())) throw new NonExistenceException(String.format("No such a reply[%s] to delete.", reply.getId()));
        repository.delete(ReplyDoc.toDocument(reply));
    }


    @Override
    public void deleteByFeedbackId(String feedbackId) {
        //
        repository.deleteAllByFeedbackId(feedbackId);
    }
}
