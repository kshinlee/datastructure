package namoo.drama.feedback.da.mongo.document.review;

import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.nara.share.domain.IntPairList;
import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Map;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Document(collection = "DR_FEEDBACK_REVIEW_SUMMARY")
public class ReviewSummaryDoc {
    //
    @Id
    private String id;

    private Boolean versionBased;
    private Integer maxStarCount;

    private Integer reviewerCount;
    private Double average;             // 4.31
    private IntPairList starCounts;     // 1:2, 2:3, 3:0, 4:5, 5:10

    private Map<String,IntPairList> versionStarCountMap;
    private Map<String,Integer> versionReviewerCountMap;

    @Version
    private Long entityVersion;

    public static ReviewSummaryDoc toDocument(ReviewSummary reviewSummary) {
        //
        ReviewSummaryDoc reviewSummaryDoc = new ReviewSummaryDoc();
        reviewSummaryDoc.setId(reviewSummary.getId());
        reviewSummaryDoc.setEntityVersion(reviewSummary.getEntityVersion());
        BeanUtils.copyProperties(reviewSummary, reviewSummaryDoc);

        return  reviewSummaryDoc;
    }

    public ReviewSummary toDomain() {
        //
        ReviewSummary reviewSummary = new ReviewSummary(id);
        reviewSummary.setEntityVersion(entityVersion);
        BeanUtils.copyProperties(this, reviewSummary);
        return reviewSummary;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean getVersionBased() {
        return versionBased;
    }

    public void setVersionBased(Boolean versionBased) {
        this.versionBased = versionBased;
    }

    public Integer getReviewerCount() {
        return reviewerCount;
    }

    public int getMaxStarCount() {
        return maxStarCount;
    }

    public void setMaxStarCount(Integer maxStarCount) {
        this.maxStarCount = maxStarCount;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(Double average) {
        this.average = average;
    }

    public IntPairList getStarCounts() {
        return starCounts;
    }

    public void setStarCounts(IntPairList starCounts) {
        this.starCounts = starCounts;
    }

    public void setReviewerCount(Integer reviewerCount) {
        this.reviewerCount = reviewerCount;
    }

    public Map<String, IntPairList> getVersionStarCountMap() {
        return versionStarCountMap;
    }

    public void setVersionStarCountMap(Map<String, IntPairList> versionStarCountMap) {
        this.versionStarCountMap = versionStarCountMap;
    }

    public Map<String, Integer> getVersionReviewerCountMap() {
        return versionReviewerCountMap;
    }

    public void setVersionReviewerCountMap(Map<String, Integer> versionReviewerCountMap) {
        this.versionReviewerCountMap = versionReviewerCountMap;
    }

    public Long getEntityVersion() {
        return entityVersion;
    }

    public void setEntityVersion(Long entityVersion) {
        this.entityVersion = entityVersion;
    }
}
