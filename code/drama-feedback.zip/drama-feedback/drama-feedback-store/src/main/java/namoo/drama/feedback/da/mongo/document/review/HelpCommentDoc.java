package namoo.drama.feedback.da.mongo.document.review;

import namoo.drama.feedback.domain.entity.review.HelpComment;
import namoo.drama.feedback.domain.entity.review.ReviewSummary;
import namoo.nara.share.domain.IntPairList;
import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
@Document(collection = "DR_FEEDBACK_HELP_COMMENT")
public class HelpCommentDoc {
    //
    @Id
    private String id;

    private Boolean anonymous;
    private String reviewerId;
    private Boolean helpful;
    private Long time;

    private String reviewId;

    @Version
    private Long entityVersion;

    public static HelpCommentDoc toDocument(HelpComment helpComment) {
        //
        HelpCommentDoc helpCommentDoc = new HelpCommentDoc();
        helpCommentDoc.setId(helpComment.getId());
        helpCommentDoc.setEntityVersion(helpComment.getEntityVersion());
        BeanUtils.copyProperties(helpComment, helpCommentDoc);

        return  helpCommentDoc;
    }

    public HelpComment toDomain() {
        //
        HelpComment helpComment = new HelpComment(id);
        helpComment.setEntityVersion(entityVersion);
        BeanUtils.copyProperties(this, helpComment);
        return helpComment;
    }

    public static List<HelpComment> toDomains(List<HelpCommentDoc> helpCommentDocs) {
        //
        if (helpCommentDocs == null || helpCommentDocs.isEmpty()) return Collections.EMPTY_LIST;
        return helpCommentDocs.stream().map(helpCommentDoc -> helpCommentDoc.toDomain()).collect(Collectors.toList());
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean getAnonymous() {
        return anonymous;
    }

    public void setAnonymous(Boolean anonymous) {
        this.anonymous = anonymous;
    }

    public String getReviewerId() {
        return reviewerId;
    }

    public void setReviewerId(String reviewerId) {
        this.reviewerId = reviewerId;
    }

    public Boolean getHelpful() {
        return helpful;
    }

    public void setHelpful(Boolean helpful) {
        this.helpful = helpful;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getReviewId() {
        return reviewId;
    }

    public void setReviewId(String reviewId) {
        this.reviewId = reviewId;
    }

    public Long getEntityVersion() {
        return entityVersion;
    }

    public void setEntityVersion(Long entityVersion) {
        this.entityVersion = entityVersion;
    }
}
