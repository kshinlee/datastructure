package namoo.drama.feedback.da.mongo.springdata;

import namoo.drama.feedback.da.mongo.document.reply.ReplyDoc;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * @author <a href="mailto:jsseo@nextree.co.kr">Seo, Jisu</a>
 * @since 2017-05-08
 */
public interface ReplyMongoRepository extends MongoRepository<ReplyDoc, String> {
    //
    List<ReplyDoc> findAllByFeedbackId(String feedbackId);
    Page<ReplyDoc> findAllByFeedbackId(String feedbackId, Pageable pageable);
    void deleteAllByFeedbackId(String feedbackId);
}
