/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.list.link;

import java.lang.reflect.Array;
import java.util.Iterator;

import namoosori.datastructure.iterator.MyIterator;
import namoosori.datastructure.iterator.logic.MyIteratorLogic;
import namoosori.datastructure.list.facade.MyList;

public class MyLinkedList<E> implements MyList<E> {
	//
	private int size; 
	private Node head; 
	private Node tail; 
	
	public MyLinkedList() {
		// 
		this.clear();  
	}

	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("head:").append(head); 
		builder.append(", size:").append(size); 
		builder.append(", tail:").append(tail); 
		
		return builder.toString(); 
	}

	public void addFirst(E element) {
		// 
		Node newNode = new Node(element); 
		newNode.setNext(head);
		head = newNode; 
		size++; 
		if (head.isTail()) {
			tail = head; 
		} 
	}
	
	public void addLast(E element) {
		// 
		if(size == 0) {
			addFirst(element);
			return; 
		} 

		Node newNode = new Node(element); 
		tail.setNext(newNode);
		tail = newNode; 
		size++; 
	}
	
	@Override
	public int size() {
		// 
		return size;
	}

	@Override
	public boolean empty() {
		// 
		if(size == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public boolean contains(Object object) {
		// 
		boolean found = false; 
		Node targetNode = head; 
		
		while(targetNode != null) {
			if (targetNode.getElement().equals(object)) {
				found = true;
				break; 
			}
			targetNode = targetNode.getNext(); 
		}
		
		return found;
	}

	@Override
	public MyIterator<E> iterator() {
		// 
		@SuppressWarnings("unchecked")
		E[] newElements = (E[])new Object[size];
		Node node = head; 
		int i = 0; 
		while(node != null) {
			newElements[i++] = node.getElement(); 
			node = node.getNext(); 
		}
		
		return new MyIteratorLogic<E>(newElements); 
	}

	@Override
	public void add(E element) {
		// 
		if(size == 0) {
			addFirst(element); 
		} else {
			addLast(element); 
		}
	}

	@Override
	public void add(int index, E element) {
		// 
		if (index != size) {
			checkArrayIndex(index);
		}
		
		if (index == 0) {
			addFirst(element); 
		} else if (index == size) {
			addLast(element); 
		} else {
			Node previousNode = getNode(index-1); 
			Node nextNode = previousNode.getNext(); 
			Node newNode = new Node(element); 
			previousNode.setNext(newNode);
			newNode.setNext(nextNode); 
			size++; 
		}
	}

	@Override
	public E get(int index) {
		// 
		checkArrayIndex(index); 
		
		Node targetNode = head; 
		for(int i=0; i<index; i++) {
			targetNode = targetNode.getNext(); 
		}
		
		return targetNode.getElement();
	}


	@Override
	public void remove(int index) {
		// 
		checkArrayIndex(index); 
		
		if (index == 0) {
			removeFirst(); 
			return; 
		} 
		
		Node previousNode = getNode(index - 1); 
		Node targetNode = previousNode.getNext(); 
		previousNode.setNext(targetNode.getNext()); 
		size--;
		
		if(previousNode.isTail()) {
			tail = previousNode; 	
		}
	}
	
	@Override
	public void remove(Object object) {
		// 
		Node targetNode = head; 
		boolean found = false; 
		int index = 0; 
		while(targetNode != null) {
			if(targetNode.getElement().equals(object)) {
				found = true; 
				break;
			}
			targetNode = targetNode.getNext(); 
			index++; 
		}

		if (found) {
			remove(index); 
		}
	}
	
	public E removeFirst() {
		// 
		if(size == 0) {
			return null; 
		}
		
		Node removedNode = head; 
		head = head.getNext(); 
		size--; 

		if(size == 0) {
			clear(); 
		}
		
		return removedNode.getElement(); 
	}

	@Override
	public void addAll(MyList<? extends E> collection) {
		// 
		@SuppressWarnings("unchecked")
		Iterator<E> iter = (Iterator<E>)collection.iterator(); 
		while(iter.hasNext()) {
			E newElement = iter.next(); 
			if(size == 0) {
				addFirst(newElement); 
			} else {
				addLast(newElement);
			}
		}
	}

	@Override
	public void clear() {
		//
		size = 0; 
		head = null; 
		tail = null;
	}
	


	@Override
	@SuppressWarnings("unchecked")
	public <T> T[] toArray(T[] some) {
		// 
		T[] newElements = (T[])Array.newInstance(some.getClass().getComponentType(), size); 
		Node node = head; 
		int i = 0; 
		while(node != null) {
			newElements[i++] = (T)node.getElement(); 
			node = node.getNext(); 
		}

		return newElements;
	}

	private Node getNode(int index) {
		// 
		this.checkArrayIndex(index); 
		
		Node targetNode = head; 
		for(int i=0; i<index; i++) {
			targetNode = targetNode.getNext(); 
		}
		
		return targetNode;
	}
	
	private void checkArrayIndex(int index) {
		// 
		if(index < 0 || index >= size) {
			throw new IndexOutOfBoundsException("index:" + index); 
		}
	}

	private class Node {
		// 
		private E element; 
		private Node next; 
		
		public Node(E element) {
			// 
			this.element = element;
			this.next = null; 
		}
		
		public String toString() {
			// 
			StringBuilder builder = new StringBuilder(); 

			builder.append("element:").append(element); 
			builder.append(", next:").append((getNext() == null)? "null": getNext().getElement()); 
			
			return builder.toString(); 
		}

		public boolean isTail() {
			// 
			if(next == null) {
				return true; 
			}
			
			return false; 
		}
		
		public E getElement() {
			return element;
		}

		public Node getNext() {
			return next;
		}

		public void setNext(Node next) {
			this.next = next;
		}
	}
}