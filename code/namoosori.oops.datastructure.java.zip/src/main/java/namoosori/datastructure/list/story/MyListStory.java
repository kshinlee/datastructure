/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.list.story;

import namoosori.datastructure.iterator.MyIterator;
import namoosori.datastructure.list.array.MyArrayList;
import namoosori.datastructure.list.facade.MyList;

public class MyListStory {
	
	public static void main(String[] args) {
		// 
		MyListStory story = new MyListStory(); 
		story.tellMe(); 
	}

	public void tellMe() {
		// 
		MyList<String> months = new MyArrayList<>(); 
		String april = "4.April"; 
		
		months.add(0, "1.January"); 
		months.add(1, "2.February"); 
		months.add(2, "3.March"); 
		months.add(3, april); 
		months.add(4, "5.May"); 
		months.add(5, "6.June"); 
		months.add(6, "7.July"); 
		months.add(7, "8.August"); 
		months.add("9.September"); 
		months.add("10.October"); 
		months.add("11.November"); 
		months.add("12.December"); 
		
		MyIterator<String> monthIter = months.iterator(); 
		while(monthIter.hasNext()) {
			String month = monthIter.next(); 
			System.out.println(month); 
		}

		months.add(12, "13.NewMonth"); 
		
		int arraySize = months.size(); 
		for(int i=0; i<arraySize; i++) {
			System.out.print(months.get(i) + ", ");
		}
		System.out.println(""); 
		
		months.clear(); 
		System.out.println("\n" + months.toString());
	}
}
