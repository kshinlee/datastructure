/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.list.link;

import namoosori.datastructure.iterator.MyStringIterator;
import namoosori.datastructure.iterator.logic.MyStringIteratorLogic;
import namoosori.datastructure.list.facade.MyStringList;

public class MyStringLinkedList implements MyStringList {
	//
	private int size; 
	private Node head; 
	private Node tail; 
	
	public MyStringLinkedList() {
		// 
		this.clear();  
	}

	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("head:").append(head); 
		builder.append(", size:").append(size); 
		builder.append(", tail:").append(tail); 
		
		return builder.toString();  
	}


	@Override
	public int size() {
		// 
		return size;
	}

	@Override
	public boolean empty() {
		// 
		if(size == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public boolean contains(String element) {
		// 
		boolean found = false; 
		Node targetNode = head; 
		
		while(targetNode != null) {
			if (targetNode.getElement().equals(element)) {
				found = true;
				break; 
			}
			targetNode = targetNode.getNext(); 
		}
		
		return found;
	}

	@Override
	public MyStringIterator iterator() {
		// 
		String[] newElements = new String[size];
		Node node = head; 
		int i=0; 
		while(node != null) {
			newElements[i] = node.getElement(); 
			node = node.getNext(); 
		}
		
		return new MyStringIteratorLogic(newElements); 
	}

	@Override
	public void add(String element) {
		// 
		if(size == 0) {
			addFirst(element); 
		} else {
			addLast(element); 
		}
	}

	@Override
	public void add(int index, String element) {
		// 
		if(index != size) {
			this.checkArrayIndex(index);
		}
		
		if (index == 0) {
			addFirst(element); 
		} else if (index == size) {
			addLast(element);
		} else {
			addMiddle(index, element); 
		}
	}

	public void addFirst(String e) {
		// 
		Node newNode = new Node(e); 
		newNode.setNext(head);
		head = newNode; 
		size++; 
		if (head.isTail()) {
			tail = head; 
		} 
	}
	
	public void addMiddle(int index, String element) {
		// 
		Node previousNode = getNode(index-1); 
		Node nextNode = previousNode.getNext(); 
		Node newNode = new Node(element); 
		previousNode.setNext(newNode);
		newNode.setNext(nextNode); 
		size++; 
	}
	
	public void addLast(String e) {
		// 
		if(size == 0) {
			addFirst(e); 
			return; 
		} 

		Node newNode = new Node(e); 
		tail.setNext(newNode);
		tail = newNode; 
		size++; 
	}
	

	@Override
	public void addAll(MyStringList c) {
		// 
		MyStringIterator iter = c.iterator(); 
		while(iter.hasNext()) {
			String newElement = iter.next(); 
			if(size == 0) {
				addFirst(newElement); 
			} else {
				addLast(newElement);
			}
		}
	}
	
	@Override
	public String get(int index) {
		// 
		this.checkArrayIndex(index); 
		
		Node targetNode = head; 
		for(int i=0; i<index; i++) {
			targetNode = targetNode.getNext(); 
		}
		
		return targetNode.getElement();
	}


	@Override
	public void remove(int index) {
		// 
		this.checkArrayIndex(index); 

		if (index == 0) {
			removeFirst(); 
			return; 
		} 
		
		Node previousNode = getNode(index - 1); 
		Node targetNode = previousNode.getNext(); 
		previousNode.setNext(targetNode.getNext()); 
		size--;
		
		if(previousNode.isTail()) {
			tail = previousNode; 	
		}
	}
	
	@Override
	public void remove(String element) {
		// 
		Node targetNode = head; 
		int index = 0; 
		boolean found = false; 
		while(targetNode != null) {
			if(targetNode.getElement().equals(element)) {
				found = true; 
				break;
			}
			targetNode = targetNode.getNext(); 
			index++; 
		}

		if (found) {
			remove(index); 
		}
	}
	
	public String removeFirst() {
		// 
		if(size == 0) {
			return null; 
		}
		
		Node removedNode = head; 
		head = head.getNext(); 
		size--; 

		if(size == 0) {
			clear(); 
		}
		
		return removedNode.getElement(); 
	}

	@Override
	public void clear() {
		//
		size = 0; 
		head = null; 
		tail = null; 
	}

	@Override
	public String[] toArray() {
		// 
		String[] newElements = new String[size];
		Node node = head; 
		for(int i=0; i<size; i++) {
			newElements[i] = node.getElement(); 
			node = node.getNext(); 
		}
		
		return newElements; 
	}

	private Node getNode(int index) {
		//
		this.checkArrayIndex(index);
		
		Node targetNode = head; 
		for(int i=0; i<index; i++) {
			targetNode = targetNode.getNext(); 
		}
		
		return targetNode;
	}

	private void checkArrayIndex(int index) {
		// 
		if(index < 0 || index >= size) {
			throw new IndexOutOfBoundsException("index:" + index); 
		}
	}
	
	private class Node {
		// 
		String element; 
		Node next; 
		
		public Node(String element) {
			// 
			this.element = element;
			this.next = null; 
		}
		
		public String toString() {
			// 
			StringBuilder builder = new StringBuilder(); 

			builder.append("element:").append(element); 
			builder.append(", next:").append((getNext() == null)? "null": getNext().getElement()); 
			
			return builder.toString(); 
		}

		public boolean isTail() {
			// 
			if (next == null) {
				return true; 
			}
			
			return false; 
		}
		
		public String getElement() {
			return element;
		}

		public Node getNext() {
			return next;
		}

		public void setNext(Node next) {
			this.next = next;
		}
	}
}