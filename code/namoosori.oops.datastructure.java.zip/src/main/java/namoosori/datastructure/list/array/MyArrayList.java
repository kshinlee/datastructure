/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.list.array;

import java.lang.reflect.Array;

import namoosori.datastructure.iterator.MyIterator;
import namoosori.datastructure.iterator.logic.MyIteratorLogic;
import namoosori.datastructure.list.facade.MyList;

public class MyArrayList<E> implements MyList<E>  {
	//
	private static final int INITIAL_CAPACITY = 10; 
	
	private int length; 
	private int capacity; 
	private E[] elements; 
	
	public MyArrayList() {
		// 
		this.clear(); 
	}
	
	public MyArrayList(int capacity) {
		// 
		this.clear(capacity); 
	}
	
	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("length:").append(length); 
		builder.append(", capacity:").append(capacity); 
		builder.append(", elements:").append(elements); 
		
		return builder.toString(); 
	}
	
	@Override
	public int size() {
		// 
		return length;
	}

	@Override
	public boolean empty() {
		//
		if (length == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public boolean contains(Object object) {
		// 
		boolean contained = false; 
		
		for(int index = 0; index<length; index++) {
			// 
			if (elements[index].equals(object)) {
				contained = true; 
				break; 
			}
		}
		
		return contained;
	}

	@SuppressWarnings("unchecked")
	@Override
	public MyIterator<E> iterator() {
		// 
		return new MyIteratorLogic<E>(toArray((E[])new Object[1]));  
	}

	@Override
	public void add(E element) {
		// 
		if(length == capacity) {
			increaseCapacity(); 
		}
		this.elements[length] = element;
		this.length++; 
	}

	@Override
	public void add(int index, E element) {
		// 
		if (index != length) {
			this.checkArrayIndex(index);
		}
		
		if(length == capacity) {
			increaseCapacity(); 
		}
		
		if(length > 0) {
			shiftRightFrom(index);
		}

		elements[index] = element; 
		length++; 
	}
	
	@Override
	public E get(int index) {
		// 
		checkArrayIndex(index); 
		
		return elements[index]; 
	}

	@Override
	public void remove(Object object) {
		// 
		int index = -1; 
		for(int i=0; i<length; i++) {
			// 
			if(elements[i].equals(object)) {
				index = i; 
				break; 
			}
		}
		
		if(index > -1) {
			remove(index); 
		}
	}

	@Override
	public void remove(int index) {
		// 
		elements[index] = null; 
		shiftLeftTo(index); 
		length--; 
	}

	@Override
	public void addAll(MyList<? extends E> collection) {
		//
		int targetCapacity = length + collection.size(); 
		if (targetCapacity > capacity) {
			increaseCapacity(targetCapacity);  
		}
		
		int sourceLength = collection.size(); 
		for(int i=0; i<sourceLength; i++) {
			elements[length++] = collection.get(i);   
		}
	}

	@Override
	public void clear() {
		// 
		clear(INITIAL_CAPACITY);
	}
	
	@SuppressWarnings("unchecked")
	private void clear(int capacity) {
		//
		this.length = 0; 
		this.capacity = capacity; 
		this.elements = (E[])new Object[capacity]; 
	}
	
	@Override
	public <T> T[] toArray(T[] some) {
		// 
		@SuppressWarnings("unchecked")
		T[] newElements = (T[])Array.newInstance(
				some.getClass().getComponentType(), 
				length); 
		System.arraycopy(elements, 0, newElements, 0, length); 
		return newElements;
	}

	private void increaseCapacity() {
		// 
		increaseCapacity(10);
	}
	
	@SuppressWarnings("unchecked")
	private void increaseCapacity(int targetCapacity) {
		// 
		while(true) {
			if (capacity > targetCapacity) {
				break; 
			}
			capacity += INITIAL_CAPACITY; 
		}
		
		E[] newElements = (E[])new Object[capacity];
		System.arraycopy(elements, 0, newElements, 0, elements.length); 
		elements = newElements; 
		newElements = null; 
	}

	private void shiftRightFrom(int position) {
		//
		for(int i=length; i>position; i--) {
			// 
			elements[i] = elements[i-1]; 
		}
	}
	
	private void shiftLeftTo(int position) {
		// 
		for(int i=position; i<length; i++) {
			// 
			elements[i] = elements[i+1]; 
		}
	}
	
	private void checkArrayIndex(int index) {
		// 
		if(index < 0 || index >= length) {
			throw new IndexOutOfBoundsException("index:" + index); 
		}
	}
}