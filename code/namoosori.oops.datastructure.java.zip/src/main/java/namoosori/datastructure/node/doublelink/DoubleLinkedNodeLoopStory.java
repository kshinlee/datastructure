/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.doublelink;

public class DoubleLinkedNodeLoopStory {
	// 
	public static void main(String[] args) {
		// 
		showLinkedLinkedNodeDemo(); 
	}
	
	public static void showLinkedLinkedNodeDemo() {
		// 
		DoubleLinkedNode sundayNode = new DoubleLinkedNode("Sunday");
		sundayNode.setNext(new DoubleLinkedNode("Monday"))
				.setNext(new DoubleLinkedNode("Thuesday")) 
				.setNext(new DoubleLinkedNode("Wednesday")) 
				.setNext(new DoubleLinkedNode("Thursday"))
				.setNext(new DoubleLinkedNode("Friday"))
				.setNext(new DoubleLinkedNode("Satureday"))
				
				.setNext(sundayNode); 
		
		DoubleLinkedNode dayNode = sundayNode; 
		for(int i=0; i<12; i++) {
			dayNode.show(); 
			dayNode = dayNode.getNext(); 
		}
		System.out.println("...."); 
		
		dayNode = sundayNode; 
		for(int i=0; i<21; i++) {
			dayNode.show(); 
			dayNode = dayNode.getPrevious(); 
		}
	}
}