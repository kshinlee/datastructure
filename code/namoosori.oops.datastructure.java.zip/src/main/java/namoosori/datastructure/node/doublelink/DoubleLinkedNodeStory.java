/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.doublelink;

public class DoubleLinkedNodeStory {
	// 
	public static void main(String[] args) {
		// 
		showLinkedLinkedNodeDemo(); 
	}
	
	public static void showLinkedLinkedNodeDemo() {
		// 
		DoubleLinkedNode sundayNode = new DoubleLinkedNode("Sunday");
		sundayNode.setNext(new DoubleLinkedNode("Monday"))
				.setNext(new DoubleLinkedNode("Thuesday")) 
				.setNext(new DoubleLinkedNode("Wednesday")) 
				.setNext(new DoubleLinkedNode("Thursday"))
				.setNext(new DoubleLinkedNode("Friday"))
				.setNext(new DoubleLinkedNode("Satureday")); 
		
		DoubleLinkedNode dayNode = sundayNode; 
		DoubleLinkedNode lastNode = null; 
		while(true) {
			dayNode.show(); 
			if (dayNode.getNext() == null) {
				lastNode = dayNode; 
				break; 
			}
			dayNode = dayNode.getNext(); 
		}
		
		dayNode = lastNode; 
		while(dayNode != null) {
			dayNode.show(); 
			dayNode = dayNode.getPrevious(); 
		}
	}
}