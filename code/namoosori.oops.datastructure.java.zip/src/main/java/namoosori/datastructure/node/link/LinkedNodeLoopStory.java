/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.link;

public class LinkedNodeLoopStory {
	// 
	public static void main(String[] args) {
		// 
		showLinkedLinkedNodeDemo(); 
	}
	
	public static void showLinkedLinkedNodeDemo() {
		// 
		LinkedNode sundayNode = new LinkedNode("Sunday");
		sundayNode.setNext(new LinkedNode("Monday"))
				.setNext(new LinkedNode("Thuesday")) 
				.setNext(new LinkedNode("Wednesday")) 
				.setNext(new LinkedNode("Thursday"))
				.setNext(new LinkedNode("Friday"))
				.setNext(new LinkedNode("Satureday"))
				.setNext(sundayNode); 				// make them loop
		
		LinkedNode dayNode = sundayNode; 
		for(int i=0; i<13; i++) {
			dayNode.show(); 
			dayNode = dayNode.getNext(); 
		}
	}
}