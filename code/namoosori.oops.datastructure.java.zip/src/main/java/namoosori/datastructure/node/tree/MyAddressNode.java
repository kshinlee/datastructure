/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.tree;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

public class MyAddressNode implements TreeNode {
	// 
	private TreeNode parent; 
	private Map<String,TreeNode> children; 
	private String value; 
	
	public MyAddressNode(String text) {
		// 
		this.parent = null; 
		this.value = text; 
	}

	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("[").append((countChild()>0) ? "+" : "-").append("]");   
		builder.append("value:").append(value); 
		builder.append(", parent:").append((parent==null)?"none":parent.getValue());
		builder.append(", childCount:").append(countChild());
		
		return builder.toString(); 
	}
	
	@Override
	public String getValue() {
		return value; 
	}
	
	@Override
	public String getParentPath() {
		// 
		if(isRoot()) {
			return value; 
		}
		
		StringBuilder builder = new StringBuilder();
		builder.append(getParent().getParentPath()); 
		builder.append(" ").append(getValue()); 
		
		return builder.toString(); 
	}
	
	@Override
	public Collection<TreeNode> getChildren() {
		// 
		return children.values();
	}

	@Override
	public boolean isLeaf() {
		// 
		if (children == null || children.size() == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public TreeNode getParent() {
		//
		return parent;
	}

	@Override
	public void setParent(TreeNode parent) {
		this.parent = parent; 
	}
	
	@Override
	public boolean isRoot() {
		// 
		if(parent == null) {
			return true; 
		}
		
		return false;
	}

	@Override
	public void addChild(TreeNode child) {
		//
		if(children == null) {
			children = new LinkedHashMap<>(); 
		}
		
		child.setParent(this); 
		children.put(child.getValue(), child); 
	}

	@Override
	public void addChild(String text) {
		//
		addChild(new MyAddressNode(text)); 
	}

	@Override
	public int countChild() {
		//
		if(isLeaf()) {
			return 0; 
		} 
		
		return children.size();
	}

	@Override
	public TreeNode getChildByValue(String text) {
		// 
		return children.get(text);
	}

}










