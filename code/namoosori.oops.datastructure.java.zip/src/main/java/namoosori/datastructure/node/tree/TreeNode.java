/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.tree;

import java.util.Collection;

public interface TreeNode {
	//
	boolean isLeaf(); 
	boolean isRoot(); 
	void addChild(TreeNode child); 
	void addChild(String value); 
	TreeNode getChildByValue(String value); 
	Collection<TreeNode> getChildren(); 
	TreeNode getParent(); 
	int countChild(); 
	String getValue();
	String getParentPath(); 
	void setParent(TreeNode myTreeNode);   
}