/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.link;

import namoosori.datastructure.node.single.Node;

public class LinkedChildNode extends Node {
	//
	private LinkedChildNode next;  
	
	public LinkedChildNode(String value) {
		super(value);
	}
	
	public LinkedChildNode getNext() {
		return next; 
	}
	
	public void setNext(LinkedChildNode node) {
		this.next = node; 
	}
}