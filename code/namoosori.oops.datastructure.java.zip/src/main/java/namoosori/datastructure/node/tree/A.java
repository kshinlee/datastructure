package namoosori.datastructure.node.tree;

public class A {

}
