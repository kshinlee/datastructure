/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.stack.story;

import namoosori.datastructure.stack.link.MyLinkedStack;

public class MyLinkedStackStory {
	// 
	public static void main(String[] args) {
		// 
		MyLinkedStack<Integer> stack = new MyLinkedStack<>(); 
		for(int i=0; i<100; i++) {
			stack.push(i); 
			System.out.println("Pushed --> " + stack.peek()); 
		}
		
		for(int i=0; i<100; i++) {
			System.out.println("poped --> " + stack.peek()); 
			stack.pop(); 
		}
		
		System.out.println(stack.empty()); 
	}
}