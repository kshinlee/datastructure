/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.stack.link;

import java.util.EmptyStackException;

import namoosori.datastructure.stack.facade.MyStack;

public class MyLinkedStack<E> implements MyStack<E> {
	// 
	private Node top; 
	private int size; 
	
	public MyLinkedStack() {
		// 
		this.size = 0; 
	}
	
	@Override
	public boolean empty() {
		// 
		if (size == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public E push(E element) {
		//
		Node newNode = new Node(element); 
		newNode.setNext(top);
		top = newNode; 
		size++; 
		
		return top.getElement(); 
	}	

	@Override
	public E pop() {
		// 
		if(empty()) {
			throw new EmptyStackException(); 
		}
		
		// 
		Node firstNode = top; 
		top = firstNode.getNext(); 
		size--;
		
		return firstNode.getElement(); 
	}

	@Override
	public E peek() {
		// 
		return top.getElement();
	}

	@Override
	public int search(E element) {
		// 
		int position = -1; 
		int targetIndex = 0; 
		Node node = top; 

		while(node != null) {
			if (node.getElement().equals(element)) {
				position = targetIndex + 1; 
				break; 
			}
			node = node.getNext(); 
			targetIndex++; 
		}
		
		return position;
	}

	
	private class Node {
		// 
		E element; 
		Node next; 
		
		public Node(E element) {
			// 
			this.element = element;
			this.next = null; 
		}
		
		public String toString() {
			// 
			StringBuilder builder = new StringBuilder(); 

			builder.append("element:").append(element); 
			builder.append(", nextElement:").append((getNext() == null)? "null": getNext().getElement()); 
			
			return builder.toString(); 
		}

		public E getElement() {
			return element;
		}

		public Node getNext() {
			return next;
		}

		public void setNext(Node next) {
			this.next = next;
		}
	}
}