/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.hash.story;

import java.util.Random;
import java.util.Set;

import namoosori.datastructure.hash.linknode.MyStringHashMap;

public class MyHashStory {
	//
	public static void main(String[] args) {
		//
		System.out.println("Hello".hashCode());
		// showHashMapDemo(); 
	}
	
	private static void showHashMapDemo() {
		// 
		MyStringHashMap hashMap = new MyStringHashMap();
		Random random = new Random(); 
		for(int month=1; month<=500; month++) {
			int randomValue = random.nextInt(500); 
			hashMap.put(String.valueOf(randomValue), (randomValue + "월")); 
		}
		
		hashMap.remove("6");
		
		Set<String> keys = hashMap.keySet(); 
		for(String key : keys) {
			System.out.print(" " + hashMap.get(key));  
		}
		
		System.out.println("\n size --> " + hashMap.size()); 
	}
}