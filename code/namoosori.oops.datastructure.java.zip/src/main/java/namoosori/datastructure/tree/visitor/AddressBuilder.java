/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.visitor;

import namoosori.datastructure.tree.node.TreeNode;

public class AddressBuilder {
	//
	
	public static String buildFullAddress(TreeNode node) {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append(node.getContents().getText()); 
		if(node.getContents().getZipCode() != null) {
			builder.append(" ").append(node.getContents().getZipCode()); 
		}
		node = node.getParent();  
		while(!node.isRoot()) {
			builder.insert(0, node.getContents().getText() + " ");
			node = node.getParent(); 
		}
		
		return builder.toString(); 
	}
}