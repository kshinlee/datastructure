/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.node;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class AddressNode implements TreeNode {
	//
	private TreeNode parent; 
	private String name; 
	private NodeContents contents;  
	private Map<String,TreeNode> children; 
	
	public AddressNode(NodeContents contents) {
		//
		this.name = contents.getText(); 
		this.contents = contents; 
	}
	
	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("parent:").append(parent); 
		builder.append(", contents:").append(contents); 
		builder.append(", children:").append(children); 
		
		return builder.toString(); 
	}
	
	@Override
	public String getName() {
		return name; 
	}
	
	@Override
	public NodeContents getContents() {
		return contents; 
	}
	
	@Override
	public List<TreeNode> getLeafNodes() {
		// 
		List<TreeNode> leafNodes = new ArrayList<TreeNode>(); 
		if(hasChild()) {
			for(TreeNode childNode : children.values()) {
				collectLeafNodes(childNode, leafNodes);
			}
		}
		
		return leafNodes; 
	}
	
	private void collectLeafNodes(TreeNode childNode, List<TreeNode> leafNodes) {
		// 
		if (childNode.isLeaf()) {
			leafNodes.add(childNode); 
			return; 
		}
		
		if (childNode.hasChild()) {
			for(TreeNode subChildNode : childNode.getChildren()) {
				collectLeafNodes(subChildNode, leafNodes);
			}
		}
	}
	
	@Override
	public void addChild(TreeNode child) {
		// 
		if(children == null) {
			children = new LinkedHashMap<>(); 
		}
		
		children.put(child.getName(), child); 
		child.setParent(this); 
	}
	
	@Override
	public Collection<TreeNode> getChildren() {
		//
		return children.values();
	}

	@Override
	public boolean hasChild() {
		// 
		if (children != null && children.size() > 0) {
			return true; 
		}
		
		return false; 
	}
	
	@Override
	public TreeNode getChild(String text) {
		// 
		if (children == null) {
			return null; 
		}
		
		return children.get(text); 
	}
	
	public int getChildCount() {
		// 
		if (hasChild()) {
			return children.size(); 
		} else {
			return 0; 
		}
	}
	
	@Override
	public TreeNode getParent() {
		// 
		return parent;
	}

	@Override
	public void setParent(TreeNode parent) {
		// 
		this.parent = parent; 
	}

	@Override
	public boolean isRoot() {
		// 
		if (parent == null) {
			return true;
		}
		
		return false;
	}

	@Override
	public boolean isLeaf() {
		// 
		if(children == null || children.size() == 0) {
			return true; 
		}
		
		return false;
	}
}