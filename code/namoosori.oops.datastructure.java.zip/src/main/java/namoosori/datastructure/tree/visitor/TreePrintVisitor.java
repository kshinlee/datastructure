/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.visitor;

import namoosori.datastructure.tree.node.TreeNode;

public class TreePrintVisitor {
	//
	private int tabCount; 
	
	private TreePrintVisitor() {
		// 
		this.tabCount = 0; 
	}
	
	public static TreePrintVisitor newInstance() {
		// 
		return new TreePrintVisitor(); 
	}
	
	public void printCityNode(TreeNode nationNode) {
		// 
		nationNode.getContents().showText(tabCount);
		if (!nationNode.hasChild()) {
			return; 
		}
		tabCount++; 
		for(TreeNode child : nationNode.getChildren()) {
			printChildNode(child); 	
		}
		tabCount--;
	}
	
	private void printChildNode(TreeNode child) {
		// 
		child.getContents().showText(tabCount); 
		if (!child.hasChild()) {
			return; 
		}

		tabCount++; 
		for(TreeNode subChild : child.getChildren()) {
			printChildNode(subChild);
		}
		tabCount--; 
	}
}