/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.visitor;

import java.util.LinkedHashMap;
import java.util.Map;

import namoosori.datastructure.tree.domain.District;
import namoosori.datastructure.tree.node.TreeNode;

public class DongNodeCollector {
	//
	private Map<String,TreeNode> dongNodeMap; 
	
	private DongNodeCollector() {
		// 
	}
	
	public static DongNodeCollector newInstance() {
		return new DongNodeCollector(); 
	}
	
	public Map<String,TreeNode> collectDongNode(TreeNode nationNode) {
		// 
		dongNodeMap = new LinkedHashMap<String,TreeNode>();  
		
		collectDong(nationNode); 
		
		return dongNodeMap; 
	}
	
	private void collectDong(TreeNode node) {
		//
		if (node.getContents().getDistrict().equals(District.Dong)) {
			dongNodeMap.put(node.getName(), node); 
			return; 
		}
		
		if (!node.hasChild()) {
			return; 
		}
		
		for(TreeNode subNode : node.getChildren()) {
			collectDong(subNode); 
		}
	}
}