/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.story;

import java.util.List;
import java.util.Map;

import io.namoo.util.expow.api.ExpowFileReader;
import io.namoo.util.expow.api.ExpowSheet;
import namoosori.datastructure.tree.domain.District;
import namoosori.datastructure.tree.domain.ZipAddress;
import namoosori.datastructure.tree.node.AddressNode;
import namoosori.datastructure.tree.node.NodeContents;
import namoosori.datastructure.tree.node.TreeNode;
import namoosori.datastructure.tree.visitor.AddressBuilder;
import namoosori.datastructure.tree.visitor.DongNodeCollector;
import namoosori.datastructure.tree.visitor.TreeBuildVisitor;
import namoosori.datastructure.tree.visitor.TreePrintVisitor;
import namoosori.datastructure.tree.visitor.ZipNodeCollector;

public class AddressStory {
	//
	private AddressNode nationNode; 
	private String fileName = "./src/main/resources/20150710_Seoul(Unicode_half).xlsx";
	
	public static void main(String[] args) {
		// 
		AddressStory story = new AddressStory(); 
		story.buildAddressTree();
		story.showAddressTree(); 
		// story.showAddressWithZipCode();
		// story.showAddressWithDong();
	}
	
	public void buildAddressTree() {
		// 
		System.out.println("엑셀파일을 읽어들입니다..."); 
		ExpowSheet sheet = ExpowFileReader.read(fileName).requestSheet(0);  
		nationNode = new AddressNode(new NodeContents(District.Nation, "대한민국")); 
		TreeBuildVisitor nodeVisitor = new TreeBuildVisitor(); 
		
		System.out.println("주소 트리를 빌딩합니다..."); 
		int rowCount = sheet.countRow(); 
		for(int i=1; i<rowCount; i++) {
			ZipAddress address = new ZipAddress(sheet.requestRow(i)); 
			nodeVisitor.visitCityNode(nationNode, address);
		}
	}

	public void showAddressTree() {
		// 
		TreePrintVisitor.newInstance().printCityNode(nationNode); 
	}

	public void showAddressWithZipCode() {
		// 
		System.out.println("\n우편번호로 찾습니다....(134842).. \n"); 

		Map<String,List<TreeNode>> zipcodeMap = ZipNodeCollector.newInstance().collectZipNode(nationNode); 
		
		List<TreeNode> zipNodes = zipcodeMap.get("134842"); 
		if (zipNodes != null) {
			for(TreeNode zipNode : zipNodes) {
				System.out.println(AddressBuilder.buildFullAddress(zipNode));
			}
		}
		
		System.out.println("\n우편번호로 찾습니다....(152888).. \n"); 

		zipNodes = zipcodeMap.get("152888"); 
		if(zipNodes != null) {
			for(TreeNode zipNode : zipNodes) {
				System.out.println(AddressBuilder.buildFullAddress(zipNode));
			}
		}
	}
	
	public void showAddressWithDong() {
		//
		System.out.println("\n동으로 찾습니다....(우이동).. \n"); 

		Map<String,TreeNode> dongNodeMap = DongNodeCollector.newInstance().collectDongNode(nationNode); 
		TreeNode dongNode = dongNodeMap.get("우이동"); 
		if (dongNode != null) {
			for(TreeNode leafNode : dongNode.getLeafNodes()) { 
				System.out.println(AddressBuilder.buildFullAddress(leafNode));
			}
		}
	}
}








