/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.domain;

import java.util.ListIterator;

import io.namoo.util.expow.api.ExpowCell;
import io.namoo.util.expow.api.ExpowRow;

public class ZipAddress {
	//
	private String zipCode; 
	private String city; 
	private String gungu; 
	private String roadName; 
	private String buildingName; 
	private String dong; 
	
	public ZipAddress(ExpowRow row) {
		//
		ListIterator<ExpowCell> iterator = row.requestCellsIterator(); 
		this.zipCode = iterator.next().getValue(); 
		this.city = iterator.next().getValue(); 
		this.gungu = iterator.next().getValue(); 
		this.roadName = iterator.next().getValue(); 
		this.buildingName = iterator.next().getValue(); 
		this.dong = iterator.next().getValue(); 
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getGungu() {
		return gungu;
	}

	public void setGungu(String gungu) {
		this.gungu = gungu;
	}

	public String getRoadName() {
		return roadName;
	}

	public void setRoadName(String roadName) {
		this.roadName = roadName;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getDong() {
		return dong;
	}

	public void setDong(String dong) {
		this.dong = dong;
	}
}
