/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.util;

import java.util.Iterator;
import java.util.ListIterator;

import io.namoo.util.expow.api.ExpowCell;
import io.namoo.util.expow.api.ExpowColumn;
import io.namoo.util.expow.api.ExpowFile;
import io.namoo.util.expow.api.ExpowFileReader;
import io.namoo.util.expow.api.ExpowRow;
import io.namoo.util.expow.api.ExpowSheet;

public class ExcelAddressReader {
	//
	public static ExcelAddressReader newInstance() {
		// 
		return new ExcelAddressReader(); 
	}
	
	public ExpowSheet readFile() { 
		//
		String fileName = "./src/main/resources/20150710_Seoul(Unicode_half).xlsx";
		ExpowFile file = ExpowFileReader.read(fileName); 
		return file.requestSheet(0); 
		// readColumnTest(powSheet); 
		// readRowTest(powSheet); 
	}
	
	public static void readColumnTest(ExpowSheet powSheet) {
		//
		ExpowColumn skillColumn = powSheet.requestColumnKeyColumn("우편번호");
		Iterator<ExpowCell> cellIter = skillColumn.requestCellsFrom("우편번호"); 
		while(cellIter.hasNext()) {
			ExpowCell cell = cellIter.next(); 
			if (!cell.isEmpty()) {
				ExpowRow skillRow = powSheet.requestRowKeyRow(cell.getValue()); 
				ExpowCell rowCell = skillRow.requestCell(cell.getColumnIndex()+2); 
				System.out.println(rowCell.toPrettyJson());  
			}
		}
	}
	
	public static void readRowTest(ExpowSheet powSheet) {
		//
		int rowCount = powSheet.countRow(); 
		for(int i=1;i<rowCount; i++) {
			ExpowRow row = powSheet.requestRow(i); 
			ListIterator<ExpowCell> iterator = row.requestCellsIterator(); 
			System.out.format("[%06d] ", i); 
			while(iterator.hasNext()) {
				ExpowCell cell = iterator.next(); 
				System.out.print(cell.getValue() + ", ");
			}
			
			System.out.println(""); 
		}
	}
}