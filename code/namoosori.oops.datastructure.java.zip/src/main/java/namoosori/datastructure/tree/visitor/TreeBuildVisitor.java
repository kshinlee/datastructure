/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.visitor;

import namoosori.datastructure.tree.domain.District;
import namoosori.datastructure.tree.domain.ZipAddress;
import namoosori.datastructure.tree.node.AddressNode;
import namoosori.datastructure.tree.node.NodeContents;
import namoosori.datastructure.tree.node.TreeNode;

public class TreeBuildVisitor {
	//
	private boolean silent; 
	
	public TreeBuildVisitor() {
		// 
		this.silent = true; 
	}
	
	private void showMessage(String message) {
		// 
//		try {
//			Thread.sleep(200);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} 
		
		if(!silent) {
			System.out.println(message); 
		}
	}
	
	public void visitCityNode(TreeNode nationNode, ZipAddress address) {
		// 
		String city = address.getCity(); 
		TreeNode cityNode = nationNode.getChild(city); 
		if (cityNode == null) {
			cityNode = new AddressNode(new NodeContents(District.City, city)); 
			nationNode.addChild(cityNode);
			showMessage("City created: " + city); 
		}
 		
		visitGunguNode(cityNode, address);
	}
	
	public void visitGunguNode(TreeNode cityNode, ZipAddress address) {
		// 
		String gungu = address.getGungu(); 
		TreeNode gunguNode = cityNode.getChild(gungu); 
		if(gunguNode == null) {
			//
			gunguNode = new AddressNode(new NodeContents(District.Gungu, gungu)); 
			cityNode.addChild(gunguNode);
			showMessage("Gungu created: " + gungu); 
		}
		
		visitDongNode(gunguNode, address);
	}
	
	public void visitDongNode(TreeNode gunguNode, ZipAddress address) {
		// 
		String dong = address.getDong(); 
		TreeNode dongNode = gunguNode.getChild(dong); 
		
		if(gunguNode.getChildCount() > 10) {
			return; 
		}
		
		if (dongNode == null) {
			dongNode = new AddressNode(new NodeContents(District.Dong, dong)); 
			gunguNode.addChild(dongNode);
			showMessage("Dong created: " + dong); 
		}
		
		visitRoadNameNode(dongNode, address); 
	}
	
	public void visitRoadNameNode(TreeNode dongNode, ZipAddress address) {
		// 
		String roadName = address.getRoadName(); 
		TreeNode roadNameNode = dongNode.getChild(roadName); 
		
		if (dongNode.getChildCount() > 10) {
			return; 
		}
		
		if(roadNameNode == null) {
			roadNameNode = new AddressNode(new NodeContents(District.RoadName, roadName)); 
			dongNode.addChild(roadNameNode);
			showMessage("RoadName created: " + roadName); 
		}
		
		if (address.getBuildingName() != null) {
			visitBuildingNameNode(roadNameNode, address); 
		}
	}
	
	public void visitBuildingNameNode(TreeNode roadNameNode, ZipAddress address) {
		// 
		String buildingName = address.getBuildingName(); 
		
		if (buildingName == null || buildingName.equals("")) {
			roadNameNode.getContents().setZipCode(address.getZipCode());
			return; 
		}
		
		TreeNode buildingNameNode = roadNameNode.getChild(buildingName); 
		
		if (roadNameNode.getChildCount() > 6) {
			return; 
		}

		if(buildingNameNode == null) {
			buildingNameNode = new AddressNode(new NodeContents(District.BuildingName, buildingName)); 
			buildingNameNode.getContents().setZipCode(address.getZipCode()); 
			roadNameNode.addChild(buildingNameNode); 
			showMessage("BuildingName created: " + buildingName); 
		}
	}
}