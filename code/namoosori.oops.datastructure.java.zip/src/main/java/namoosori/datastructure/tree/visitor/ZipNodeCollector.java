/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.visitor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import namoosori.datastructure.tree.node.TreeNode;

public class ZipNodeCollector {
	//
	private Map<String,List<TreeNode>> zipcodeMap; 
	
	private ZipNodeCollector() {
		// 
	}
	
	public static ZipNodeCollector newInstance() {
		return new ZipNodeCollector(); 
	}
	
	public Map<String,List<TreeNode>> collectZipNode(TreeNode nationNode) {
		// 
		zipcodeMap = new LinkedHashMap<String,List<TreeNode>>();  
		
		collectZipCode(nationNode); 
		
		return zipcodeMap; 
	}
	
	private void collectZipCode(TreeNode node) {
		//
		if (node.getContents().getZipCode() != null) {
			List<TreeNode> nodes = zipcodeMap.get(node.getContents().getZipCode()); 
			if (nodes == null) {
				nodes = new ArrayList<TreeNode>(); 
				zipcodeMap.put(node.getContents().getZipCode(), nodes); 
			}
			nodes.add(node); 
		}
		
		if (!node.hasChild()) {
			return; 
		}
		
		for(TreeNode subNode : node.getChildren()) {
			collectZipCode(subNode); 
		}
	}
}