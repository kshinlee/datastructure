/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.queue.story;

import namoosori.datastructure.queue.facade.MyQueue;
import namoosori.datastructure.queue.link.MyLinkedQueue;
import namoosori.datastructure.queue.link.MyStringLinkedQueue;

public class MyQueueStory {
	//
	public static void main(String[] args) {
		//
		MyQueueStory myStory = new MyQueueStory(); 
		myStory.tellMeAboutArrayQueue(); 
		myStory.tellMeAboutLinkedQueue(); 
	}
	
	public void tellMeAboutArrayQueue() {
		// 
		MyQueue<String> myQueue = new MyLinkedQueue<String>(); 

		myQueue.offer("1월"); 
		myQueue.offer("2월"); 
		myQueue.offer("3월"); 
		myQueue.offer("4월"); 
		myQueue.offer("5월"); 
		myQueue.offer("6월"); 
		myQueue.offer("7월"); 
		myQueue.offer("8월"); 
		myQueue.offer("9월"); 
		myQueue.offer("10월"); 
		myQueue.offer("11월"); 
		myQueue.offer("12월"); 
		myQueue.offer("13월"); 
		
		int size = myQueue.size(); 
		for(int i=0; i<size; i++) {
			System.out.println(myQueue.poll());
		}
	}
	
	public void tellMeAboutLinkedQueue() {
		//
		MyStringLinkedQueue myQueue = new MyStringLinkedQueue(); 
		myQueue.offer("1월"); 
		myQueue.offer("2월"); 
		myQueue.offer("3월"); 
		myQueue.offer("4월"); 
		
		int size = myQueue.size(); 
		for(int i=0; i<size; i++) {
			System.out.println(myQueue.poll());
		}
	}
}
