/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.queue.array;

import namoosori.datastructure.queue.facade.MyQueue;

public class MyArrayQueue<E> implements MyQueue<E> {
	//
	private static final int INITIAL_CAPACITY = 10; 
	
	private int length; 
	private int offerIndex; 
	private int pollIndex; 
	private int capacity; 
	private E[] elements; 
	
	public MyArrayQueue() {
		// 
		this(INITIAL_CAPACITY); 
	}
	
	@SuppressWarnings("unchecked")
	public MyArrayQueue(int capacity) {
		// 
		this.length = 0; 
		this.pollIndex = 0; 
		this.offerIndex = 0; 
		this.capacity = capacity; 
		this.elements = (E[])new Object[capacity];
	}
	
	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append(", length:").append(length); 
		builder.append(", pollIndex:").append(pollIndex); 
		builder.append(", offerIndex:").append(offerIndex); 
		builder.append(", capacity:").append(capacity); 
		builder.append(", elements:").append(elements); 
		
		return builder.toString(); 
	}
	
	public int remainingCapacity() {
		// 
		return capacity - length; 
	}
	
	@Override
	public int size() {
		// 
		return length;
	}

	@Override
	public boolean empty() {
		//
		if (length == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public boolean offer(E element) {
		// 
		if(length == capacity) {
			System.out.println("No room for: " + element);  
			return false; 
		}
		
		elements[offerIndex++] = element;
		length++; 
		
		if(offerIndex == capacity) {
			offerIndex = 0; 
		}
		
		return true;
	}

	@Override
	public E peek() {
		// 
		return elements[pollIndex]; 
	}

	@Override
	public E poll() {
		// 
		if (length == 0) {
			return null; 
		}
		
		E polledElement = elements[pollIndex]; 
		elements[pollIndex] = null; 
		pollIndex++; 
		length--; 
		
		if(pollIndex == capacity) {
			pollIndex = 0; 
		}
		
		return polledElement; 
	}
}