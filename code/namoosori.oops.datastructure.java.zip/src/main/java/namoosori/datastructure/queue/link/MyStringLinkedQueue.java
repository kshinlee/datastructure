/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.queue.link;

import namoosori.datastructure.queue.facade.MyStringQueue;

public class MyStringLinkedQueue implements MyStringQueue {
	//
	private int size; 
	private Node head; 
	private Node tail; 
	
	public MyStringLinkedQueue() {
		// 
		this.size = 0; 
		this.head = null; 
		this.tail = null; 
	}

	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("head:").append(head); 
		builder.append(", size:").append(size); 
		builder.append(", tail:").append(tail); 
		
		return builder.toString(); 
	}

	@Override
	public boolean offer(String element) {
		// 
		Node newNode = new Node(element); 
		if(size == 0) {
			newNode.setNext(head);
			head = newNode; 
			if (head.isTail()) {
				tail = head; 
			} 
		} else {
			tail.setNext(newNode);
			tail = newNode; 
		}
		size++; 
		
		return true; 
	}
	
	@Override
	public int size() {
		// 
		return size;
	}

	@Override
	public boolean empty() {
		// 
		if(size == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public String peek() {
		// 
		return head.getElement(); 
	}

	@Override
	public String poll() {
		// 
		Node removeNode = head; 
		if (head.isTail()) {
			tail = null; 
		}
		
		head = removeNode.getNext();
		size--; 
		
		return removeNode.getElement(); 
	}

	private class Node {
		// 
		String element; 
		Node next; 
		
		public Node(String element) {
			// 
			this.element = element;
			this.next = null; 
		}
		
		public String toString() {
			// 
			StringBuilder builder = new StringBuilder(); 

			builder.append("element:").append(element); 
			builder.append(", nextElement:").append((getNext() == null)? "null": getNext().getElement()); 
			
			return builder.toString(); 
		}

		public boolean isTail() {
			// 
			if (next == null) {
				return true; 
			}
			
			return false; 
		}
		
		public String getElement() {
			return element;
		}

		public Node getNext() {
			return next;
		}

		public void setNext(Node next) {
			this.next = next;
		}
	}
}
