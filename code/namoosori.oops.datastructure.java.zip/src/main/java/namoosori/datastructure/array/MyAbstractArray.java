/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.array;

public class MyAbstractArray<E> {
	// 
	private static final int INITIAL_CAPACITY = 10; 
	
	private E[] elements;
	private int length; 
	private int capacity; 
	private IncreasePolicy policy; 
	
	protected MyAbstractArray() {
		// 
		this(INITIAL_CAPACITY); 
	}
	
	protected MyAbstractArray(int capacity) {
		// 
		this.length = 0; 
		this.capacity = capacity; 
		this.initialize(capacity);
		this.policy = IncreasePolicy.DoubleTimes; 
	}
	
	public E get(int index) {
		// 
		validateIndex(index);
		return elements[index]; 
	}
	
	public int length() {
		return length; 
	}
	
	public boolean empty() {
		return length == 0; 
	}
	
	protected void setPolicy(IncreasePolicy policy) {
		this.policy = policy; 
	}
	
	protected IncreasePolicy getPolicy() {
		return policy; 
	}
	
	public void addFirst(E element) {
		// 
		addAt(0, element); 
		
		// or 
		// validateCapacity(); 
		// shiftRightFrom(0); 
		// elements[0] = element; 
		// length++; 

	}
	
	public void removeFirst() {
		// 
		removeAt(0); 
		
		// or 
		// if (isEmpty()) {
		//	return; 
		// }
		// elements[0] = null; 
		// shiftLeftTo(0); 
		// length--; 
	}
	
	public void addLast(E element) {
		//
		addAt(length, element); 
		
		// or 
		// validateCapacity(); 
		// elements[length] = element; 
		// length++; 
	}

	public void removeLast() {
		// 
		removeAt(length); 
		
		// or 
		// if (isEmpty()) {
		//	return; 
		// }
		
		// elements[length-1] = null; 
		// length--; 
	}

	public void addAt(int index, E element) {
		// 
		arrangeCapacity(); 
		if (length != index) {
			validateIndex(index); 
		}
		
		shiftRightFrom(index);
		elements[index] = element; 
		length++; 
	}
	
	public void removeAt(int index) {
		// 
		if(empty()) {
			return; 
		}
		
		validateIndex(index); 
		
		elements[index] = null; 
		shiftLeftTo(index);
		length--; 
	}
	
	public void addAll(MyAbstractArray<E> source) {
		// 
		int targetCapacity = length + source.length(); 
		if (targetCapacity > capacity) {
			increaseCapacity(targetCapacity);  
		}

		int sourceLength = source.length(); 
		System.arraycopy(source, 0, elements, length, sourceLength); 
		
		// or 
		// for(int i=0; i<sourceLength; i++) {
		// 	elements[length++] = source.get(i);  
		// }	
	}
	
	protected void shiftRightFrom(int index) {
		//
		for(int i=length; i>index; i--) {
			elements[i] = elements[i-1]; 
		}
	}
	
	protected void shiftLeftTo(int index) {
		// 
		for(int i=index; i<length; i++) {
			elements[i] = elements[i+1]; 
		}
	}
	
	protected void validateIndex(int index) {
		// 
		if (index < 0 || index >= length) {
			throw new ArrayIndexOutOfBoundsException("index: "+index); 
		}
	}
	
	protected void arrangeCapacity() {
		// 
		if(length == capacity) {
			increaseCapacity(); 
		}
	}
	
	private void increaseCapacity() {
		// 
		switch(policy) {
		case PlusOne: 
			capacity += 1; 
			break; 
		
		case PlusInitial:
			capacity += INITIAL_CAPACITY; 
			break; 
			
		case DoubleTimes: 
			capacity *= 2; 
		}
		
		increaseCapacity(capacity); 
	}
	
	private void increaseCapacity(int newCapacity) {
		// 
		@SuppressWarnings("unchecked")
		E[] newElements = (E[])new Object[capacity];

		System.arraycopy(elements, 0, newElements, 0, length); 
		elements = newElements; 
	}
	
	@SuppressWarnings("unchecked")
	private void initialize(int capacity) {
		// 
		this.elements = (E[])new Object[capacity];
	}

	enum IncreasePolicy {
		PlusOne,
		PlusInitial,
		DoubleTimes 
	}
}