/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.doublelink;

public class DoubleLinkedNode {
	//
	private String value; 
	private DoubleLinkedNode previous; 
	private DoubleLinkedNode next; 
	
	public DoubleLinkedNode(String value) {
		// 
		this.value = value; 
		this.previous = null; 
		this.next = null; 
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public DoubleLinkedNode getNext() {
		return next;
	}

	public DoubleLinkedNode setNext(DoubleLinkedNode next) {
		// 
		this.next = next;
		next.setPrevious(this); 
		return next; 
	}
	
	public DoubleLinkedNode getPrevious() {
		return previous;
	}

	public void setPrevious(DoubleLinkedNode previous) {
		this.previous = previous;
	}
	
	public void show() {
		System.out.println("value:" + value); 
	}
}