/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.tree.node;

import java.util.Collection;
import java.util.List;

public interface TreeNode {
	//
	String getName(); 
	NodeContents getContents(); 
	TreeNode getParent(); 
	void setParent(TreeNode parent); 
	void addChild(TreeNode child); 
	Collection<TreeNode> getChildren(); 
	boolean hasChild(); 
	TreeNode getChild(String text); 
	int getChildCount(); 
	boolean isRoot(); 
	boolean isLeaf(); 
	List<TreeNode> getLeafNodes(); 

	//
//	String getText(); 
//	String getZipCode(); 
//	void setZipCode(String zipCode); 
//	District getTitle(); 
//	String getFullAddress(); 
}