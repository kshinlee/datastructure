/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.stack.link;

import java.util.EmptyStackException;

import namoosori.datastructure.stack.facade.MyStringStack;

public class MyStringLinkedStack implements MyStringStack {
	// 
	private Node top; 
	private int size; 
	
	public MyStringLinkedStack() {
		// 
		this.size = 0; 
		this.top = null; 
	}
	
	@Override
	public boolean empty() {
		// 
		if (size == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public int size() {
		return size; 
	}
	
	@Override
	public String push(String e) {
		//
		Node newNode = new Node(e); 
		newNode.setNext(top);
		top = newNode;
		size++; 
		
		return top.getElement(); 
	}	

	@Override
	public String pop() {
		// 
		if(empty()) {
			throw new EmptyStackException(); 
		}
		
		// 
		Node firstNode = top; 
		top = firstNode.getNext(); 
		size--; 
		
		return firstNode.getElement(); 
	}

	@Override
	public String peek() {
		// 
		if(empty()) {
			throw new EmptyStackException(); 
		}

		return top.getElement();
	}

	@Override
	public int search(String element) {
		// 
		int position = -1; 
		if (empty()) {
			return position; 
		}
		
		Node node = top; 
		for(int i=0; i<size; i++) {
			if (node.getElement().equals(element)) {
				position = i+1; 
				break; 
			}
			node = node.getNext(); 
		}
		
		return position;
	}
	
	private class Node {
		// 
		String element; 
		Node next; 
		
		public Node(String element) {
			// 
			this.element = element;
			this.next = null; 
		}

		public String getElement() {
			return element;
		}

		public Node getNext() {
			return next;
		}

		public void setNext(Node next) {
			this.next = next;
		}
	}
}