/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.hash.linknode;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import namoosori.datastructure.hash.facade.MyStringHash;

public class MyStringHashMap implements MyStringHash {
	//
	private static final int INITIAL_CAPACITY = 16; 
	private static final double LOAD_FACTOR = 0.75; 

	private int length; 
	private int capacity; 
	private HashNode[] hashTable; 
	
	public MyStringHashMap() {
		// 
		this.clear(); 
	}
	
	private int hash(String value, int hashCapacity) {
		// 
		int hashCode = value.hashCode(); 
		if (hashCode == 0) {
			return 0; 
		}
		
		return hashCode % hashCapacity; 
	}
	
	
	@Override
	public int size() {
		// 
		return length;
	}

	@Override
	public boolean empty() {
		// 
		return length == 0;
	}

	@Override
	public boolean contains(String key) {
		// 
		int index = hash(key, capacity); 
		if (hashTable[index].empty()) {
			return true; 
		}
		
		return false;
	}

	@Override
	public void put(String key, Object value) {
		//
		if(length == capacity) {
			rehash(); 
		}

		int index = hash(key, capacity); 
		hashTable[index].add(key, value); 
		length++; 
	}

	@Override
	public Object get(String key) {
		//  
		int index = hash(key, capacity); 
		return hashTable[index].get(key); 
	}

	@Override
	public void remove(String key) {
		// 
		int index = hash(key, capacity); 
		if(hashTable[index].remove(key)) {
			length--; 
		}
	}
 
	@Override
	public Set<String> keySet() {
		// 
		Set<String> keys = new HashSet<>();
		for(int i=0; i<capacity; i++) {
			if(!hashTable[i].empty()) {
				keys.addAll(hashTable[i].keys()); 
			}
		}
		
		return keys;
	}

	@Override
	public Collection<Object> values() {
		// 
		List<Object> values = new ArrayList<>();
		for(int i=0; i<capacity; i++) {
			if(!hashTable[i].empty()) {
				values.addAll(hashTable[i].values()); 
			}
		}
		
		return values;
	}

	@Override
	public void clear() {
		// 
		this.length = 0; 
		this.capacity = (int)(INITIAL_CAPACITY/LOAD_FACTOR); 
		this.hashTable = new HashNode[capacity]; 
		this.initialize(this.hashTable); 
	}
	
	private void initialize(HashNode[] table) {
		// 
		for(int i=0; i<table.length; i++) {
			table[i] = new HashNode(); 
		}
	}

	private void rehash() {
		// 
		System.out.println("rehashed..."); 
		
		int newCapacity = capacity + INITIAL_CAPACITY; 
		HashNode[] newTable = new HashNode[newCapacity]; 
		initialize(newTable); 
		Set<String> keys = keySet(); 
		for(String key : keys) {
			Object value = get(key); 
			int index = hash(key, newCapacity); 
			newTable[index].add(key, value);
		}
		this.capacity = newCapacity; 
		this.hashTable = newTable; 
	}
}