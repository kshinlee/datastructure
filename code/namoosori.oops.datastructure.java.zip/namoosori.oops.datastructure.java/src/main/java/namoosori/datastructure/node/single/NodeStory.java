/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.single;

import java.util.ArrayList;
import java.util.List;

public class NodeStory {
	// 
	public static void main(String[] args) {
		// 
		showNodeDemo(); 
	}
	
	private static void showNodeDemo() {
		// 
		Node sundayNode = new Node("Sunday"); 
		Node mondayNode = new Node("Monday"); 
		Node tuesdayNode = new Node("Thuesday"); 
		Node wednesdayNode = new Node("Wednesday"); 
		Node thursdayNode = new Node("Thursday"); 
		Node fridayNode = new Node("Friday"); 
		Node saturdayNode = new Node("Satureday"); 
		
		List<Node> nodeList = new ArrayList<>(); 
		nodeList.add(sundayNode); 
		nodeList.add(mondayNode); 
		nodeList.add(tuesdayNode); 
		nodeList.add(wednesdayNode); 
		nodeList.add(thursdayNode); 
		nodeList.add(fridayNode); 
		nodeList.add(saturdayNode);
		
		for(Node node : nodeList) {
			node.show(); 
		}
	}
}