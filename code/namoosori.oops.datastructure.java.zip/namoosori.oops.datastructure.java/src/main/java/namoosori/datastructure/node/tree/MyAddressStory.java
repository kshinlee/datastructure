/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.tree;

public class MyAddressStory {
	//
	private int tabSize; 
	
	public static void main(String[] args) {
		// 
		MyAddressStory story = new MyAddressStory(); 
		story.tellMe(); 
	}
	
	public void tellMe() {
		// 
		TreeNode cityNode = buildTreeNode(); 
		tabSize = 0; 
		printTree(cityNode); 
		findNode(cityNode, "가산동"); 
		findNode(cityNode, "개포동"); 
	}
	
	public void findNode(TreeNode treeNode, String text) {
		// 
		MyNodeFinder finder =  MyNodeFinder.getInstance(); 
		TreeNode resultNode = finder.find(treeNode, text); 
		
		System.out.println(resultNode); 
		System.out.println(resultNode.getParentPath()); 
	}
	
	public void printTree(TreeNode treeNode) {
		// 
		showNode(tabSize++, treeNode); 
		
		if(treeNode.isLeaf()) {
			tabSize--; 
			return; 
		}
		
		for(TreeNode childTreeNode : treeNode.getChildren()) {
			printTree(childTreeNode); 
		}
		tabSize--; 
	}
	
	private void showNode(int tabSize, TreeNode node) {
		//
		for(int i=0; i<tabSize; i++) {
			System.out.print("\t"); 
		}
		System.out.println(node); 
	}
	
	public TreeNode buildTreeNode() {
		//
		MyAddressNode cityNode = new MyAddressNode("서울시"); 
		
		cityNode.addChild(new MyAddressNode("강남구"));
		cityNode.addChild(new MyAddressNode("금천구")); 
		
		TreeNode targetNode = cityNode.getChildByValue("강남구"); 
		targetNode.addChild("개포동"); 
		targetNode.addChild("논현동"); 
		
		targetNode = cityNode.getChildByValue("금천구"); 
		targetNode.addChild("독산동"); 
		targetNode.addChild("가산동"); 
		
		return cityNode; 
	}
}
