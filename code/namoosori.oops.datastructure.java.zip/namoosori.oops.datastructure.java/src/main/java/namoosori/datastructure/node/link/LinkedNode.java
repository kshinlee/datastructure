/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.node.link;

public class LinkedNode {
	//
	private String value; 
	private LinkedNode next; 
	
	public LinkedNode(String value) {
		// 
		this.value = value; 
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public LinkedNode getNext() {
		return next;
	}

	public LinkedNode setNext(LinkedNode next) {
		this.next = next;
		return next; 
	}
	
	public void show() {
		System.out.println("value:" + value); 
	}
}