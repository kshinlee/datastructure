/*
 * COPYRIGHT (c) NEXTREE Consulting 2014
 * This software is the proprietary of NEXTREE Consulting CO.  
 * 
 * @author <a href="mailto:tsong@nextree.co.kr">Song, Taegook</a>
 * @since 2014. 6. 10.
 */
package namoosori.datastructure.stack.array;

import java.util.EmptyStackException;

import namoosori.datastructure.stack.facade.MyStack;

public class MyArrayStack<E> implements MyStack<E> {
	// 
	private static int INITIAL_CAPACITY = 10; 
	
	private int length; 
	private int capacity; 
	private E[] elements; 
	
	@SuppressWarnings("unchecked")
	public MyArrayStack() {
		// 
		this.length = 0; 
		this.capacity = INITIAL_CAPACITY; 
		this.elements = (E[])new Object[capacity]; 
	}
	
	@Override
	public boolean empty() {
		// 
		if (length == 0) {
			return true; 
		}
		
		return false;
	}

	@Override
	public E push(E element) {
		//
		if(length == capacity) {
			increaseCapacity();
		}
		
		elements[length] = element; 
		length++; 
		
		return element; 
	}

	@Override
	public E pop() {
		// 
		if(empty()) {
			throw new EmptyStackException(); 
		}
		
		length--; 
		E element = elements[length]; 
		elements[length] = null; 
		
		return element;
	}

	@Override
	public E peek() {
		// 
		return elements[length-1];
	}

	@Override
	public int search(E element) {
		// 
		int position = -1; 
		for(int i=0; i<length; i++) {
			if (elements[i].equals(element)) {
				position = (length - i);
				break; 
			}
		}

		return position; 
	}
	
	@SuppressWarnings("unchecked")
	private void increaseCapacity() {
		// 
		capacity += INITIAL_CAPACITY; 
		E[] newElements = (E[])new Object[capacity];
		System.arraycopy(elements, 0, newElements, 0, elements.length); 
		elements = newElements; 
		newElements = null; 
	}
}