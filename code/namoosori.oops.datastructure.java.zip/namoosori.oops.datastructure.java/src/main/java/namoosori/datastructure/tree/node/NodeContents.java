package namoosori.datastructure.tree.node;

import namoosori.datastructure.tree.domain.District;

public class NodeContents {
	//
	private String text;
	private String zipCode; 
	private District district; 		// [행정] 구역

	public NodeContents(District title, String text) {
		// 
		this.district = title;
		this.text = text; 
		this.zipCode = null; 
	}
	
	@Override
	public String toString() {
		// 
		StringBuilder builder = new StringBuilder(); 
		
		builder.append("district:").append(district); 
		builder.append(", text:").append(text); 
		builder.append(", zipCode:").append(text); 
		
		return builder.toString(); 
	}

	public void showText(int tabCount) {
		// 
		for(int i=0; i<tabCount; i++) {
			System.out.print("\t");
		}
		
		System.out.print(text);
		if (zipCode != null) {
			System.out.print(" --> " + zipCode); 
		}
		System.out.println("");
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public District getDistrict() {
		return district;
	}

	public void setDistrict(District title) {
		this.district = title;
	}
}