package namoosori.algorithm.hanoitower;

public class Ring {
	// 
	private int number; 
	private int size; 
	
	public Ring (int number, int size) {
		// 
		this.number = number; 
		this.size = size; 
	}

	public void show() {
		//
		System.out.println(" -> number:" + number + ", size:" + size);
	}	
	
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
}
