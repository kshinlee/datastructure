package namoosori.algorithm.hanoitower;

public class SamrtMover {
	// 
	private Pannel pannel; 
	private int moveCount; 
	private int tabCount; 
	
	public SamrtMover() {
		// 
		this.pannel = new Pannel(); 
		this.moveCount = 0; 
		this.tabCount = 0; 
	}
	
	public void showPannel() {
		// 
		this.pannel.showRingsInPole();
	}
	
	public void move() {
		// 
		Pole sourcePole = pannel.getLeftPole(); 
		Pole tempPole = pannel.getMiddlePole(); 
		Pole targetPole = pannel.getRightPole(); 
		int diskCount = pannel.getRingCount();
		
		this.moveRings(sourcePole, targetPole, diskCount, tempPole); 
	}
	
	private void moveRings(Pole sourcePole, Pole targetPole, int diskCount, Pole tempPole) {
		//
		if (diskCount == 0) {
			return; 
		}
		tabCount++;
		moveRings(sourcePole, tempPole, diskCount-1, targetPole); 
		moveRingToFinal(sourcePole, targetPole); 
		moveRings(tempPole, targetPole, diskCount-1, sourcePole); 
		tabCount--; 
	}
	
	public void moveRingToFinal(Pole sourcePole, Pole targetPole) {
		// 
		for(int i=1; i<tabCount; i++) {
			System.out.print("\t"); 
		}

		Ring ring = pannel.moveRingToFinal(sourcePole, targetPole); 
		
		String message = 
				String.format("| %03d, from:%s, \tto:%s, \tring:%d", 
						moveCount++, sourcePole.getName(), targetPole.getName(), ring.getNumber()); 
		System.out.println(message);
	}
}