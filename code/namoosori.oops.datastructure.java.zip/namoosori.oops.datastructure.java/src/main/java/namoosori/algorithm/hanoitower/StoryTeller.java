package namoosori.algorithm.hanoitower;

public class StoryTeller {

	public static void main(String[] args) {
		// 
		StoryTeller teller = new StoryTeller(); 
		teller.talk(); 
		
	}
	
	public void talk() {
		// 
		SamrtMover mover = new SamrtMover(); 
		mover.showPannel();
		mover.move(); 
		mover.showPannel();
	}
}