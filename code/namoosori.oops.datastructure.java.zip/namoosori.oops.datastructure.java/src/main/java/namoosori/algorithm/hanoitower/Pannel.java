package namoosori.algorithm.hanoitower;

public class Pannel {
	//
	private Pole[] poles;
	
	public Pannel() {
		// 
		this.poles = new Pole[] {new Pole(0,"left"), new Pole(1, "middle"), new Pole(2, "right")}; 
		for (int i=Pole.MaxRingCount; i>0; i--) {
			this.poles[0].push(new Ring(i,i)); 
		}
	}

	public void showRingsInPole() {
		//
		System.out.println("............................"); 
		System.out.println(".....Rings in the Pannel...."); 
		System.out.println("............................"); 
		for(int i=0; i<poles.length; i++) {
			poles[i].showRings();
		}
		System.out.println("............................"); 
	}
	
	public int getRingCount() {
		// 
		return Pole.MaxRingCount; 
	}
	
	public Pole getRightPole() {
		return poles[2]; 
	}
	
	public Pole getMiddlePole() {
		return poles[1]; 
	}
	
	public Pole getLeftPole() {
		return poles[0]; 
	}
	
	public Ring moveRingToFinal(Pole sourcePole, Pole targetPole) {
		// 
		Ring ring = sourcePole.pop(); 
		targetPole.push(ring);
		
		return ring;
	}
}