package namoosori.algorithm.hanoitower;

import java.util.Stack;

public class Pole {
	// 
	public static final int MaxRingCount = 6;  
	
	private int index; 
	private String name; 
	private Stack<Ring> ringStack; 
	
	public Pole(int index, String name) {
		// 
		this.index = index;
		this.name = name; 
		this.ringStack = new Stack<Ring>(); 
	}
	
	public void showRings() {
		// 
		System.out.println("Pole["+ index + "]"); 

		int size = ringStack.size(); 
		if(size == 0) {
			System.out.println(" -> No ring in this pole.");
			return; 
		}
		
		for (int i = (size-1); i>= 0; i--) {
			ringStack.get(i).show();
		}
	}
	
	public boolean isFull() {
		// 
		if (this.ringStack.size() == MaxRingCount) {
			return true; 
		}
		
		return false; 
	}
	
	public Ring peek() {
		//
		if(ringStack.size() == 0) {
			// 
			System.out.println(" -> No rings in this pole."); 
			return null; 
		}
		
		return ringStack.peek(); 
	}
	
	public Ring pop() {
		// 
		if(ringStack.size() == 0) {
			// 
			System.out.println(" -> No rings in this pole."); 
			return null; 
		}
		
		return ringStack.pop(); 
	}
	
	public void push(Ring ring) {
		// 
		if (isPushable(ring)) {
			ringStack.push(ring); 
		}
	}
	
	public boolean isPushable(Ring ring) {
		// 
		if (ringStack.isEmpty()) {
			return true; 
		}
		
		if (ringStack.peek().getSize() < ring.getSize()) {
			System.out.println("큰 링이 위에 올 수 없습니다.");
			return false; 
		} else {
			return true; 
		}
	}
	
	public int getIndex() {
		return index; 
	}
	
	public void setIndex(int index) {
		this.index = index; 
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
